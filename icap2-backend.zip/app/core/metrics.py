"""
metrics.py
-------------------------------------------------------------------------
Lightweight in-memory request/response metrics for the Admin Dashboard's
"System Performance" section (uptime, avg response time, error rate).

LIMITATION (flagged, not hidden): this is process-local memory. It resets
on every restart/deploy, and if the app ever runs as multiple uvicorn
workers or multiple replicas behind a load balancer, EACH process has its
own separate counters — there's no cross-process aggregation. That's fine
for a single dev/demo instance, but for real production monitoring this
should be replaced with an external APM (Prometheus + a /metrics scrape
endpoint, or a hosted option like Datadog/CloudWatch) rather than trusted
as-is at scale.
-------------------------------------------------------------------------
"""
import time
from collections import deque
from threading import Lock

_START_TIME = time.time()
_LOCK = Lock()

_request_count = 0
_error_count = 0  # status >= 500
# Keep only the most recent N durations for the rolling average, so this
# doesn't grow unbounded over a long-running process.
_recent_durations_ms: deque = deque(maxlen=1000)


def record_request(duration_ms: float, status_code: int) -> None:
    global _request_count, _error_count
    with _LOCK:
        _request_count += 1
        if status_code >= 500:
            _error_count += 1
        _recent_durations_ms.append(duration_ms)


def get_snapshot() -> dict:
    with _LOCK:
        request_count = _request_count
        error_count = _error_count
        durations = list(_recent_durations_ms)

    avg_response_ms = round(sum(durations) / len(durations), 2) if durations else None
    error_rate_percent = round((error_count / request_count) * 100, 2) if request_count else 0.0
    uptime_seconds = round(time.time() - _START_TIME, 1)

    return {
        "uptime_seconds": uptime_seconds,
        "request_count": request_count,
        "error_count": error_count,
        "error_rate_percent": error_rate_percent,
        "avg_response_time_ms": avg_response_ms,
        "sample_size": len(durations),
        "note": "In-memory, single-process metrics — resets on restart, not aggregated across workers/replicas.",
    }
