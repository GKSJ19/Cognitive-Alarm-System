import uuid
from enum import Enum as PyEnum
from sqlalchemy import Column, Integer, DateTime, Enum, ForeignKey, String, Index
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from sqlalchemy.sql import func
from app.core.database import Base

class VerificationStatus(str, PyEnum):
    pending = "pending"
    in_progress = "in_progress"
    passed = "passed"
    failed = "failed"

class AlarmTrigger(Base):
    __tablename__ = "alarm_triggers"
    __table_args__ = (
        Index("ix_alarm_triggers_alarm_id", "alarm_id"),
        Index("ix_alarm_triggers_user_id", "user_id"),
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    alarm_id = Column(UUID(as_uuid=True), ForeignKey("alarms.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    triggered_at = Column(DateTime(timezone=True), server_default=func.now())
    scheduled_for = Column(DateTime(timezone=True), nullable=True)
    dismissed_at = Column(DateTime(timezone=True), nullable=True)
    verification_status = Column(Enum(VerificationStatus, native_enum=False), default=VerificationStatus.pending)
    snooze_count = Column(Integer, default=0)
    total_attempts = Column(Integer, default=0)
    current_challenge_id = Column(UUID(as_uuid=True), ForeignKey("challenges.id", ondelete="SET NULL"), nullable=True)
    current_step = Column(Integer, default=0)
    correct_count = Column(Integer, default=0)
    chain_categories = Column(ARRAY(String), default=list)
    current_deadline = Column(DateTime(timezone=True), nullable=True)