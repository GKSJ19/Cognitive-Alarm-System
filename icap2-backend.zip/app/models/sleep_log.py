import uuid
from enum import Enum as PyEnum
from sqlalchemy import Column, Date, DateTime, Integer, Enum, ForeignKey, CheckConstraint, UniqueConstraint, Index
from sqlalchemy.dialects.postgresql import UUID
from app.core.database import Base

class SleepSource(str, PyEnum):
    manual = "manual"
    apple_healthkit = "apple_healthkit"
    google_fit = "google_fit"

class SleepLog(Base):
    __tablename__ = "sleep_logs"
    __table_args__ = (
        CheckConstraint("quality IS NULL OR (quality >= 1 AND quality <= 5)", name="ck_sleep_logs_quality_range"),
        UniqueConstraint("user_id", "date", name="uq_sleep_logs_user_date"),
        Index("ix_sleep_logs_user_id", "user_id"),
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    date = Column(Date, nullable=False)
    sleep_start = Column(DateTime(timezone=True), nullable=True)
    sleep_end = Column(DateTime(timezone=True), nullable=True)
    duration_mins = Column(Integer, nullable=True)
    quality = Column(Integer, nullable=True)  # 1-5 star rating, user-reported, optional
    source = Column(Enum(SleepSource, native_enum=False), default=SleepSource.manual)