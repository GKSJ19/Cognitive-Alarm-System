import uuid
from enum import Enum as PyEnum
from sqlalchemy import Column, String, Boolean, DateTime, Time, Date, ARRAY, SmallInteger, Integer, Enum, ForeignKey, Index
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from app.core.database import Base

class AlarmType(str, PyEnum):
    daily = "daily"
    weekday = "weekday"
    weekend = "weekend"
    one_time = "one_time"
    smart_adaptive = "smart_adaptive"

class VerificationMethod(str, PyEnum):
    puzzle = "puzzle"                    # Solve N. Wrong answers cost time, never progress.
    multi_step = "multi_step"            # Chain of N across different challenge types; one mistake restarts it.
    consecutive = "consecutive"          # N correct in a row; a wrong answer resets the streak to zero.
    time_bounded = "time_bounded"        # Every challenge carries a deadline; lapsing counts as wrong.
    accuracy = "accuracy"                # N correct AND >=70% accuracy overall.

class Alarm(Base):
    __tablename__ = "alarms"
    __table_args__ = (
        Index("ix_alarms_user_id", "user_id"),
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    time = Column(Time, nullable=False)
    alarm_type = Column(Enum(AlarmType, native_enum=False), default=AlarmType.daily)
    days_of_week = Column(ARRAY(SmallInteger), nullable=True)
    specific_date = Column(Date, nullable=True)
    timezone_override = Column(String(60), nullable=True)
    is_active = Column(Boolean, default=True)
    label = Column(String(100), nullable=True)
    max_snoozes = Column(Integer, default=3)
    snooze_duration_mins = Column(Integer, default=5)
    verification_method = Column(Enum(VerificationMethod, native_enum=False), default=VerificationMethod.puzzle)
    verification_target = Column(Integer, default=1)
    challenge_time_limit_secs = Column(Integer, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    deleted_at = Column(DateTime(timezone=True), nullable=True)  # soft-delete marker — separate from is_active (on/off toggle)