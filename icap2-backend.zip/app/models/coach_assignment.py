import uuid
from sqlalchemy import Column, DateTime, ForeignKey, UniqueConstraint, Index
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from app.core.database import Base

class CoachAssignment(Base):
    __tablename__ = "coach_assignments"
    __table_args__ = (
        UniqueConstraint("coach_id", "user_id", name="uq_coach_assignments_coach_user"),
        Index("ix_coach_assignments_coach_id", "coach_id"),
        Index("ix_coach_assignments_user_id", "user_id"),
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    coach_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    assigned_at = Column(DateTime(timezone=True), server_default=func.now())