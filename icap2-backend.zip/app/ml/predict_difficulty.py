"""
Loads the trained Difficulty model and predicts a direction
(increase/maintain/decrease) for one set of features — with a real,
per-prediction explanation, not a canned sentence.

Usage:
    from app.ml.predict_difficulty import predict_direction
    result = predict_direction({
        "rolling_accuracy": 82.0,
        "rolling_avg_time": 14.5,
        "current_difficulty": 2,   # medium
        "streak": 3,
        "challenge_type": "math",
    })
    # {"direction": "increase", "confidence": 0.71, "explanation": "..."}

If no model has been trained yet, predict_direction returns None so the
caller (difficulty_service.py) can fall back to the rule-based engine
instead of crashing.
"""
import os
import joblib
import shap
import pandas as pd

from app.ml.train_difficulty_model import MODEL_PATH, NUMERIC_FEATURES, CATEGORICAL_FEATURES, LABEL_ORDER

_cache = {}


def _load():
    if "bundle" in _cache:
        return _cache["bundle"]
    if not os.path.exists(MODEL_PATH):
        return None
    bundle = joblib.load(MODEL_PATH)
    _cache["bundle"] = bundle
    return bundle


def predict_direction(features: dict) -> dict | None:
    bundle = _load()
    if bundle is None:
        return None

    pipeline = bundle["pipeline"]
    label_encoder = bundle["label_encoder"]

    row = pd.DataFrame([{
        **{k: features.get(k) for k in NUMERIC_FEATURES},
        **{k: features.get(k) for k in CATEGORICAL_FEATURES},
    }])

    proba = pipeline.predict_proba(row)[0]
    pred_idx = proba.argmax()
    direction = str(label_encoder.inverse_transform([pred_idx])[0])
    confidence = float(proba[pred_idx])

    explanation = _explain(pipeline, row, pred_idx)

    return {"direction": direction, "confidence": round(confidence, 3), "explanation": explanation}


def _explain(pipeline, row: pd.DataFrame, class_idx: int) -> str:
    """Real per-prediction SHAP explanation — which features actually pushed this specific
    prediction toward this specific class, not a static list of 'important features'."""
    preprocessor = pipeline.named_steps["preprocess"]
    model = pipeline.named_steps["model"]

    transformed = preprocessor.transform(row)
    feature_names = list(preprocessor.get_feature_names_out())

    explainer = shap.TreeExplainer(model)
    explanation = explainer(transformed)

    values = explanation.values[0]
    if values.ndim == 1:
        class_values = values
    else:
        class_values = values[:, class_idx]

    ranked = sorted(zip(feature_names, class_values), key=lambda p: abs(p[1]), reverse=True)
    top = ranked[:2]

    parts = []
    for name, value in top:
        direction_word = "pushed toward this" if value > 0 else "pushed against this"
        clean_name = name.replace("remainder__", "").replace("cat__challenge_type_", "challenge type: ")
        parts.append(f"{clean_name} ({direction_word})")

    return "Driven mainly by " + " and ".join(parts) if parts else "No dominant feature."