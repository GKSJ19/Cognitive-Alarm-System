"""
Builds a per-(user, day) behavior feature frame for anomaly detection.

Unlike the Difficulty model (which predicts a label), this is unsupervised —
there's no "correct answer" per row. The features here describe one day of
one user's behavior; the model later learns what "normal" looks like and
flags days that don't fit.
"""
from datetime import timedelta
from collections import defaultdict
import pandas as pd
from sqlalchemy.orm import Session

from app.models.alarm_trigger import AlarmTrigger, VerificationStatus
from app.models.challenge_attempt import ChallengeAttempt
from app.models.sleep_log import SleepLog

MIN_ROWS_TO_TRAIN = 60


def build_behavior_frame(db: Session) -> pd.DataFrame:
    triggers = db.query(AlarmTrigger).filter(AlarmTrigger.triggered_at.isnot(None)).all()
    if not triggers:
        return pd.DataFrame()

    # --- Aggregate triggers per (user, date): snooze count + dismiss latency ---
    daily = defaultdict(lambda: {"snooze_count": 0, "dismiss_latencies": [], "trigger_times": []})
    for t in triggers:
        key = (t.user_id, t.triggered_at.date())
        daily[key]["snooze_count"] += t.snooze_count or 0
        daily[key]["trigger_times"].append(t.triggered_at)
        if t.dismissed_at and t.verification_status == VerificationStatus.passed:
            latency = (t.dismissed_at - t.triggered_at).total_seconds()
            if latency >= 0:
                daily[key]["dismiss_latencies"].append(latency)

    # --- Challenge accuracy per (user, date) ---
    attempts = (
        db.query(ChallengeAttempt, AlarmTrigger.user_id)
        .join(AlarmTrigger, ChallengeAttempt.alarm_trigger_id == AlarmTrigger.id)
        .filter(ChallengeAttempt.answered_at.isnot(None))
        .all()
    )
    accuracy_by_key = defaultdict(list)
    for attempt, user_id in attempts:
        key = (user_id, attempt.answered_at.date())
        accuracy_by_key[key].append(attempt.is_correct)

    # --- Sleep duration per (user, date) ---
    sleep_logs = db.query(SleepLog).all()
    sleep_by_key = {(s.user_id, s.date): s.duration_mins for s in sleep_logs if s.duration_mins is not None}

    # --- Each user's own rolling wake-time baseline, to make deviation personalized ---
    wake_minutes_by_user = defaultdict(list)
    for key, info in sorted(daily.items(), key=lambda kv: kv[0][1]):
        user_id, _ = key
        if info["trigger_times"]:
            first_trigger = min(info["trigger_times"])
            wake_minutes_by_user[user_id].append(first_trigger.hour * 60 + first_trigger.minute)

    user_avg_wake_minute = {
        user_id: sum(mins) / len(mins) for user_id, mins in wake_minutes_by_user.items() if mins
    }

    records = []
    for (user_id, date), info in daily.items():
        first_trigger = min(info["trigger_times"])
        wake_minute = first_trigger.hour * 60 + first_trigger.minute
        baseline = user_avg_wake_minute.get(user_id, wake_minute)
        wake_deviation = abs(wake_minute - baseline)

        latencies = info["dismiss_latencies"]
        avg_latency = sum(latencies) / len(latencies) if latencies else None

        results = accuracy_by_key.get((user_id, date))
        accuracy = (sum(results) / len(results) * 100) if results else None

        sleep_duration = sleep_by_key.get((user_id, date))

        records.append({
            "user_id": user_id,
            "date": date,
            "snooze_count": info["snooze_count"],
            "dismiss_latency_seconds": avg_latency,
            "wake_time_deviation_minutes": wake_deviation,
            "challenge_accuracy_percent": accuracy,
            "sleep_duration_mins": sleep_duration,
        })

    df = pd.DataFrame(records)
    if df.empty:
        return df

    # Impute missing values with each user's OWN median, not a global one — a 6-hour
    # sleeper's "normal" is a 9-hour sleeper's anomaly, so a global fill would be wrong.
    for col in ["dismiss_latency_seconds", "challenge_accuracy_percent", "sleep_duration_mins"]:
        df[col] = df.groupby("user_id")[col].transform(lambda s: s.fillna(s.median()))
        df[col] = df[col].fillna(df[col].median())  # last resort for users with zero data on this metric

    return df