"""
Builds a training dataframe for the Recommendation model: one row per past
ChallengeAttempt, predicting whether the user got it right (is_correct),
using ONLY that user's history strictly before this attempt.

CRITICAL: every feature here is computed to exactly mirror
recommendation_service.py's _build_live_features() -- same field names, same
defaults, same "use history, not the current attempt's own challenge" logic
(e.g. current_difficulty comes from the LAST same-category attempt's
difficulty, not this attempt's own difficulty, because at real recommendation
time the next challenge hasn't been generated yet). If training-time features
don't match inference-time features, the model learns a different problem
than the one it's actually asked to solve at prediction time.
"""
import pandas as pd
from sqlalchemy.orm import Session

from app.models.challenge_attempt import ChallengeAttempt
from app.models.challenge import Challenge
from app.models.alarm_trigger import AlarmTrigger

DIFFICULTY_ORDER = {"beginner": 0, "easy": 1, "medium": 2, "hard": 3, "expert": 4}
ROLLING_WINDOW = 8
MIN_ROWS_TO_TRAIN = 60

NUMERIC_FEATURES = [
    "overall_rolling_accuracy", "same_category_accuracy", "same_category_attempts",
    "current_difficulty", "streak", "hour_of_day", "day_of_week",
    "days_since_category_attempt", "category_diversity", "total_attempts_so_far",
    "difficulty_trend",
]
CATEGORICAL_FEATURES = ["challenge_type"]


def _fetch_raw_attempts(db: Session) -> pd.DataFrame:
    rows = (
        db.query(
            ChallengeAttempt.id,
            AlarmTrigger.user_id,
            ChallengeAttempt.answered_at,
            ChallengeAttempt.is_correct,
            Challenge.type,
            Challenge.difficulty,
        )
        .join(Challenge, ChallengeAttempt.challenge_id == Challenge.id)
        .join(AlarmTrigger, ChallengeAttempt.alarm_trigger_id == AlarmTrigger.id)
        .filter(ChallengeAttempt.answered_at.isnot(None))
        .all()
    )
    df = pd.DataFrame(rows, columns=[
        "attempt_id", "user_id", "answered_at", "is_correct", "challenge_type", "difficulty",
    ])
    df["challenge_type"] = df["challenge_type"].apply(lambda t: t.value if hasattr(t, "value") else t)
    df["difficulty"] = df["difficulty"].apply(lambda d: d.value if hasattr(d, "value") else d)
    return df


def build_training_frame(db: Session) -> pd.DataFrame:
    df = _fetch_raw_attempts(db)
    if df.empty:
        return df

    df = df.sort_values(["user_id", "answered_at"]).reset_index(drop=True)

    records = []
    for user_id, group in df.groupby("user_id"):
        group = group.reset_index(drop=True)

        for i in range(len(group)):
            history = group.iloc[:i]  # strictly before this attempt -- no leakage
            if len(history) == 0:
                continue

            current_row = group.iloc[i]
            category = current_row["challenge_type"]

            recent_all = history.tail(ROLLING_WINDOW)
            overall_rolling_accuracy = recent_all["is_correct"].mean() * 100

            same_cat_hist = history[history["challenge_type"] == category]
            if len(same_cat_hist) > 0:
                same_cat_recent = same_cat_hist.tail(ROLLING_WINDOW)
                same_category_accuracy = same_cat_recent["is_correct"].mean() * 100
                same_category_attempts = len(same_cat_hist)

                last_difficulty = same_cat_hist.iloc[-1]["difficulty"]
                days_since_category_attempt = (
                    current_row["answered_at"] - same_cat_hist.iloc[-1]["answered_at"]
                ).total_seconds() / 86400

                if len(same_cat_hist) >= 2:
                    diffs = same_cat_hist["difficulty"].map(lambda d: DIFFICULTY_ORDER.get(d, 2)).tolist()
                    half = max(1, len(diffs) // 2)
                    difficulty_trend = (
                        sum(diffs[-half:]) / half
                        - sum(diffs[: len(diffs) - half]) / max(1, len(diffs) - half)
                    )
                else:
                    difficulty_trend = 0.0
            else:
                same_category_accuracy = -1
                same_category_attempts = 0
                last_difficulty = "medium"
                days_since_category_attempt = -1
                difficulty_trend = 0.0

            streak = 0
            for correct in recent_all["is_correct"].iloc[::-1]:
                if correct:
                    streak += 1
                else:
                    break

            distinct_categories = history["challenge_type"].nunique()

            records.append({
                "overall_rolling_accuracy": overall_rolling_accuracy,
                "same_category_accuracy": same_category_accuracy,
                "same_category_attempts": same_category_attempts,
                "current_difficulty": DIFFICULTY_ORDER.get(last_difficulty, 2),
                "challenge_type": category,
                "streak": streak,
                "hour_of_day": current_row["answered_at"].hour,
                "day_of_week": current_row["answered_at"].weekday(),
                "days_since_category_attempt": round(days_since_category_attempt, 2),
                "category_diversity": distinct_categories,
                "total_attempts_so_far": len(history),
                "difficulty_trend": round(float(difficulty_trend), 2),
                "label": int(current_row["is_correct"]),
            })

    return pd.DataFrame(records)