"""
Builds a training dataframe for the Adaptive Difficulty model.

CRITICAL RULE: every feature for attempt i is computed using ONLY attempts
that happened before attempt i, for that same user. If you compute rolling
stats over a window that includes the current row, the model sees the
answer before it predicts — that's leakage, and it makes your accuracy
numbers meaningless.
"""
import pandas as pd
from sqlalchemy.orm import Session

from app.models.challenge_attempt import ChallengeAttempt
from app.models.challenge import Challenge
from app.models.alarm_trigger import AlarmTrigger

DIFFICULTY_ORDER = {"beginner": 0, "easy": 1, "medium": 2, "hard": 3, "expert": 4}
ROLLING_WINDOW = 8
MIN_ROWS_TO_TRAIN = 60


def _fetch_raw_attempts(db: Session) -> pd.DataFrame:
    """One row per attempt, across ALL users — joined with its challenge's type/difficulty."""
    rows = (
        db.query(
            ChallengeAttempt.id,
            AlarmTrigger.user_id,
            ChallengeAttempt.answered_at,
            ChallengeAttempt.is_correct,
            ChallengeAttempt.time_taken_seconds,
            Challenge.type,
            Challenge.difficulty,
        )
        .join(Challenge, ChallengeAttempt.challenge_id == Challenge.id)
        .join(AlarmTrigger, ChallengeAttempt.alarm_trigger_id == AlarmTrigger.id)
        .filter(ChallengeAttempt.answered_at.isnot(None))
        .all()
    )
    df = pd.DataFrame(rows, columns=[
        "attempt_id", "user_id", "answered_at", "is_correct",
        "time_taken_seconds", "challenge_type", "difficulty",
    ])
    df["challenge_type"] = df["challenge_type"].apply(lambda t: t.value if hasattr(t, "value") else t)
    df["difficulty"] = df["difficulty"].apply(lambda d: d.value if hasattr(d, "value") else d)
    return df


def _label_row(is_correct: bool, time_taken, fast_threshold) -> str:
    if not is_correct:
        return "decrease"
    if time_taken is not None and fast_threshold is not None and time_taken <= fast_threshold:
        return "increase"
    return "maintain"


def build_training_frame(db: Session) -> pd.DataFrame:
    df = _fetch_raw_attempts(db)
    if df.empty:
        return df

    df = df.sort_values(["user_id", "answered_at"]).reset_index(drop=True)

    # "Fast" is relative to BOTH challenge type AND difficulty — a fast hard
    # question and a fast easy question don't take the same time, and pooling
    # them together was letting the label leak difficulty into itself.
    fast_thresholds = df.groupby(["challenge_type", "difficulty"])["time_taken_seconds"].quantile(0.33)

    records = []
    for user_id, group in df.groupby("user_id"):
        group = group.reset_index(drop=True)
        for i in range(len(group)):
            history = group.iloc[:i]
            if len(history) == 0:
                continue

            recent = history.tail(ROLLING_WINDOW)
            rolling_accuracy = recent["is_correct"].mean() * 100
            rolling_avg_time = recent["time_taken_seconds"].dropna().mean()

            streak = 0
            for correct in recent["is_correct"].iloc[::-1]:
                if correct:
                    streak += 1
                else:
                    break

            current_row = group.iloc[i]
            fast_threshold = fast_thresholds.get((current_row["challenge_type"], current_row["difficulty"]))
            label = _label_row(current_row["is_correct"], current_row["time_taken_seconds"], fast_threshold)

            records.append({
                "user_id": user_id,
                "rolling_accuracy": rolling_accuracy,
                "rolling_avg_time": rolling_avg_time if pd.notna(rolling_avg_time) else -1,
                "current_difficulty": DIFFICULTY_ORDER.get(current_row["difficulty"], 2),
                "challenge_type": current_row["challenge_type"],
                "streak": streak,
                "label": label,
            })

    return pd.DataFrame(records)