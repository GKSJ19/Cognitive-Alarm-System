"""
Seeds ~90 days of per-user behavior data for the Behavior anomaly model:
AlarmTrigger snooze/dismiss timing, ChallengeAttempt accuracy, and SleepLog
rows. Unlike seed_synthetic_data.py (Difficulty), this doesn't need to run
through the adaptive-difficulty flow -- the Behavior model only reads daily
aggregates, so this writes those rows directly.

Commits once per user (not once per day) and generates row IDs locally
instead of refreshing from the DB after every insert -- cuts round trips
from ~270/user to ~1/user, which matters a lot on a remote pooler.

Each synthetic user gets a stable "normal" pattern (wake time, snoozes,
sleep duration, accuracy), plus a small fraction of days deliberately drawn
from a worse distribution -- poor sleep, many snoozes, long dismiss latency,
lower accuracy -- so the dataset actually contains days that SHOULD look
anomalous. No day is hand-labeled as anomalous; the model has to find them
itself from the feature values, same as it will with real user data later.

Reuses an existing Challenge row from your Difficulty seed data for the
challenge_id foreign key on ChallengeAttempt -- run seed_synthetic_data.py
at least once before this (and don't run its cleanup() first).

Every seeded user's email ends in @icap-behavior-seed.local, kept separate
from the Difficulty seed users, so the two can be wiped independently.

Run: python -m app.ml.seed_behavior_data
"""
import random
import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import sessionmaker
from app.core.database import engine
from app.models.user import User
from app.models.alarm import Alarm, VerificationMethod
from app.models.alarm_trigger import AlarmTrigger, VerificationStatus
from app.models.challenge_attempt import ChallengeAttempt
from app.models.challenge import Challenge
from app.models.sleep_log import SleepLog, SleepSource

SeedSession = sessionmaker(autocommit=False, autoflush=False, bind=engine, expire_on_commit=False)

SEED_DOMAIN = "icap-behavior-seed.local"
NUM_SYNTHETIC_USERS = 12
DAYS_BACK = 90
ANOMALY_DAY_RATE = 0.08  # ~8% of days deliberately drawn from a "bad day" distribution


def _get_reusable_challenge_id(db):
    """Reuses any existing Challenge row so ChallengeAttempt's FK is satisfied,
    without needing to guess this project's exact Challenge model fields."""
    challenge = db.query(Challenge).first()
    if challenge is None:
        raise RuntimeError(
            "No Challenge rows found. Run `python -m app.ml.seed_synthetic_data` "
            "(the Difficulty seed script) first -- this script reuses one of its "
            "challenges and doesn't create its own."
        )
    return challenge.id


def _make_synthetic_users(db):
    users = []
    for i in range(NUM_SYNTHETIC_USERS):
        email = f"synthetic_behavior_{i}@{SEED_DOMAIN}"
        existing = db.query(User).filter(User.email == email).first()
        if existing:
            user = existing
        else:
            user = User(
                id=uuid.uuid4(),
                name=f"Synthetic Behavior User {i}",
                email=email,
                password_hash=None,
                auth_provider="seed",
                role="user",
                is_active=True,
            )
            db.add(user)
            db.commit()

        baseline_wake_minute = random.randint(360, 510)
        baseline_snooze_rate = random.uniform(0.2, 1.5)
        baseline_latency = random.uniform(15, 45)
        baseline_sleep_mins = random.uniform(390, 480)
        baseline_accuracy = random.uniform(0.6, 0.9)

        users.append((user, {
            "wake_minute": baseline_wake_minute,
            "snooze_rate": baseline_snooze_rate,
            "latency": baseline_latency,
            "sleep_mins": baseline_sleep_mins,
            "accuracy": baseline_accuracy,
        }))
    return users


def _make_alarm_for(db, user):
    existing = db.query(Alarm).filter(Alarm.user_id == user.id).first()
    if existing:
        return existing
    alarm = Alarm(
        id=uuid.uuid4(),
        user_id=user.id,
        time=datetime.now().time(),
        label="Synthetic behavior seed alarm",
        verification_method=VerificationMethod.puzzle,
        verification_target=1,
        is_active=True,
    )
    db.add(alarm)
    db.commit()
    return alarm


def seed():
    db = SeedSession()
    try:
        challenge_id = _get_reusable_challenge_id(db)
        users = _make_synthetic_users(db)
        print(f"Using {len(users)} synthetic behavior users")

        total_triggers = 0
        total_sleep_logs = 0

        for user, baseline in users:
            alarm = _make_alarm_for(db, user)

            for d in range(DAYS_BACK):
                day_date = (datetime.now(timezone.utc) - timedelta(days=DAYS_BACK - d)).date()
                is_anomaly = random.random() < ANOMALY_DAY_RATE

                if is_anomaly:
                    wake_minute = baseline["wake_minute"] + random.choice([-1, 1]) * random.randint(90, 180)
                    snooze_count = random.randint(4, 8)
                    latency = random.uniform(300, 900)
                    sleep_mins = random.choice([random.uniform(120, 240), random.uniform(560, 660)])
                    accuracy_prob = max(0.05, baseline["accuracy"] - 0.5)
                else:
                    wake_minute = baseline["wake_minute"] + int(random.gauss(0, 15))
                    snooze_count = max(0, int(random.gauss(baseline["snooze_rate"], 1)))
                    latency = max(3, random.gauss(baseline["latency"], 10))
                    sleep_mins = max(180, random.gauss(baseline["sleep_mins"], 30))
                    accuracy_prob = baseline["accuracy"]

                wake_minute = max(0, min(23 * 60 + 59, wake_minute))
                triggered_at = datetime.combine(day_date, datetime.min.time(), tzinfo=timezone.utc) \
                    + timedelta(minutes=wake_minute)
                dismissed_at = triggered_at + timedelta(seconds=latency)

                trigger_id = uuid.uuid4()
                db.add(AlarmTrigger(
                    id=trigger_id,
                    alarm_id=alarm.id,
                    user_id=user.id,
                    triggered_at=triggered_at,
                    dismissed_at=dismissed_at,
                    verification_status=VerificationStatus.passed,
                    snooze_count=snooze_count,
                ))
                total_triggers += 1

                for _ in range(random.randint(1, 3)):
                    is_correct = random.random() < accuracy_prob
                    db.add(ChallengeAttempt(
                        id=uuid.uuid4(),
                        alarm_trigger_id=trigger_id,
                        challenge_id=challenge_id,
                        attempt_number=1,
                        is_correct=is_correct,
                        time_taken_seconds=random.randint(5, 30),
                        answered_at=triggered_at + timedelta(minutes=random.randint(1, 5)),
                    ))

                db.add(SleepLog(
                    id=uuid.uuid4(),
                    user_id=user.id,
                    date=day_date,
                    duration_mins=int(sleep_mins),
                    source=SleepSource.manual,
                ))
                total_sleep_logs += 1

            db.commit()  # one commit per user, not per day
            print(f"  seeded {DAYS_BACK} days for {user.email}")

        print(f"\nDone. {total_triggers} triggers and {total_sleep_logs} sleep logs "
              f"across {len(users)} users (~{total_triggers} user-days).")
        print("Next: python -m app.ml.train_behavior_model")
    finally:
        db.close()


def cleanup():
    """Removes all seeded behavior synthetic users and their data."""
    db = SeedSession()
    try:
        seed_users = db.query(User).filter(User.email.like(f"%@{SEED_DOMAIN}")).all()
        user_ids = [u.id for u in seed_users]
        if not user_ids:
            print("No synthetic behavior seed users found.")
            return

        alarm_ids = [a.id for a in db.query(Alarm).filter(Alarm.user_id.in_(user_ids)).all()]
        trigger_ids = [t.id for t in db.query(AlarmTrigger).filter(AlarmTrigger.user_id.in_(user_ids)).all()]

        db.query(ChallengeAttempt).filter(ChallengeAttempt.alarm_trigger_id.in_(trigger_ids)).delete(synchronize_session=False)
        db.query(SleepLog).filter(SleepLog.user_id.in_(user_ids)).delete(synchronize_session=False)
        db.query(AlarmTrigger).filter(AlarmTrigger.id.in_(trigger_ids)).delete(synchronize_session=False)
        db.query(Alarm).filter(Alarm.id.in_(alarm_ids)).delete(synchronize_session=False)
        db.query(User).filter(User.id.in_(user_ids)).delete(synchronize_session=False)
        db.commit()
        print(f"Removed {len(user_ids)} synthetic behavior users and all their seeded data.")
    finally:
        db.close()


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "cleanup":
        cleanup()
    else:
        seed()