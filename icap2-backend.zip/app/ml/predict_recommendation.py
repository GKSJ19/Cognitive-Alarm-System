"""
Loads the trained (and calibrated) Recommendation model and predicts
P(correct) for a user in a given category - with a real, per-prediction
SHAP explanation.

Usage:
    from app.ml.predict_recommendation import predict_success_probability
    result = predict_success_probability({
        "overall_rolling_accuracy": 74.0,
        "same_category_accuracy": 40.0,
        "same_category_attempts": 6,
        "current_difficulty": 2,
        "challenge_type": "logic",
        "streak": 1,
        "hour_of_day": 7,
        "day_of_week": 2,
        "days_since_category_attempt": 3.5,
        "category_diversity": 4,
        "total_attempts_so_far": 22,
        "difficulty_trend": 0.5,
    })
    # {"success_probability": 0.42, "explanation": "..."}

If no model has been trained yet, predict_success_probability returns None
so the caller (recommendation_service.py) falls back to the rule-based
engine instead of crashing.
"""
import os
import joblib
import shap
import pandas as pd

from app.ml.train_recommendation_model import MODEL_PATH
from app.ml.recommendation_features import NUMERIC_FEATURES, CATEGORICAL_FEATURES

_cache = {}


def _load():
    if "bundle" in _cache:
        return _cache["bundle"]
    if not os.path.exists(MODEL_PATH):
        return None
    bundle = joblib.load(MODEL_PATH)
    _cache["bundle"] = bundle
    return bundle


def _row_from(features: dict) -> pd.DataFrame:
    return pd.DataFrame([{
        **{k: features.get(k) for k in NUMERIC_FEATURES},
        **{k: features.get(k) for k in CATEGORICAL_FEATURES},
    }])


def predict_success_probability(features: dict) -> dict | None:
    bundle = _load()
    if bundle is None:
        return None

    calibrated_pipeline = bundle["pipeline"]
    row = _row_from(features)

    proba = calibrated_pipeline.predict_proba(row)[0]
    success_probability = float(proba[1])  # class 1 = correct

    explanation = _explain(bundle["explainer_pipeline"], row)

    return {"success_probability": round(success_probability, 3), "explanation": explanation}


def _explain(pipeline, row: pd.DataFrame) -> str:
    """SHAP runs on the underlying (uncalibrated) tree pipeline - calibration only
    rescales the output probability, it doesn't change which features drove the
    ranking, so this still explains the real prediction."""
    preprocessor = pipeline.named_steps["preprocess"]
    model = pipeline.named_steps["model"]

    transformed = preprocessor.transform(row)
    feature_names = list(preprocessor.get_feature_names_out())

    explainer = shap.TreeExplainer(model)
    explanation = explainer(transformed)

    values = explanation.values[0]
    if values.ndim == 2:
        values = values[:, 1]

    ranked = sorted(zip(feature_names, values), key=lambda p: abs(p[1]), reverse=True)
    top = ranked[:2]

    parts = []
    for name, value in top:
        direction_word = "raised the odds" if value > 0 else "lowered the odds"
        clean_name = name.replace("remainder__", "").replace("cat__challenge_type_", "category: ")
        parts.append(f"{clean_name} ({direction_word})")

    return "Driven mainly by " + " and ".join(parts) if parts else "No dominant feature."