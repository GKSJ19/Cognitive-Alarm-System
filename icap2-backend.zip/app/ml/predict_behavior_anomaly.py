"""
Loads the trained Behavior Anomaly model and scores one day's behavior.

Usage:
    from app.ml.predict_behavior_anomaly import check_anomaly
    result = check_anomaly({
        "snooze_count": 4,
        "dismiss_latency_seconds": 240,
        "wake_time_deviation_minutes": 55,
        "challenge_accuracy_percent": 40,
        "sleep_duration_mins": 300,
    })
    # {"is_anomaly": True, "anomaly_score": -0.18}

Returns None if no model has been trained yet, so callers can fall back
to the rule-based behavior_service.py instead of crashing.
"""
import os
import joblib
import pandas as pd

from app.ml.train_behavior_model import MODEL_PATH, FEATURE_COLUMNS

_cache = {}


def _load():
    if "bundle" in _cache:
        return _cache["bundle"]
    if not os.path.exists(MODEL_PATH):
        return None
    bundle = joblib.load(MODEL_PATH)
    _cache["bundle"] = bundle
    return bundle


def check_anomaly(features: dict) -> dict | None:
    bundle = _load()
    if bundle is None:
        return None

    model = bundle["model"]
    scaler = bundle["scaler"]

    row = pd.DataFrame([{col: features.get(col) for col in FEATURE_COLUMNS}])
    scaled = scaler.transform(row)

    prediction = model.predict(scaled)[0]  # -1 = anomaly, 1 = normal
    score = float(model.decision_function(scaled)[0])  # lower = more anomalous

    return {"is_anomaly": bool(prediction == -1), "anomaly_score": round(score, 4)}