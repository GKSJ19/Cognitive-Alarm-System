"""
Trains the Recommendation model: predicts P(this user answers a challenge
in this category correctly), used to recommend which category to practice.

Run: python -m app.ml.train_recommendation_model

Unlike the Difficulty model, this prediction gets shown to the user as a
literal probability ("42% success chance"), not just used to pick a class.
That means raw model output isn't good enough -- tree models are often good
at RANKING who's more likely to succeed but poorly CALIBRATED in the actual
probability numbers (e.g. everything predicted "70%" doesn't actually
succeed 70% of the time). So this script:

1. Trains RandomForest vs XGBoost, picks the winner by ROC AUC (ranking
   quality) on a held-out test set.
2. Wraps the winner in CalibratedClassifierCV and reports the Brier score
   (lower = better-calibrated probabilities) BEFORE and AFTER calibration,
   so the improvement is a measured number, not an assumption.
3. Saves BOTH the calibrated pipeline (what predict_recommendation.py uses
   for actual probabilities) and the original uncalibrated pipeline
   (what SHAP explains -- calibration only rescales the output, it doesn't
   change which features drove the prediction).
4. Still refuses to train below MIN_ROWS_TO_TRAIN.
"""
import os
import json
from datetime import datetime, timezone

import joblib
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import accuracy_score, roc_auc_score, brier_score_loss
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

from app.core.database import SessionLocal
from app.ml.recommendation_features import build_training_frame, MIN_ROWS_TO_TRAIN, NUMERIC_FEATURES, CATEGORICAL_FEATURES

ARTIFACT_DIR = os.path.join(os.path.dirname(__file__), "artifacts")
MODEL_PATH = os.path.join(ARTIFACT_DIR, "recommendation_model.joblib")
METADATA_PATH = os.path.join(ARTIFACT_DIR, "recommendation_model_meta.json")


def _build_pipeline(estimator):
    preprocessor = ColumnTransformer([
        ("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL_FEATURES),
    ], remainder="passthrough")
    return Pipeline([("preprocess", preprocessor), ("model", estimator)])


def train():
    os.makedirs(ARTIFACT_DIR, exist_ok=True)
    db = SessionLocal()
    try:
        df = build_training_frame(db)
    finally:
        db.close()

    if len(df) < MIN_ROWS_TO_TRAIN:
        print(
            f"Only {len(df)} usable rows -- need at least {MIN_ROWS_TO_TRAIN} to train "
            f"a model that means anything. Not training. The rule-based fallback in "
            f"recommendation_service.py stays in charge until you have enough real data."
        )
        return None

    X = df[NUMERIC_FEATURES + CATEGORICAL_FEATURES]
    y = df["label"]

    print(f"Training on {len(df)} rows. Label balance: "
          f"{y.mean():.1%} correct / {1 - y.mean():.1%} incorrect")
    print(f"Category counts:\n{df['challenge_type'].value_counts().to_string()}\n")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    candidates = {
        "random_forest": RandomForestClassifier(
            n_estimators=200, max_depth=8, min_samples_leaf=5,
            random_state=42, class_weight="balanced",
        ),
        "xgboost": XGBClassifier(
            n_estimators=200, max_depth=4, learning_rate=0.1,
            subsample=0.8, colsample_bytree=0.8,
            random_state=42, eval_metric="logloss",
        ),
    }

    results = {}
    fitted_pipelines = {}

    for name, estimator in candidates.items():
        pipeline = _build_pipeline(estimator)
        pipeline.fit(X_train, y_train)

        train_pred = pipeline.predict(X_train)
        test_pred = pipeline.predict(X_test)
        test_proba = pipeline.predict_proba(X_test)[:, 1]

        train_acc = accuracy_score(y_train, train_pred)
        test_acc = accuracy_score(y_test, test_pred)
        test_auc = roc_auc_score(y_test, test_proba)
        raw_brier = brier_score_loss(y_test, test_proba)

        results[name] = {
            "train_accuracy": round(train_acc, 4),
            "test_accuracy": round(test_acc, 4),
            "test_roc_auc": round(test_auc, 4),
            "raw_brier_score": round(raw_brier, 4),
        }
        fitted_pipelines[name] = pipeline

        print(f"{name}:")
        print(f"  train accuracy: {results[name]['train_accuracy']}")
        print(f"  test accuracy:  {results[name]['test_accuracy']}")
        print(f"  test ROC AUC:   {results[name]['test_roc_auc']}")
        if train_acc - test_acc > 0.15:
            print(f"  WARNING: {name} shows signs of overfitting (train >> test accuracy)")

    winner_name = max(results, key=lambda n: results[n]["test_roc_auc"])
    winner_pipeline = fitted_pipelines[winner_name]
    print(f"\nWinner (by ROC AUC): {winner_name}\n")

    print("Calibrating probabilities with CalibratedClassifierCV...")
    calibrated = CalibratedClassifierCV(
        _build_pipeline(candidates[winner_name].__class__(**candidates[winner_name].get_params())),
        method="sigmoid", cv=3,
    )
    calibrated.fit(X_train, y_train)

    calibrated_proba = calibrated.predict_proba(X_test)[:, 1]
    calibrated_brier = brier_score_loss(y_test, calibrated_proba)
    raw_brier = results[winner_name]["raw_brier_score"]

    print(f"Brier score before calibration: {raw_brier}")
    print(f"Brier score after calibration:  {round(calibrated_brier, 4)}")
    if calibrated_brier < raw_brier:
        print("Calibration improved probability quality (lower Brier = better).")
    else:
        print("WARNING: calibration did not improve Brier score -- raw probabilities "
              "may already be reasonably calibrated, or there isn't enough data for "
              "CalibratedClassifierCV's internal split to help.")

    joblib.dump({
        "pipeline": calibrated,
        "explainer_pipeline": winner_pipeline,
        "algorithm": winner_name,
    }, MODEL_PATH)

    with open(METADATA_PATH, "w") as f:
        json.dump({
            "trained_at": datetime.now(timezone.utc).isoformat(),
            "n_rows": len(df),
            "label_balance_correct": round(float(y.mean()), 4),
            "winner": winner_name,
            "model_comparison": results,
            "brier_before_calibration": round(raw_brier, 4),
            "brier_after_calibration": round(calibrated_brier, 4),
            "feature_columns": NUMERIC_FEATURES + CATEGORICAL_FEATURES,
        }, f, indent=2)

    print(f"\nSaved model to {MODEL_PATH}")
    print(f"Saved comparison + calibration metrics to {METADATA_PATH}")
    return calibrated


if __name__ == "__main__":
    train()