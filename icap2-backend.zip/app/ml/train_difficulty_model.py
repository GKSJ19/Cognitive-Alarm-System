"""
Trains the Adaptive Difficulty model — for real, not a toy pass.

Run: python -m app.ml.train_difficulty_model

What this does differently from a "pick one algorithm and hope" script:

1. Trains BOTH RandomForest and XGBoost on the identical train/test split,
   so the comparison is fair — same data, same features, same split seed.

2. Selects the winner by MACRO F1, not accuracy. Here's why that matters:
   our 3 classes (increase/maintain/decrease) are not equally common —
   "maintain" dominates in most real usage. A model that just predicts
   "maintain" every time can post high accuracy while being useless at
   the two classes that actually matter for adapting difficulty.
   Macro F1 scores all 3 classes equally, so a model can't hide behind
   the majority class.

3. Computes SHAP values on the winning model — real feature attribution,
   not just .feature_importances_. SHAP tells you, per prediction, how
   much each feature pushed toward "increase" vs "decrease" vs "maintain",
   which is what "explainable" actually means in practice, not just a
   ranked list of feature names.

4. Still refuses to train below MIN_ROWS_TO_TRAIN, and still reports
   train vs test performance so overfitting can't hide.
"""
import os
import json
from datetime import datetime, timezone

import numpy as np
import joblib
import shap
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, classification_report
from sklearn.preprocessing import OneHotEncoder, LabelEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

from app.core.database import SessionLocal
from app.ml.features import build_training_frame, MIN_ROWS_TO_TRAIN

ARTIFACT_DIR = os.path.join(os.path.dirname(__file__), "artifacts")
MODEL_PATH = os.path.join(ARTIFACT_DIR, "difficulty_model.joblib")
METADATA_PATH = os.path.join(ARTIFACT_DIR, "difficulty_model_meta.json")

NUMERIC_FEATURES = ["rolling_accuracy", "rolling_avg_time", "current_difficulty", "streak"]
CATEGORICAL_FEATURES = ["challenge_type"]
LABEL_ORDER = ["decrease", "maintain", "increase"]  # fixed order so SHAP class indices are stable


def _build_pipeline(estimator):
    preprocessor = ColumnTransformer([
        ("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL_FEATURES),
    ], remainder="passthrough")
    return Pipeline([("preprocess", preprocessor), ("model", estimator)])


def _evaluate(pipeline, X_train, y_train, X_test, y_test):
    train_pred = pipeline.predict(X_train)
    test_pred = pipeline.predict(X_test)
    return {
        "train_accuracy": round(accuracy_score(y_train, train_pred), 4),
        "test_accuracy": round(accuracy_score(y_test, test_pred), 4),
        "test_macro_f1": round(f1_score(y_test, test_pred, average="macro"), 4),
        "classification_report": classification_report(y_test, test_pred, output_dict=True),
    }


def _compute_shap_importance(pipeline, X_test):
    """
    Runs SHAP TreeExplainer on the fitted tree model, using the SAME
    preprocessing the pipeline uses at inference time. Returns:
      - global_importance: mean(|SHAP value|) per feature, averaged across
        classes — "which features matter most overall"
      - per_class_top_features: top 3 features driving each class specifically
    """
    preprocessor = pipeline.named_steps["preprocess"]
    model = pipeline.named_steps["model"]

    X_test_transformed = preprocessor.transform(X_test)
    feature_names = list(preprocessor.get_feature_names_out())

    explainer = shap.TreeExplainer(model)
    explanation = explainer(X_test_transformed)  # shape: (n_samples, n_features, n_classes) for multiclass

    values = explanation.values
    if values.ndim == 2:  # binary/regression fallback shape
        values = values[:, :, None]

    n_classes = values.shape[2]
    mean_abs_per_feature = np.abs(values).mean(axis=(0, 2))
    global_importance = sorted(
        zip(feature_names, mean_abs_per_feature.tolist()),
        key=lambda pair: pair[1], reverse=True,
    )

    per_class_top_features = {}
    for c in range(min(n_classes, len(LABEL_ORDER))):
        class_mean_abs = np.abs(values[:, :, c]).mean(axis=0)
        top3 = sorted(zip(feature_names, class_mean_abs.tolist()), key=lambda p: p[1], reverse=True)[:3]
        per_class_top_features[LABEL_ORDER[c]] = [{"feature": f, "mean_abs_shap": round(v, 4)} for f, v in top3]

    return {
        "global_importance": [{"feature": f, "mean_abs_shap": round(v, 4)} for f, v in global_importance],
        "per_class_top_features": per_class_top_features,
    }


def train():
    os.makedirs(ARTIFACT_DIR, exist_ok=True)
    db = SessionLocal()
    try:
        df = build_training_frame(db)
    finally:
        db.close()

    if len(df) < MIN_ROWS_TO_TRAIN:
        print(
            f"Only {len(df)} usable rows — need at least {MIN_ROWS_TO_TRAIN} to train "
            f"a model that means anything. Not training. The rule-based engine in "
            f"difficulty_service.py stays in charge until you have enough real data."
        )
        return None

    X = df[NUMERIC_FEATURES + CATEGORICAL_FEATURES]
    y = df["label"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    candidates = {
        "random_forest": RandomForestClassifier(
            n_estimators=200, max_depth=8, min_samples_leaf=5,
            random_state=42, class_weight="balanced",
        ),
        "xgboost": XGBClassifier(
            n_estimators=200, max_depth=4, learning_rate=0.1,
            subsample=0.8, colsample_bytree=0.8,
            random_state=42, eval_metric="mlogloss",
        ),
    }

    # XGBoost needs integer-encoded labels, not strings — RandomForest doesn't care either way,
    # so we encode once and use it for both, keeping the comparison on identical footing.
    label_encoder = LabelEncoder()
    label_encoder.fit(LABEL_ORDER)
    y_train_enc = label_encoder.transform(y_train)
    y_test_enc = label_encoder.transform(y_test)

    results = {}
    fitted_pipelines = {}

    for name, estimator in candidates.items():
        pipeline = _build_pipeline(estimator)
        pipeline.fit(X_train, y_train_enc)
        metrics = _evaluate(pipeline, X_train, y_train_enc, X_test, y_test_enc)
        results[name] = metrics
        fitted_pipelines[name] = pipeline

        print(f"\n{name}:")
        print(f"  train accuracy: {metrics['train_accuracy']}")
        print(f"  test accuracy:  {metrics['test_accuracy']}")
        print(f"  test macro F1:  {metrics['test_macro_f1']}")
        if metrics["train_accuracy"] - metrics["test_accuracy"] > 0.15:
            print(f"  WARNING: {name} shows signs of overfitting (train >> test accuracy)")

    winner_name = max(results, key=lambda n: results[n]["test_macro_f1"])
    winner_pipeline = fitted_pipelines[winner_name]
    print(f"\nWinner: {winner_name} (highest test macro F1: {results[winner_name]['test_macro_f1']})")

    print("Computing SHAP explainability on the winning model...")
    shap_summary = _compute_shap_importance(winner_pipeline, X_test)

    print("\nTop features overall:")
    for item in shap_summary["global_importance"][:5]:
        print(f"  {item['feature']}: {item['mean_abs_shap']}")

    joblib.dump({
        "pipeline": winner_pipeline,
        "label_encoder": label_encoder,
        "algorithm": winner_name,
    }, MODEL_PATH)

    with open(METADATA_PATH, "w") as f:
        json.dump({
            "trained_at": datetime.now(timezone.utc).isoformat(),
            "n_rows": len(df),
            "winner": winner_name,
            "model_comparison": results,
            "shap_explainability": shap_summary,
            "feature_columns": NUMERIC_FEATURES + CATEGORICAL_FEATURES,
            "label_order": LABEL_ORDER,
        }, f, indent=2)

    print(f"\nSaved model to {MODEL_PATH}")
    print(f"Saved comparison + SHAP explainability to {METADATA_PATH}")
    return winner_pipeline


if __name__ == "__main__":
    train()