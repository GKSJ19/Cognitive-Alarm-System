"""
Trains the Behavior Pattern (anomaly detection) model.

Run: python -m app.ml.train_behavior_model

Unsupervised models have no accuracy/F1 to report — there's no ground truth
label for "was this day actually anomalous". So instead of a metric, this
script proves the model earns its place a different way: it compares
IsolationForest against a per-feature z-score baseline (the "smarter"
version of what the rule-based engine already sort of does) and reports
how much they actually agree.

If IsolationForest only flags what z-score already flags, it's not adding
anything, and that fact gets written to the metadata file, not hidden.
If it catches genuinely different days, that's the real justification for
using it over per-metric thresholds.
"""
import os
import json
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

from app.core.database import SessionLocal
from app.ml.behavior_features import build_behavior_frame, MIN_ROWS_TO_TRAIN

ARTIFACT_DIR = os.path.join(os.path.dirname(__file__), "artifacts")
MODEL_PATH = os.path.join(ARTIFACT_DIR, "behavior_model.joblib")
METADATA_PATH = os.path.join(ARTIFACT_DIR, "behavior_model_meta.json")

FEATURE_COLUMNS = [
    "snooze_count", "dismiss_latency_seconds",
    "wake_time_deviation_minutes", "challenge_accuracy_percent", "sleep_duration_mins",
]
CONTAMINATION = 0.05  # assume ~5% of days are genuinely anomalous — a starting assumption, not a law


def _zscore_baseline_flags(df: pd.DataFrame) -> np.ndarray:
    """Flags a day if ANY feature is >3 std devs from that user's own mean — the
    'smarter rule-based' comparison point, done per-user like the real behavior_service.py."""
    flagged = pd.Series(False, index=df.index)
    for col in FEATURE_COLUMNS:
        user_mean = df.groupby("user_id")[col].transform("mean")
        user_std = df.groupby("user_id")[col].transform("std").replace(0, np.nan)
        z = (df[col] - user_mean) / user_std
        flagged |= z.abs().fillna(0) > 3
    return flagged.values


def _explain_anomaly(row: pd.Series, user_stats: dict) -> str:
    """Per-feature z-score explanation — which features actually deviated for THIS
    user, THIS day, relative to their own history. Same spirit as SHAP: attribute
    the flag to specific features, not just 'the model said so'."""
    stats = user_stats.get(row["user_id"])
    if not stats:
        return "Not enough history for this user to explain."

    deviations = []
    for col in FEATURE_COLUMNS:
        mean, std = stats.get(col, (None, None))
        if mean is None or not std:
            continue
        z = (row[col] - mean) / std
        deviations.append((col, z))

    deviations.sort(key=lambda pair: abs(pair[1]), reverse=True)
    top = deviations[:2]
    parts = [f"{col} ({'above' if z > 0 else 'below'} their normal, z={z:.1f})" for col, z in top]
    return "Driven mainly by " + " and ".join(parts) if parts else "No strong single driver."


def train():
    os.makedirs(ARTIFACT_DIR, exist_ok=True)
    db = SessionLocal()
    try:
        df = build_behavior_frame(db)
    finally:
        db.close()

    if len(df) < MIN_ROWS_TO_TRAIN:
        print(
            f"Only {len(df)} user-day rows — need at least {MIN_ROWS_TO_TRAIN} to train "
            f"a model that means anything. Not training. The rule-based behavior_service.py "
            f"stays in charge until you have enough real data."
        )
        return None

    X = df[FEATURE_COLUMNS]

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    model = IsolationForest(
        n_estimators=200,
        contamination=CONTAMINATION,
        random_state=42,
    )
    model.fit(X_scaled)

    predictions = model.predict(X_scaled)  # -1 = anomaly, 1 = normal
    if_flags = predictions == -1
    zscore_flags = _zscore_baseline_flags(df)

    overlap = int((if_flags & zscore_flags).sum())
    if_only = int((if_flags & ~zscore_flags).sum())
    zscore_only = int((~if_flags & zscore_flags).sum())

    print(f"IsolationForest flagged: {int(if_flags.sum())} / {len(df)} days")
    print(f"Z-score baseline flagged: {int(zscore_flags.sum())} / {len(df)} days")
    print(f"Agreement (both flagged): {overlap}")
    print(f"IsolationForest caught, z-score missed: {if_only}  <- the multivariate cases")
    print(f"Z-score caught, IsolationForest missed: {zscore_only}")

    # Per-user mean/std for explainability, computed once and reused per flagged row
    user_stats = {}
    for user_id, group in df.groupby("user_id"):
        user_stats[user_id] = {col: (group[col].mean(), group[col].std()) for col in FEATURE_COLUMNS}

    example_explanations = []
    flagged_rows = df[if_flags]
    for _, row in flagged_rows.head(5).iterrows():
        example_explanations.append({
            "user_id": str(row["user_id"]),
            "date": str(row["date"]),
            "explanation": _explain_anomaly(row, user_stats),
        })

    joblib.dump({"model": model, "scaler": scaler, "feature_columns": FEATURE_COLUMNS}, MODEL_PATH)

    with open(METADATA_PATH, "w") as f:
        json.dump({
            "trained_at": datetime.now(timezone.utc).isoformat(),
            "n_rows": len(df),
            "contamination": CONTAMINATION,
            "isolation_forest_flagged": int(if_flags.sum()),
            "zscore_baseline_flagged": int(zscore_flags.sum()),
            "agreement": overlap,
            "isolation_forest_unique_catches": if_only,
            "zscore_unique_catches": zscore_only,
            "example_explanations": example_explanations,
            "feature_columns": FEATURE_COLUMNS,
        }, f, indent=2)

    print(f"\nSaved model to {MODEL_PATH}")
    print(f"Saved comparison + explainability to {METADATA_PATH}")
    return model


if __name__ == "__main__":
    train()