"""
Seeds training data for the Difficulty model by actually running the app's
real logic — generate_challenge(), calculate_difficulty(), process_attempt()
— against simulated users, instead of hand-writing fake feature rows.

This matters: the resulting data reflects your actual adaptive-difficulty
loop (a synthetic user who's improving really does get harder challenges
over time, because calculate_difficulty() is reading their real accumulated
ChallengeAttempt history as it goes). What's fake is only the "did they get
it right and how fast" — everything downstream of that is the real app.

Every seeded user's email ends in @icap-seed.local so this data is easy to
find and wipe later. Run cleanup() before your real demo if you don't want
synthetic users showing up in your admin dashboard.

Run: python -m app.ml.seed_synthetic_data
"""
import random
from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import sessionmaker
from app.core.database import engine
from app.models.user import User
from app.models.alarm import Alarm, VerificationMethod
from app.models.alarm_trigger import AlarmTrigger, VerificationStatus
from app.models.challenge_attempt import ChallengeAttempt
from app.services.verification_service import start_verification, process_attempt

SeedSession = sessionmaker(autocommit=False, autoflush=False, bind=engine, expire_on_commit=False)

SEED_DOMAIN = "icap-seed.local"
NUM_SYNTHETIC_USERS = 15
TRIGGERS_PER_USER = 60
DAYS_BACK = 90

DIFFICULTY_INDEX = {"beginner": 0, "easy": 1, "medium": 2, "hard": 3, "expert": 4}


def _make_synthetic_users(db):
    users = []
    for i in range(NUM_SYNTHETIC_USERS):
        email = f"synthetic_seed_{i}@{SEED_DOMAIN}"
        existing = db.query(User).filter(User.email == email).first()
        if existing:
            users.append((existing, random.uniform(0.3, 0.95)))
            continue

        skill_level = random.uniform(0.3, 0.95)
        user = User(
            name=f"Synthetic User {i}",
            email=email,
            password_hash=None,
            auth_provider="seed",
            role="user",
            is_active=True,
        )
        db.add(user)
        db.commit()
        db.refresh(user)
        users.append((user, skill_level))
    return users


def _make_alarm_for(db, user):
    alarm = Alarm(
        user_id=user.id,
        time=datetime.now().time(),
        label="Synthetic seed alarm",
        verification_method=VerificationMethod.puzzle,
        verification_target=1,
        is_active=True,
    )
    db.add(alarm)
    db.commit()
    db.refresh(alarm)
    return alarm


def _simulate_answer(skill_level: float, difficulty: str):
    """Harder difficulty -> lower success chance and longer time, scaled by this user's skill."""
    idx = DIFFICULTY_INDEX.get(difficulty, 2)
    prob_correct = min(0.97, max(0.05, skill_level - (idx - 2) * 0.22))
    is_correct = random.random() < prob_correct

    base_time = 8 + idx * 6
    skill_time_factor = 1.5 - 1.0 * skill_level
    time_taken = max(3, int(random.gauss(base_time * skill_time_factor, base_time * 0.2)))
    return is_correct, time_taken


def seed():
    db = SeedSession()
    total_attempts = 0
    try:
        users = _make_synthetic_users(db)
        print(f"Using {len(users)} synthetic users")

        for user, skill_level in users:
            alarm = _make_alarm_for(db, user)

            for t in range(TRIGGERS_PER_USER):
                if t % 5 == 0:
                    print(f"    ...{user.email}: trigger {t + 1}/{TRIGGERS_PER_USER}", flush=True)

                days_ago = DAYS_BACK - int((t / TRIGGERS_PER_USER) * DAYS_BACK)
                triggered_at = datetime.now(timezone.utc) - timedelta(days=days_ago, minutes=random.randint(0, 59))

                trigger = AlarmTrigger(
                    alarm_id=alarm.id,
                    user_id=user.id,
                    triggered_at=triggered_at,
                    verification_status=VerificationStatus.pending,
                )
                db.add(trigger)
                db.commit()
                db.refresh(trigger)

                challenge = start_verification(db, user, alarm, trigger)

                guard = 0
                while trigger.verification_status == VerificationStatus.in_progress or guard == 0:
                    guard += 1
                    is_correct, time_taken = _simulate_answer(skill_level, challenge.difficulty.value)

                    db.add(ChallengeAttempt(
                        alarm_trigger_id=trigger.id,
                        challenge_id=challenge.id,
                        attempt_number=(trigger.total_attempts or 0) + 1,
                        is_correct=is_correct,
                        time_taken_seconds=time_taken,
                        answered_at=triggered_at + timedelta(seconds=time_taken * guard),
                    ))
                    total_attempts += 1

                    _, status, next_challenge, _ = process_attempt(db, user, alarm, trigger, challenge, is_correct)

                    if next_challenge is None:
                        break
                    challenge = next_challenge

                    if guard > 8:
                        break

            print(f"  seeded {TRIGGERS_PER_USER} triggers for {user.email}")

        print(f"Done. {total_attempts} total ChallengeAttempt rows created across {len(users)} users.")
        print("Next: python -m app.ml.train_difficulty_model")
    finally:
        db.close()


def cleanup():
    """Removes all seeded synthetic users and their data. Run before a real demo."""
    db = SeedSession()
    try:
        seed_users = db.query(User).filter(User.email.like(f"%@{SEED_DOMAIN}")).all()
        user_ids = [u.id for u in seed_users]
        if not user_ids:
            print("No synthetic seed users found.")
            return

        alarm_ids = [a.id for a in db.query(Alarm).filter(Alarm.user_id.in_(user_ids)).all()]
        trigger_ids = [t.id for t in db.query(AlarmTrigger).filter(AlarmTrigger.user_id.in_(user_ids)).all()]

        db.query(ChallengeAttempt).filter(ChallengeAttempt.alarm_trigger_id.in_(trigger_ids)).delete(synchronize_session=False)
        db.query(AlarmTrigger).filter(AlarmTrigger.id.in_(trigger_ids)).delete(synchronize_session=False)
        db.query(Alarm).filter(Alarm.id.in_(alarm_ids)).delete(synchronize_session=False)
        db.query(User).filter(User.id.in_(user_ids)).delete(synchronize_session=False)
        db.commit()
        print(f"Removed {len(user_ids)} synthetic users and all their seeded data.")
    finally:
        db.close()


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "cleanup":
        cleanup()
    else:
        seed()