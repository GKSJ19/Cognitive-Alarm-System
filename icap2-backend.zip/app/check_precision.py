from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split

from app.core.database import SessionLocal
from app.ml.recommendation_features import build_training_frame, NUMERIC_FEATURES, CATEGORICAL_FEATURES
import joblib
from app.ml.train_recommendation_model import MODEL_PATH

db = SessionLocal()
df = build_training_frame(db)
db.close()

X = df[NUMERIC_FEATURES + CATEGORICAL_FEATURES]
y = df["label"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

bundle = joblib.load(MODEL_PATH)
pipeline = bundle["explainer_pipeline"]  # the uncalibrated RandomForest pipeline

preds = pipeline.predict(X_test)
print(classification_report(y_test, preds, target_names=["incorrect", "correct"]))