from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_user, require_role
from app.services.dashboard_service import get_user_dashboard, get_coach_dashboard, get_admin_dashboard

router = APIRouter()


@router.get("/user")
def user_dashboard(
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    return get_user_dashboard(current_user, db)


@router.get("/coach")
def coach_dashboard(
    payload: dict = Depends(require_role("wellness_coach")),
    db: Session = Depends(get_db),
):
    return get_coach_dashboard(payload["sub"], db)


@router.get("/admin")
def admin_dashboard(
    payload: dict = Depends(require_role("administrator")),
    db: Session = Depends(get_db),
):
    return get_admin_dashboard(db)