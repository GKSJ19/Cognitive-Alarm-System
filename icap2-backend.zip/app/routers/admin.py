from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from uuid import UUID

from app.core.database import get_db
from app.core.security import require_role
from app.models.user import User
from app.models.coach_assignment import CoachAssignment
from app.services.dashboard_service import (
    _platform_analytics_summary,
    _recommendation_monitoring_summary,
    _system_reports_summary,
)

router = APIRouter()

ALLOWED_ROLES = {"user", "wellness_coach", "administrator"}


class RoleUpdate(BaseModel):
    role: str


class CoachAssignmentCreate(BaseModel):
    coach_id: UUID
    user_id: UUID


# ---------- User management ----------

@router.get("/users")
def list_all_users(
    payload: dict = Depends(require_role("administrator")),
    db: Session = Depends(get_db),
):
    users = db.query(User).all()
    return [
        {"id": str(u.id), "name": u.name, "email": u.email, "role": u.role, "is_active": u.is_active}
        for u in users
    ]


@router.patch("/users/{user_id}/role")
def change_user_role(
    user_id: UUID,
    body: RoleUpdate,
    payload: dict = Depends(require_role("administrator")),
    db: Session = Depends(get_db),
):
    if body.role not in ALLOWED_ROLES:
        raise HTTPException(status_code=400, detail=f"role must be one of {sorted(ALLOWED_ROLES)}")

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.role = body.role
    db.commit()
    db.refresh(user)
    return {"id": str(user.id), "role": user.role}


@router.patch("/users/{user_id}/deactivate")
def deactivate_user(
    user_id: UUID,
    payload: dict = Depends(require_role("administrator")),
    db: Session = Depends(get_db),
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if str(user.id) == payload.get("sub"):
        raise HTTPException(status_code=400, detail="You cannot deactivate your own account")

    user.is_active = False
    db.commit()
    db.refresh(user)
    return {"id": str(user.id), "is_active": user.is_active}


@router.patch("/users/{user_id}/activate")
def activate_user(
    user_id: UUID,
    payload: dict = Depends(require_role("administrator")),
    db: Session = Depends(get_db),
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.is_active = True
    db.commit()
    db.refresh(user)
    return {"id": str(user.id), "is_active": user.is_active}


# ---------- Coach assignment management ----------
# (needed to actually populate the wellness_coach dashboard)

@router.post("/coach-assignments")
def assign_coach(
    body: CoachAssignmentCreate,
    payload: dict = Depends(require_role("administrator")),
    db: Session = Depends(get_db),
):
    coach = db.query(User).filter(User.id == body.coach_id, User.role == "wellness_coach").first()
    if not coach:
        raise HTTPException(status_code=400, detail="coach_id must belong to a user with role 'wellness_coach'")

    user = db.query(User).filter(User.id == body.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="user_id not found")

    existing = db.query(CoachAssignment).filter(
        CoachAssignment.coach_id == body.coach_id, CoachAssignment.user_id == body.user_id
    ).first()
    if existing:
        raise HTTPException(status_code=409, detail="This assignment already exists")

    assignment = CoachAssignment(coach_id=body.coach_id, user_id=body.user_id)
    db.add(assignment)
    db.commit()
    db.refresh(assignment)
    return {
        "id": str(assignment.id),
        "coach_id": str(assignment.coach_id),
        "user_id": str(assignment.user_id),
        "assigned_at": assignment.assigned_at,
    }


@router.get("/coach-assignments")
def list_coach_assignments(
    payload: dict = Depends(require_role("administrator")),
    db: Session = Depends(get_db),
):
    rows = db.query(CoachAssignment).all()
    return [
        {
            "id": str(a.id),
            "coach_id": str(a.coach_id),
            "user_id": str(a.user_id),
            "assigned_at": a.assigned_at,
        }
        for a in rows
    ]


@router.delete("/coach-assignments/{assignment_id}")
def remove_coach_assignment(
    assignment_id: UUID,
    payload: dict = Depends(require_role("administrator")),
    db: Session = Depends(get_db),
):
    assignment = db.query(CoachAssignment).filter(CoachAssignment.id == assignment_id).first()
    if not assignment:
        raise HTTPException(status_code=404, detail="Assignment not found")

    db.delete(assignment)
    db.commit()
    return {"message": "Coach assignment removed"}


# ---------- Platform analytics / recommendation monitoring / system reports ----------
# Granular reads — the same data is also available combined at GET /dashboard/admin.

@router.get("/analytics/platform")
def platform_analytics(
    payload: dict = Depends(require_role("administrator")),
    db: Session = Depends(get_db),
):
    return _platform_analytics_summary(db)


@router.get("/analytics/recommendations")
def recommendation_monitoring(
    payload: dict = Depends(require_role("administrator")),
    db: Session = Depends(get_db),
):
    return _recommendation_monitoring_summary(db)


@router.get("/reports/system")
def system_reports(
    payload: dict = Depends(require_role("administrator")),
    db: Session = Depends(get_db),
):
    return _system_reports_summary(db)