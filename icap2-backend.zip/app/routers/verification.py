from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.alarm import Alarm
from app.models.alarm_trigger import AlarmTrigger, VerificationStatus
from app.models.challenge import Challenge
from app.models.challenge_attempt import ChallengeAttempt
from app.models.user import User
from app.schema.verification import (
    TriggerAlarmRequest, TriggerAlarmResponse,
    VerifyAttemptRequest, VerifyAttemptResponse,
    SnoozeRequest, SnoozeResponse,
)
from app.services.verification_service import start_verification, process_attempt
from app.services.dispatcher_service import check_and_fire_alarms

router = APIRouter()


@router.post("/trigger", response_model=TriggerAlarmResponse)
def trigger_alarm(
    payload: TriggerAlarmRequest,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    alarm = db.query(Alarm).filter(Alarm.id == payload.alarm_id, Alarm.user_id == current_user).first()
    if not alarm:
        raise HTTPException(status_code=404, detail="Alarm not found")

    user = db.query(User).filter(User.id == current_user).first()

    trigger = AlarmTrigger(
        alarm_id=payload.alarm_id,
        user_id=current_user,
        verification_status=VerificationStatus.pending,
    )
    db.add(trigger)
    db.commit()
    db.refresh(trigger)

    challenge = start_verification(db, user, alarm, trigger)

    return {
        "trigger_id": trigger.id,
        "challenge_id": challenge.id,
        "category": challenge.type.value,
        "question": challenge.question,
        "verification_method": alarm.verification_method.value,
        "verification_target": alarm.verification_target,
        "debug_answer": challenge.correct_answer,
    }


@router.post("/attempt", response_model=VerifyAttemptResponse)
def verify_attempt(
    payload: VerifyAttemptRequest,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    trigger = db.query(AlarmTrigger).filter(
        AlarmTrigger.id == payload.trigger_id, AlarmTrigger.user_id == current_user
    ).first()
    if not trigger:
        raise HTTPException(status_code=404, detail="Trigger not found")

    if str(trigger.current_challenge_id) != str(payload.challenge_id):
        raise HTTPException(status_code=400, detail="That challenge is no longer active for this trigger")

    challenge = db.query(Challenge).filter(Challenge.id == payload.challenge_id).first()
    if not challenge:
        raise HTTPException(status_code=404, detail="Challenge not found")

    alarm = db.query(Alarm).filter(Alarm.id == trigger.alarm_id).first()
    user = db.query(User).filter(User.id == current_user).first()

    is_correct = payload.submitted_answer.strip().lower() == challenge.correct_answer.strip().lower()

    db.add(ChallengeAttempt(
        alarm_trigger_id=trigger.id,
        challenge_id=challenge.id,
        attempt_number=(trigger.total_attempts or 0) + 1,
        is_correct=is_correct,
    ))

    final_correct, status, next_challenge, extra = process_attempt(db, user, alarm, trigger, challenge, is_correct)

    return {
        "is_correct": final_correct,
        "verification_status": status,
        "total_attempts": trigger.total_attempts,
        "current_step": trigger.current_step,
        "next_challenge_id": next_challenge.id if next_challenge else None,
        "next_question": next_challenge.question if next_challenge else None,
        "extra": extra,
    }


@router.post("/snooze", response_model=SnoozeResponse)
def snooze_alarm(
    payload: SnoozeRequest,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    trigger = db.query(AlarmTrigger).filter(
        AlarmTrigger.id == payload.trigger_id,
        AlarmTrigger.user_id == current_user,
    ).first()
    if not trigger:
        raise HTTPException(status_code=404, detail="Trigger not found")

    alarm = db.query(Alarm).filter(Alarm.id == trigger.alarm_id).first()
    max_snoozes = alarm.max_snoozes if alarm else 3

    if trigger.snooze_count >= max_snoozes:
        raise HTTPException(
            status_code=400,
            detail=f"Max snoozes ({max_snoozes}) reached — you have to solve the challenge now",
        )

    trigger.snooze_count += 1
    trigger.verification_status = VerificationStatus.pending
    db.commit()
    db.refresh(trigger)

    remaining = max_snoozes - trigger.snooze_count
    return {
        "snooze_count": trigger.snooze_count,
        "max_snoozes": max_snoozes,
        "snoozes_remaining": remaining,
        "can_still_snooze": remaining > 0,
    }


@router.post("/dispatcher/run-once")
def run_dispatcher_once():
    """Testing only — manually runs one dispatcher check instead of waiting for the timer."""
    fired = check_and_fire_alarms()
    return {"fired": fired}