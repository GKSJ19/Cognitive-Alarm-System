from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy.sql import func
from pydantic import BaseModel

from app.core.database import get_db
from app.core.security import get_current_user, require_role
from app.models.notification import Notification
from app.services.notification_service import broadcast_announcement

router = APIRouter()


class AnnouncementIn(BaseModel):
    message: str


@router.get("")
def list_notifications(
    unread_only: bool = Query(False),
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    q = db.query(Notification).filter(Notification.user_id == current_user)
    if unread_only:
        q = q.filter(Notification.read_at.is_(None))

    total = q.count()
    items = q.order_by(Notification.sent_at.desc()).offset(offset).limit(limit).all()

    return {
        "total": total,
        "unread_count": db.query(Notification).filter(
            Notification.user_id == current_user, Notification.read_at.is_(None)
        ).count(),
        "notifications": [
            {
                "id": str(n.id),
                "type": n.type,
                "message": n.message,
                "sent_at": n.sent_at,
                "read_at": n.read_at,
            }
            for n in items
        ],
    }


@router.get("/unread-count")
def unread_count(
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    count = db.query(Notification).filter(
        Notification.user_id == current_user, Notification.read_at.is_(None)
    ).count()
    return {"unread_count": count}


@router.patch("/read-all")
def mark_all_read(
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    updated = db.query(Notification).filter(
        Notification.user_id == current_user, Notification.read_at.is_(None)
    ).update({"read_at": func.now()}, synchronize_session=False)
    db.commit()
    return {"marked_read": updated}


@router.patch("/{notification_id}/read")
def mark_read(
    notification_id: str,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    notif = db.query(Notification).filter(
        Notification.id == notification_id, Notification.user_id == current_user
    ).first()
    if not notif:
        raise HTTPException(status_code=404, detail="Notification not found")

    if notif.read_at is None:
        notif.read_at = func.now()
        db.commit()
        db.refresh(notif)

    return {"id": str(notif.id), "read_at": notif.read_at}


@router.delete("/{notification_id}")
def delete_notification(
    notification_id: str,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    notif = db.query(Notification).filter(
        Notification.id == notification_id, Notification.user_id == current_user
    ).first()
    if not notif:
        raise HTTPException(status_code=404, detail="Notification not found")

    db.delete(notif)
    db.commit()
    return {"message": "Notification deleted"}


@router.post("/announcement")
def send_platform_announcement(
    body: AnnouncementIn,
    payload: dict = Depends(require_role("administrator")),
    db: Session = Depends(get_db),
):
    count = broadcast_announcement(db, body.message)
    return {"message": "Announcement sent", "recipients": count}