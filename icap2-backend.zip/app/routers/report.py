import os
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from pydantic import BaseModel

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.report import Report, ReportType, ReportFormat
from app.services.report_service import generate_report, REPORTS_DIR

router = APIRouter()


class ReportRequest(BaseModel):
    report_type: ReportType
    format: ReportFormat
    days: int = 7


@router.post("/generate")
def create_report(
    body: ReportRequest,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if body.days < 1 or body.days > 365:
        raise HTTPException(status_code=400, detail="days must be between 1 and 365")

    report = generate_report(current_user, db, body.report_type.value, body.format.value, body.days)

    return {
        "id": str(report.id),
        "report_type": report.report_type.value,
        "format": report.format.value,
        "generated_at": report.generated_at,
        "download_url": f"/reports/{report.id}/download",
    }


@router.get("")
def list_reports(
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    q = db.query(Report).filter(Report.user_id == current_user)
    total = q.count()
    items = q.order_by(Report.generated_at.desc()).offset(offset).limit(limit).all()

    return {
        "total": total,
        "reports": [
            {
                "id": str(r.id),
                "report_type": r.report_type.value,
                "format": r.format.value,
                "generated_at": r.generated_at,
                "download_url": f"/reports/{r.id}/download",
            }
            for r in items
        ],
    }


@router.get("/{report_id}/download")
def download_report(
    report_id: str,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    report = db.query(Report).filter(
        Report.id == report_id, Report.user_id == current_user
    ).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    path = os.path.join(REPORTS_DIR, report.file_url)
    if not os.path.exists(path):
        raise HTTPException(status_code=410, detail="Report file no longer exists — please regenerate it")

    media_type = "application/pdf" if report.format == ReportFormat.pdf else \
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    download_name = f"{report.report_type.value}_report.{'pdf' if report.format == ReportFormat.pdf else 'xlsx'}"

    return FileResponse(path, media_type=media_type, filename=download_name)