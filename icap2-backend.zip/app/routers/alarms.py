from datetime import datetime, timezone as dt_timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from uuid import UUID
from zoneinfo import ZoneInfo

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.alarm import Alarm
from app.models.user import User
from app.schema.alarm import AlarmCreateRequest, AlarmUpdateRequest, AlarmResponse
from app.services.alarm_schedule_service import compute_next_trigger

router = APIRouter()


@router.post("/", response_model=AlarmResponse)
def create_alarm(
    payload: AlarmCreateRequest,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    alarm = Alarm(
        user_id=current_user,
        time=payload.time,
        alarm_type=payload.alarm_type,
        days_of_week=payload.days_of_week,
        specific_date=payload.specific_date,
        timezone_override=payload.timezone_override,
        label=payload.label,
    )
    db.add(alarm)
    db.commit()
    db.refresh(alarm)
    return alarm


@router.get("/", response_model=List[AlarmResponse])
def list_alarms(
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    # Show every alarm that hasn't been deleted — including disabled ones,
    # so the on/off toggle in the UI has something to show as "off".
    return (
        db.query(Alarm)
        .filter(Alarm.user_id == current_user, Alarm.deleted_at.is_(None))
        .all()
    )


@router.put("/{alarm_id}", response_model=AlarmResponse)
def update_alarm(
    alarm_id: UUID,
    payload: AlarmUpdateRequest,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    alarm = (
        db.query(Alarm)
        .filter(Alarm.id == alarm_id, Alarm.user_id == current_user, Alarm.deleted_at.is_(None))
        .first()
    )
    if not alarm:
        raise HTTPException(status_code=404, detail="Alarm not found")

    update_data = payload.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(alarm, field, value)

    db.commit()
    db.refresh(alarm)
    return alarm


@router.delete("/{alarm_id}")
def delete_alarm(
    alarm_id: UUID,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    alarm = (
        db.query(Alarm)
        .filter(Alarm.id == alarm_id, Alarm.user_id == current_user, Alarm.deleted_at.is_(None))
        .first()
    )
    if not alarm:
        raise HTTPException(status_code=404, detail="Alarm not found")

    # Soft-delete: deleted_at is separate from is_active (the on/off toggle),
    # so a disabled alarm and a deleted alarm are no longer the same state.
    alarm.deleted_at = datetime.now(dt_timezone.utc)
    alarm.is_active = False
    db.commit()
    return {"message": "Alarm deleted"}


@router.get("/{alarm_id}/next-trigger")
def get_next_trigger(
    alarm_id: UUID,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    alarm = (
        db.query(Alarm)
        .filter(Alarm.id == alarm_id, Alarm.user_id == current_user, Alarm.deleted_at.is_(None))
        .first()
    )
    if not alarm:
        raise HTTPException(status_code=404, detail="Alarm not found")

    user = db.query(User).filter(User.id == current_user).first()
    tz_name = alarm.timezone_override or user.timezone or "UTC"
    alarm_type_value = alarm.alarm_type.value if hasattr(alarm.alarm_type, "value") else alarm.alarm_type

    try:
        next_trigger = compute_next_trigger(
            alarm.time, alarm_type_value, alarm.days_of_week, alarm.specific_date, tz_name
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    return {
        "alarm_id": str(alarm.id),
        "timezone": tz_name,
        "next_trigger_local": next_trigger.isoformat(),
        "next_trigger_utc": next_trigger.astimezone(ZoneInfo("UTC")).isoformat(),
    }