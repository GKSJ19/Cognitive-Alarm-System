from fastapi import APIRouter, Depends

from app.core.security import require_role
from app.core.metrics import get_snapshot

router = APIRouter()

@router.get("/ping")
def ping():
    return {"status": "ok"}

@router.get("/system")
def system_metrics(payload: dict = Depends(require_role("administrator"))):
    return get_snapshot()