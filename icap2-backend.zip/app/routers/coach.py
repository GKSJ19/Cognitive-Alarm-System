from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from uuid import UUID

from app.core.database import get_db
from app.core.security import require_role
from app.services.coach_service import get_assigned_users, get_user_detail

router = APIRouter()


@router.get("/users")
def list_my_assigned_users(
    payload: dict = Depends(require_role("wellness_coach")),
    db: Session = Depends(get_db),
):
    users = get_assigned_users(payload["sub"], db)
    return [{"id": str(u.id), "name": u.name, "email": u.email} for u in users]


@router.get("/users/{user_id}")
def get_assigned_user_detail(
    user_id: UUID,
    payload: dict = Depends(require_role("wellness_coach")),
    db: Session = Depends(get_db),
):
    return get_user_detail(payload["sub"], user_id, db)