from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.goal_metric import GoalMetric, GoalType
from app.schema.goal import GoalMetricLogRequest, GoalMetricResponse

router = APIRouter()

@router.post("/log", response_model=GoalMetricResponse)
def log_goal_metric(
    payload: GoalMetricLogRequest,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    try:
        goal_type = GoalType(payload.goal_type)
    except ValueError:
        raise HTTPException(status_code=422, detail=f"goal_type must be one of: {[g.value for g in GoalType]}")

    entry = GoalMetric(
        user_id=current_user,
        date=payload.date,
        goal_type=goal_type,
        metric_label=payload.metric_label,
        metric_value=payload.metric_value,
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry

@router.get("/history", response_model=List[GoalMetricResponse])
def get_goal_history(
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    return (
        db.query(GoalMetric)
        .filter(GoalMetric.user_id == current_user)
        .order_by(GoalMetric.date.desc())
        .limit(90)
        .all()
    )

@router.delete("/{metric_id}")
def delete_goal_metric(
    metric_id: str,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    entry = (
        db.query(GoalMetric)
        .filter(GoalMetric.id == metric_id, GoalMetric.user_id == current_user)
        .first()
    )
    if not entry:
        raise HTTPException(status_code=404, detail="Not found")
    db.delete(entry)
    db.commit()
    return {"message": "Deleted"}