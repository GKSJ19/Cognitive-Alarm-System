from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from uuid import UUID

from app.core.database import get_db
from app.core.security import get_current_user
from app.schema.recommendation import RecommendationHistoryItem
from app.services.recommendation_service import (
    generate_recommendations,
    get_recommendation_history,
    mark_read,
)

router = APIRouter()


@router.get("")
def get_recommendations(
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Generates fresh recommendations (personalized challenge category via the
    trained ML model, plus rule-based sleep/wake-up/habit/productivity guidance)
    and persists them to history."""
    return generate_recommendations(current_user, db)


@router.get("/history", response_model=list[RecommendationHistoryItem])
def recommendation_history(
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    return get_recommendation_history(current_user, db)


@router.patch("/{recommendation_id}/read", response_model=RecommendationHistoryItem)
def mark_recommendation_read(
    recommendation_id: UUID,
    current_user: str = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    rec = mark_read(str(recommendation_id), current_user, db)
    if not rec:
        raise HTTPException(status_code=404, detail="Recommendation not found")
    return rec