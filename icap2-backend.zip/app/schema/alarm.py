from pydantic import BaseModel, model_validator
from datetime import time as time_type, date as date_type
from typing import Optional, List
from uuid import UUID


class AlarmCreateRequest(BaseModel):
    time: time_type
    alarm_type: str = "daily"
    days_of_week: Optional[List[int]] = None
    specific_date: Optional[date_type] = None
    timezone_override: Optional[str] = None
    label: Optional[str] = None
    max_snoozes: Optional[int] = 3
    snooze_duration_mins: Optional[int] = 5

    @model_validator(mode="after")
    def check_one_time_has_date(self):
        if self.alarm_type == "one_time" and not self.specific_date:
            raise ValueError("one_time alarms require specific_date")
        if self.alarm_type != "one_time" and self.specific_date:
            raise ValueError("specific_date is only valid for one_time alarms")
        return self


class AlarmUpdateRequest(BaseModel):
    time: Optional[time_type] = None
    alarm_type: Optional[str] = None
    days_of_week: Optional[List[int]] = None
    specific_date: Optional[date_type] = None
    timezone_override: Optional[str] = None
    label: Optional[str] = None
    is_active: Optional[bool] = None
    max_snoozes: Optional[int] = None
    snooze_duration_mins: Optional[int] = None


class AlarmResponse(BaseModel):
    id: UUID
    time: time_type
    alarm_type: str
    days_of_week: Optional[List[int]] = None
    specific_date: Optional[date_type] = None
    timezone_override: Optional[str] = None
    is_active: bool
    label: Optional[str] = None
    max_snoozes: int
    snooze_duration_mins: int

    class Config:
        from_attributes = True
verification_method: Optional[str] = "puzzle"
verification_target: Optional[int] = 1
challenge_time_limit_secs: Optional[int] = None