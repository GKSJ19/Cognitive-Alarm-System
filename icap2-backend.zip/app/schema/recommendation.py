from datetime import datetime
from uuid import UUID
from pydantic import BaseModel


class RecommendationHistoryItem(BaseModel):
    id: UUID
    category: str | None
    message: str
    is_read: bool
    created_at: datetime

    class Config:
        from_attributes = True