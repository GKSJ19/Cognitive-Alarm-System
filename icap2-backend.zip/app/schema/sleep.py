from pydantic import BaseModel, Field
from datetime import date as date_type, datetime
from typing import Optional
from uuid import UUID

class SleepLogCreateRequest(BaseModel):
    date: date_type
    sleep_start: Optional[datetime] = None
    sleep_end: Optional[datetime] = None
    duration_mins: Optional[int] = None
    quality: Optional[int] = Field(default=None, ge=1, le=5)
    source: str = "manual"

class SleepLogResponse(BaseModel):
    id: UUID
    date: date_type
    sleep_start: Optional[datetime] = None
    sleep_end: Optional[datetime] = None
    duration_mins: Optional[int] = None
    quality: Optional[int] = None
    source: str

    class Config:
        from_attributes = True