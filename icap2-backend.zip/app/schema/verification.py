from pydantic import BaseModel
from uuid import UUID
from typing import Optional

class TriggerAlarmRequest(BaseModel):
    alarm_id: UUID

class TriggerAlarmResponse(BaseModel):
    trigger_id: UUID
    challenge_id: UUID
    category: str
    question: str
    verification_method: str
    verification_target: int
    debug_answer: Optional[str] = None

class VerifyAttemptRequest(BaseModel):
    trigger_id: UUID
    challenge_id: UUID
    submitted_answer: str

class VerifyAttemptResponse(BaseModel):
    is_correct: bool
    verification_status: str
    total_attempts: int
    current_step: int
    next_challenge_id: Optional[UUID] = None
    next_question: Optional[str] = None
    extra: dict = {}

class SnoozeRequest(BaseModel):
    trigger_id: UUID

class SnoozeResponse(BaseModel):
    snooze_count: int
    max_snoozes: int
    snoozes_remaining: int
    can_still_snooze: bool