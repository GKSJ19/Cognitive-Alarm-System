from pydantic import BaseModel, Field
from datetime import date as date_type
from typing import Optional
from uuid import UUID

class GoalMetricLogRequest(BaseModel):
    date: date_type
    goal_type: str  # "study" | "work" | "fitness"
    metric_label: str = Field(max_length=60)
    metric_value: float

class GoalMetricResponse(BaseModel):
    id: UUID
    date: date_type
    goal_type: str
    metric_label: str
    metric_value: float

    class Config:
        from_attributes = True