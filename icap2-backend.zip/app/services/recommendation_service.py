from datetime import datetime, timedelta
from sqlalchemy.orm import Session

from app.models.challenge_attempt import ChallengeAttempt
from app.models.challenge import Challenge
from app.models.alarm_trigger import AlarmTrigger
from app.models.user import User
from app.models.recommendation import Recommendation
from app.services.habit_score_service import calculate_habit_score
from app.services.behavior_service import get_behavior_patterns
from app.services.challenge_service.engine import CATEGORY_MODULES
from app.ml.predict_recommendation import predict_success_probability
from app.ml.recommendation_features import DIFFICULTY_ORDER, ROLLING_WINDOW
from datetime import timezone as _tz

ALL_CATEGORIES = list(CATEGORY_MODULES.keys())


# ---------- Personalized challenge recommendation (the ML-backed piece) ----------

def _build_live_features(user_id: str, db: Session, category: str) -> dict:
    """Same shape as recommendation_features.py's training rows, computed from the
    user's CURRENT history — this is what gets fed to the model at inference time."""
    attempts = (
        db.query(ChallengeAttempt, Challenge)
        .join(Challenge, ChallengeAttempt.challenge_id == Challenge.id)
        .join(AlarmTrigger, ChallengeAttempt.alarm_trigger_id == AlarmTrigger.id)
        .filter(AlarmTrigger.user_id == user_id, ChallengeAttempt.answered_at.isnot(None))
        .order_by(ChallengeAttempt.answered_at.desc())
        .limit(50)
        .all()
    )

    now = datetime.now(_tz.utc)

    if not attempts:
        return {
            "overall_rolling_accuracy": 50.0, "same_category_accuracy": -1,
            "same_category_attempts": 0, "current_difficulty": 2,
            "challenge_type": category, "streak": 0,
            "hour_of_day": now.hour, "day_of_week": now.weekday(),
            "days_since_category_attempt": -1, "category_diversity": 0,
            "total_attempts_so_far": 0, "difficulty_trend": 0.0,
        }

    recent_all = attempts[:ROLLING_WINDOW]
    overall_rolling_accuracy = sum(1 for a, c in recent_all if a.is_correct) / len(recent_all) * 100

    same_cat = [(a, c) for a, c in attempts if (c.type.value if hasattr(c.type, "value") else c.type) == category]
    if same_cat:
        same_cat_recent = same_cat[:ROLLING_WINDOW]
        same_category_accuracy = sum(1 for a, c in same_cat_recent if a.is_correct) / len(same_cat_recent) * 100
        same_category_attempts = len(same_cat)
        last_difficulty = same_cat[0][1].difficulty
        last_difficulty = last_difficulty.value if hasattr(last_difficulty, "value") else last_difficulty
        days_since_category_attempt = (now - same_cat[0][0].answered_at).total_seconds() / 86400

        if len(same_cat) >= 2:
            diffs = [DIFFICULTY_ORDER.get(c.difficulty.value if hasattr(c.difficulty, "value") else c.difficulty, 2) for a, c in same_cat]
            diffs = list(reversed(diffs))  # oldest first, matches training-time ordering
            half = max(1, len(diffs) // 2)
            difficulty_trend = (sum(diffs[-half:]) / half) - (sum(diffs[:len(diffs) - half]) / max(1, len(diffs) - half))
        else:
            difficulty_trend = 0.0
    else:
        same_category_accuracy = -1
        same_category_attempts = 0
        last_difficulty = "medium"
        days_since_category_attempt = -1
        difficulty_trend = 0.0

    streak = 0
    for a, c in recent_all:
        if a.is_correct:
            streak += 1
        else:
            break

    distinct_categories = len({c.type.value if hasattr(c.type, "value") else c.type for a, c in attempts})

    return {
        "overall_rolling_accuracy": overall_rolling_accuracy,
        "same_category_accuracy": same_category_accuracy,
        "same_category_attempts": same_category_attempts,
        "current_difficulty": DIFFICULTY_ORDER.get(last_difficulty, 2),
        "challenge_type": category,
        "streak": streak,
        "hour_of_day": now.hour,
        "day_of_week": now.weekday(),
        "days_since_category_attempt": round(days_since_category_attempt, 2),
        "category_diversity": distinct_categories,
        "total_attempts_so_far": len(attempts),
        "difficulty_trend": round(float(difficulty_trend), 2),
    }


def _rule_based_category_scores(user_id: str, db: Session) -> dict:
    """Fallback when the model isn't trained yet: per-category accuracy computed
    directly, same idea as the ML model would learn, just without the model."""
    attempts = (
        db.query(ChallengeAttempt, Challenge)
        .join(Challenge, ChallengeAttempt.challenge_id == Challenge.id)
        .join(AlarmTrigger, ChallengeAttempt.alarm_trigger_id == AlarmTrigger.id)
        .filter(AlarmTrigger.user_id == user_id, ChallengeAttempt.answered_at.isnot(None))
        .all()
    )
    scores = {}
    for cat in ALL_CATEGORIES:
        cat_attempts = [a for a, c in attempts if (c.type.value if hasattr(c.type, "value") else c.type) == cat]
        if not cat_attempts:
            scores[cat] = 0.5  # unknown — treat as neutral, gets a shot via exploration
        else:
            scores[cat] = sum(1 for a in cat_attempts if a.is_correct) / len(cat_attempts)
    return scores


def personalized_challenge_recommendation(user_id: str, db: Session) -> dict:
    predictions = {}
    used_model = False

    for category in ALL_CATEGORIES:
        features = _build_live_features(user_id, db, category)
        result = predict_success_probability(features)
        if result is not None:
            used_model = True
            predictions[category] = result["success_probability"]
        else:
            predictions[category] = None

    if not used_model:
        predictions = _rule_based_category_scores(user_id, db)

    weakest = min(predictions, key=lambda c: predictions[c])
    strongest = max(predictions, key=lambda c: predictions[c])

    return {
        "source": "ml_model" if used_model else "rule_based_fallback",
        "category_scores": {k: round(v, 3) for k, v in predictions.items()},
        "needs_practice": {
            "category": weakest,
            "predicted_success_probability": round(predictions[weakest], 3),
            "message": f"Your {weakest.replace('_', ' ')} challenges are your weakest spot right now — a few more reps here would help most.",
        },
        "confidence_booster": {
            "category": strongest,
            "predicted_success_probability": round(predictions[strongest], 3),
            "message": f"You're strongest at {strongest.replace('_', ' ')} — a quick win here is a good way to start the streak.",
        },
    }


# ---------- Rule-based recommendation types (built on top of existing services) ----------

def _sleep_recommendation(habit: dict) -> dict | None:
    score = habit.get("sleep_adherence_score")
    if score is None:
        return None
    if score >= 80:
        return None
    return {
        "category": "sleep",
        "message": "Your sleep duration has been drifting from your target lately — try locking in a consistent bedtime this week.",
    }


def _wake_up_recommendation(behavior: dict) -> dict | None:
    snooze = behavior.get("snooze_trend", {}).get("overall_average_snoozes", 0)
    if snooze < 1.5:
        return None
    return {
        "category": "wake_up",
        "message": f"You're averaging {snooze} snoozes per alarm — consider moving your alarm a few minutes earlier or trying a harder challenge difficulty.",
    }


def _habit_recommendation(habit: dict) -> dict | None:
    total = habit.get("total_score")
    if total is None or total >= 70:
        return None
    weakest_component = min(
        (k for k in ["wake_consistency_score", "challenge_success_score", "snooze_reduction_score", "sleep_adherence_score"]
         if habit.get(k) is not None),
        key=lambda k: habit[k],
        default=None,
    )
    if weakest_component is None:
        return None
    return {
        "category": "habit",
        "message": f"Your habit score is at {total} — {weakest_component.replace('_', ' ')} is pulling it down the most right now.",
    }


def _productivity_recommendation(habit: dict, user: User) -> dict | None:
    success = habit.get("challenge_success_score")
    if success is None or success >= 75:
        return None
    goal = user.goal_type or "your goals"
    return {
        "category": "productivity",
        "message": f"Challenge accuracy has been under 75% — sharpening this now will carry over into {goal}.",
    }


# ---------- Entry point ----------

def generate_recommendations(user_id: str, db: Session, persist: bool = True) -> dict:
    user = db.query(User).filter(User.id == user_id).first()
    habit = calculate_habit_score(user_id, db)
    behavior = get_behavior_patterns(user_id, db)

    challenge_rec = personalized_challenge_recommendation(user_id, db)

    rule_based = [
        r for r in [
            _sleep_recommendation(habit),
            _wake_up_recommendation(behavior),
            _habit_recommendation(habit),
            _productivity_recommendation(habit, user) if user else None,
        ] if r is not None
    ]

    if persist:
        db.add(Recommendation(
            user_id=user_id,
            category="challenge",
            message=challenge_rec["needs_practice"]["message"],
        ))
        for r in rule_based:
            db.add(Recommendation(user_id=user_id, category=r["category"], message=r["message"]))
        db.commit()

    return {
        "personalized_challenge": challenge_rec,
        "guidance": rule_based,
    }


def get_recommendation_history(user_id: str, db: Session, limit: int = 20):
    return (
        db.query(Recommendation)
        .filter(Recommendation.user_id == user_id)
        .order_by(Recommendation.created_at.desc())
        .limit(limit)
        .all()
    )


def mark_read(recommendation_id: str, user_id: str, db: Session) -> Recommendation | None:
    rec = (
        db.query(Recommendation)
        .filter(Recommendation.id == recommendation_id, Recommendation.user_id == user_id)
        .first()
    )
    if not rec:
        return None
    rec.is_read = True
    db.commit()
    db.refresh(rec)
    return rec