from datetime import datetime, date, time as time_type, timedelta
from zoneinfo import ZoneInfo


def compute_next_trigger(
    alarm_time: time_type,
    alarm_type: str,
    days_of_week: list[int] | None,
    specific_date: date | None,
    tz_name: str,
    now: datetime | None = None,
) -> datetime:
    """
    Returns the next timezone-aware datetime this alarm will fire, in tz_name.
    Uses zoneinfo so DST transitions are handled automatically — the same
    wall-clock time (e.g. 7:00 AM) always resolves to the correct UTC instant
    for that specific calendar date, even across a DST boundary.
    """
    tz = ZoneInfo(tz_name)
    now = now.astimezone(tz) if now else datetime.now(tz)

    if alarm_type == "one_time":
        if not specific_date:
            raise ValueError("one_time alarms require specific_date")
        return datetime.combine(specific_date, alarm_time, tzinfo=tz)

    if alarm_type in ("daily", "smart_adaptive"):
        allowed = set(range(7))
    elif alarm_type == "weekday":
        allowed = set(days_of_week) if days_of_week else {0, 1, 2, 3, 4}
    elif alarm_type == "weekend":
        allowed = set(days_of_week) if days_of_week else {5, 6}
    else:
        allowed = set(days_of_week) if days_of_week else set(range(7))

    for offset in range(8):
        candidate_date = (now + timedelta(days=offset)).date()
        candidate = datetime.combine(candidate_date, alarm_time, tzinfo=tz)
        if candidate.weekday() in allowed and candidate > now:
            return candidate

    raise ValueError("Could not compute next trigger — check days_of_week")