from calendar import monthrange
from datetime import date as date_type, timedelta

from sqlalchemy.orm import Session

from app.models.alarm_trigger import AlarmTrigger, VerificationStatus


def get_calendar_history(user_id: str, year: int, month: int, db: Session) -> list[dict]:
    days_in_month = monthrange(year, month)[1]
    start = date_type(year, month, 1)
    end = date_type(year, month, days_in_month)
    today = date_type.today()

    triggers = (
        db.query(AlarmTrigger)
        .filter(
            AlarmTrigger.user_id == user_id,
            AlarmTrigger.triggered_at >= start,
            AlarmTrigger.triggered_at < end + timedelta(days=1),
        )
        .all()
    )

    by_date: dict[date_type, list[AlarmTrigger]] = {}
    for t in triggers:
        by_date.setdefault(t.triggered_at.date(), []).append(t)

    results = []
    for day in range(1, days_in_month + 1):
        d = date_type(year, month, day)
        if d > today:
            status = "future"
        else:
            day_triggers = by_date.get(d)
            if not day_triggers:
                status = "none"
            elif any(t.verification_status == VerificationStatus.passed and t.snooze_count == 0 for t in day_triggers):
                status = "success"
            elif any(t.verification_status == VerificationStatus.passed and t.snooze_count > 0 for t in day_triggers):
                status = "snoozed"
            else:
                status = "missed"
        results.append({"date": d.isoformat(), "day": day, "status": status})
    return results


def get_streaks(user_id: str, db: Session) -> dict:
    today = date_type.today()
    lookback_start = today - timedelta(days=365)

    triggers = (
        db.query(AlarmTrigger)
        .filter(AlarmTrigger.user_id == user_id, AlarmTrigger.triggered_at >= lookback_start)
        .all()
    )

    by_date: dict[date_type, list[AlarmTrigger]] = {}
    for t in triggers:
        by_date.setdefault(t.triggered_at.date(), []).append(t)

    def day_passed(d: date_type):
        day_triggers = by_date.get(d)
        if not day_triggers:
            return None  # no alarm that day — neutral, doesn't break or extend the streak
        return any(t.verification_status == VerificationStatus.passed for t in day_triggers)

    # Current streak: walk back from today, skipping no-alarm days, stop at first failed day.
    current = 0
    d = today
    while d >= lookback_start:
        result = day_passed(d)
        if result is None:
            d -= timedelta(days=1)
            continue
        if result:
            current += 1
            d -= timedelta(days=1)
        else:
            break

    # Best streak: scan all days that actually had an alarm, chronologically.
    best = 0
    running = 0
    for d in sorted(by_date.keys()):
        if day_passed(d):
            running += 1
            best = max(best, running)
        else:
            running = 0

    return {"current_streak": current, "best_streak": best}