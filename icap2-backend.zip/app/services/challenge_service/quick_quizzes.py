import random

QUIZ_BANK = {
    "beginner": [
        ("How many days are in a week?", "7"),
        ("What color is the sky on a clear day?", "blue"),
        ("What do bees make?", "honey"),
    ],
    "easy": [
        ("What is the capital of France?", "paris"),
        ("How many continents are there?", "7"),
        ("What planet is known as the Red Planet?", "mars"),
        ("What gas do plants absorb from the air?", "carbon dioxide"),
    ],
    "medium": [
        ("What is the largest ocean on Earth?", "pacific"),
        ("Who wrote Romeo and Juliet?", "shakespeare"),
        ("What is the boiling point of water in Celsius?", "100"),
    ],
    "hard": [
        ("What is the chemical symbol for gold?", "au"),
        ("Which planet has the most moons in our solar system?", "saturn"),
        ("In what year did World War II end?", "1945"),
        ("What is the powerhouse of the cell called?", "mitochondria"),
    ],
    "expert": [
        ("What is the speed of light in km/s (rounded)?", "300000"),
        ("Who developed the theory of general relativity?", "einstein"),
        ("What is the rarest naturally occurring element on Earth?", "astatine"),
    ],
}


def generate(difficulty: str = "medium"):
    pool = QUIZ_BANK.get(difficulty, QUIZ_BANK["medium"])
    question, answer = random.choice(pool)
    return question, answer