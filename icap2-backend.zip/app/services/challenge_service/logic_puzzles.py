import random

REASONING_BANK = {
    "beginner": [
        ("If all dogs are animals, and Rex is a dog, is Rex an animal? (yes/no)", "yes"),
        ("If a light is on, the room is bright. The room is bright. Is the light on? (yes/no)", "yes"),
    ],
    "easy": [
        ("If all cats are animals, and Tom is a cat, is Tom an animal? (yes/no)", "yes"),
        ("If it is raining, the ground is wet. The ground is not wet. Is it raining? (yes/no)", "no"),
    ],
    "medium": [
        ("All birds can fly. Penguins are birds. Can penguins fly? (yes/no)", "no"),
        ("If some fruits are sweet, and an apple is a fruit, is an apple definitely sweet? (yes/no)", "no"),
    ],
    "hard": [
        ("All roses are flowers. Some flowers fade quickly. Can we conclude all roses fade quickly? (yes/no)", "no"),
        ("If no fish can fly, and a salmon is a fish, can a salmon fly? (yes/no)", "no"),
    ],
    "expert": [
        ("Every A is a B. Every B is a C. No C is a D. Can an A be a D? (yes/no)", "no"),
        ("All philosophers are thinkers. Some thinkers are writers. Can we conclude some philosophers are writers? (yes/no)", "no"),
    ],
}

MISSING_BANK = {
    "beginner": [("2, 4, 6, _, 10", "8"), ("1, 2, 3, _, 5", "4")],
    "easy": [("2, 4, 6, _, 10", "8"), ("1, 4, 9, 16, _", "25"), ("5, 10, 15, _, 25", "20")],
    "medium": [("1, 2, 4, 7, _", "11"), ("3, 6, 9, _, 15", "12")],
    "hard": [("1, 1, 2, 3, 5, _", "8"), ("2, 6, 12, 20, _", "30"), ("3, 8, 15, 24, _", "35")],
    "expert": [("1, 2, 6, 24, _", "120"), ("2, 3, 5, 9, 17, _", "33")],
}

STEP_RANGES = {
    "beginner": (1, 3),
    "easy": (2, 5),
    "medium": (3, 7),
    "hard": (4, 9),
    "expert": (6, 12),
}


def generate(difficulty: str = "medium"):
    difficulty = difficulty if difficulty in STEP_RANGES else "medium"
    subtype = random.choice(["number_pattern", "logical_reasoning", "missing_element"])

    if subtype == "number_pattern":
        low, high = STEP_RANGES[difficulty]
        step = random.randint(low, high)
        start = random.randint(1, 10)
        sequence = [start + step * i for i in range(4)]
        answer = start + step * 4
        question = f"What comes next in the sequence: {', '.join(map(str, sequence))}, ?"
    elif subtype == "logical_reasoning":
        question, answer = random.choice(REASONING_BANK[difficulty])
    else:
        q, answer = random.choice(MISSING_BANK[difficulty])
        question = f"Find the missing number: {q}"
    return question, str(answer)