import random

RIDDLE_BANK = {
    "beginner": [
        ("What has a face but no eyes, and hands but no arms?", "clock"),
        ("What has to be broken before you can use it?", "egg"),
    ],
    "easy": [
        ("The more you take, the more you leave behind. What am I?", "footsteps"),
        ("What gets wetter as it dries?", "towel"),
        ("What has hands but can't clap?", "clock"),
    ],
    "medium": [
        ("What has a neck but no head?", "bottle"),
        ("I have keys but no locks, space but no room. What am I?", "keyboard"),
    ],
    "hard": [
        ("I speak without a mouth and hear without ears. I have no body, but come alive with wind. What am I?", "echo"),
        ("What can travel around the world while staying in a corner?", "stamp"),
    ],
    "expert": [
        ("The person who makes it sells it. The person who buys it never uses it. What is it?", "coffin"),
        ("What is so fragile that saying its name breaks it?", "silence"),
    ],
}


def generate(difficulty: str = "medium"):
    pool = RIDDLE_BANK.get(difficulty, RIDDLE_BANK["medium"])
    question, answer = random.choice(pool)
    return question, answer