import random

WORDS_BANK = {
    "beginner": ["calm", "kind", "warm"],
    "easy": ["happy", "brave", "quiet", "sunny"],
    "medium": ["cheerful", "peaceful", "hopeful"],
    "hard": ["motivated", "determined", "vibrant"],
    "expert": ["ambitious", "resilient", "tranquil"],
}

SYNONYM_PAIRS = {
    "beginner": [("calm", "peaceful")],
    "easy": [("driven", "motivated"), ("lively", "energetic")],
    "medium": [("cheerful", "joyful"), ("grateful", "thankful")],
    "hard": [("determined", "focused"), ("resilient", "tough")],
    "expert": [("meticulous", "precise"), ("audacious", "bold")],
}

ANTONYM_PAIRS = {
    "beginner": [("happy", "sad")],
    "easy": [("energetic", "tired"), ("joyful", "sad")],
    "medium": [("hopeful", "discouraged"), ("calm", "anxious")],
    "hard": [("motivated", "lazy"), ("peaceful", "restless")],
    "expert": [("meticulous", "careless"), ("audacious", "timid")],
}

VOCAB_ITEMS = {
    "beginner": [("A word meaning 'not loud' is QUI___", "quiet")],
    "easy": [
        ("A word meaning 'full of energy' is ENER____", "energetic"),
        ("A word meaning 'calm and untroubled' is PEACE____", "peaceful"),
    ],
    "medium": [
        ("A word meaning 'showing hope' is HOPE____", "hopeful"),
        ("A word meaning 'feeling thankful' is GRATE____", "grateful"),
    ],
    "hard": [
        ("A word meaning 'firmly decided' is DETER_____", "determined"),
        ("A word meaning 'full of life and energy' is VIB____", "vibrant"),
    ],
    "expert": [
        ("A word meaning 'having strong ambition' is AMBI_____", "ambitious"),
        ("A word meaning 'able to recover quickly' is RESI_____", "resilient"),
    ],
}


def generate(difficulty: str = "medium"):
    difficulty = difficulty if difficulty in WORDS_BANK else "medium"
    subtype = random.choice(["unscramble", "synonym", "antonym", "vocabulary"])

    if subtype == "unscramble":
        word = random.choice(WORDS_BANK[difficulty])
        letters = list(word)
        random.shuffle(letters)
        question = f"Unscramble this word to start your day right: {''.join(letters)}"
        answer = word
    elif subtype == "synonym":
        word, answer = random.choice(SYNONYM_PAIRS[difficulty])
        question = f"Give a synonym for: {word}"
    elif subtype == "antonym":
        word, answer = random.choice(ANTONYM_PAIRS[difficulty])
        question = f"Give the opposite (antonym) of: {word}"
    else:
        question, answer = random.choice(VOCAB_ITEMS[difficulty])
    return question, answer