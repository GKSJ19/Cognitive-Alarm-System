import random

SHAPE_SETS = {
    "beginner": ["circle", "square"],
    "easy": ["circle", "square", "triangle"],
    "medium": ["circle", "square", "triangle", "hexagon"],
    "hard": ["circle", "square", "triangle", "hexagon", "star"],
    "expert": ["circle", "square", "triangle", "hexagon", "star", "diamond"],
}

COLOR_SETS = {
    "beginner": ["red", "blue"],
    "easy": ["red", "blue", "green"],
    "medium": ["red", "blue", "green", "yellow"],
    "hard": ["red", "blue", "green", "yellow", "purple"],
    "expert": ["red", "blue", "green", "yellow", "purple", "orange"],
}

PATTERN_LENGTHS = {
    "beginner": 5,
    "easy": 7,
    "medium": 8,
    "hard": 9,
    "expert": 10,
}

RATIO_CHOICES = {
    "beginner": [2],
    "easy": [2, 3],
    "medium": [2, 3, 4],
    "hard": [3, 4],
    "expert": [4, 5],
}


def generate(difficulty: str = "medium"):
    difficulty = difficulty if difficulty in SHAPE_SETS else "medium"
    subtype = random.choice(["shape_sequence", "color_pattern", "number_progression"])
    length = PATTERN_LENGTHS[difficulty]

    if subtype == "shape_sequence":
        shapes = SHAPE_SETS[difficulty]
        pattern = (shapes * 3)[:length]
        idx = random.randint(0, len(pattern) - 1)
        answer = pattern[idx]
        display = pattern.copy(); display[idx] = "_"
        question = f"Find the missing shape in the pattern: {' '.join(display)}"
    elif subtype == "color_pattern":
        colors = COLOR_SETS[difficulty]
        pattern = (colors * 3)[:length]
        idx = random.randint(0, len(pattern) - 1)
        answer = pattern[idx]
        display = pattern.copy(); display[idx] = "_"
        question = f"Find the missing color in the pattern: {' '.join(display)}"
    else:
        start = random.randint(1, 5)
        ratio = random.choice(RATIO_CHOICES[difficulty])
        sequence = [start * (ratio ** i) for i in range(4)]
        answer = start * (ratio ** 4)
        question = f"What comes next: {', '.join(map(str, sequence))}, ?"
    return question, str(answer)