from datetime import datetime, timedelta, time as time_type, timezone as dt_timezone
from zoneinfo import ZoneInfo

from app.core.database import SessionLocal
from app.models.notification import Notification
from app.models.user import User

FIRE_WINDOW_SECONDS = 90
BEDTIME_LEAD_MINUTES = 30


def create_notification(db, user_id, ntype: str, message: str) -> Notification:
    notif = Notification(user_id=user_id, type=ntype, message=message)
    db.add(notif)
    db.commit()
    db.refresh(notif)
    return notif


# ---------- Event-driven notifications (called from other services) ----------

def notify_wake_up_reminder(db, user, alarm) -> Notification:
    label = alarm.label or "your alarm"
    return create_notification(
        db, user.id, "wake_up_reminder",
        f"Time to wake up! Solve the challenge to dismiss \"{label}\"."
    )


def notify_challenge_reminder(db, user, trigger) -> Notification:
    return create_notification(
        db, user.id, "challenge_reminder",
        "Your challenge is still waiting — complete it to stop the alarm."
    )


def notify_habit_alert(db, user_id, total_score: float, previous_score: float = None) -> Notification | None:
    """Fires only when the score meaningfully drops or is low. Returns None otherwise."""
    if previous_score is not None and (float(previous_score) - float(total_score)) >= 15:
        msg = f"Your habit score dropped from {previous_score} to {total_score}. Let's get back on track today."
    elif float(total_score) < 40:
        msg = f"Your habit score is currently {total_score}. Try dismissing today's alarm without snoozing."
    else:
        return None
    return create_notification(db, user_id, "habit_alert", msg)


def notify_progress(db, user_id, message: str) -> Notification:
    return create_notification(db, user_id, "progress", message)


def broadcast_announcement(db, message: str) -> int:
    users = db.query(User).filter(User.is_active == True).all()
    notifs = [Notification(user_id=u.id, type="platform_announcement", message=message) for u in users]
    db.add_all(notifs)
    db.commit()
    return len(notifs)


# ---------- Scheduled check (run on a timer, like the alarm dispatcher) ----------

def check_and_send_bedtime_reminders():
    """
    For every active user with a preferred_bedtime set, sends one reminder
    BEDTIME_LEAD_MINUTES before bedtime, in their own timezone, at most once/day.
    """
    db = SessionLocal()
    sent = []
    try:
        users = db.query(User).filter(
            User.is_active == True,
            User.preferred_bedtime.isnot(None),
        ).all()

        for user in users:
            tz = ZoneInfo(user.timezone or "UTC")
            local_now = datetime.now(tz)

            target_bedtime = datetime.combine(local_now.date(), user.preferred_bedtime, tzinfo=tz)
            reminder_at = target_bedtime - timedelta(minutes=BEDTIME_LEAD_MINUTES)

            elapsed = (local_now - reminder_at).total_seconds()
            if elapsed < 0 or elapsed > FIRE_WINDOW_SECONDS:
                continue

            start_of_day_utc = datetime.combine(
                local_now.date(), time_type.min, tzinfo=tz
            ).astimezone(dt_timezone.utc)

            already_sent = db.query(Notification).filter(
                Notification.user_id == user.id,
                Notification.type == "bedtime_reminder",
                Notification.sent_at >= start_of_day_utc,
            ).first()
            if already_sent:
                continue

            create_notification(
                db, user.id, "bedtime_reminder",
                f"Bedtime in {BEDTIME_LEAD_MINUTES} minutes — start winding down for a good night's sleep."
            )
            sent.append(user.id)
    finally:
        db.close()
    return sent