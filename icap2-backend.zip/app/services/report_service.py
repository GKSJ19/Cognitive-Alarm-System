import os
import uuid
from datetime import datetime, timedelta, timezone
from sqlalchemy.orm import Session

from app.models.habit_score import HabitScore
from app.models.alarm_trigger import AlarmTrigger
from app.models.challenge_attempt import ChallengeAttempt
from app.models.challenge import Challenge
from app.models.goal_metric import GoalMetric
from app.models.sleep_log import SleepLog
from app.models.report import Report, ReportType, ReportFormat

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from openpyxl import Workbook

REPORTS_DIR = os.path.join(os.getcwd(), "generated_reports")
os.makedirs(REPORTS_DIR, exist_ok=True)

DEFAULT_WINDOW_DAYS = 7


# ---------- Data gathering, one function per report type ----------

def _gather_habit(user_id, db: Session, since):
    rows = (
        db.query(HabitScore)
        .filter(HabitScore.user_id == user_id, HabitScore.date >= since.date())
        .order_by(HabitScore.date.asc())
        .all()
    )
    headers = ["Date", "Wake Consistency", "Challenge Success", "Snooze Reduction", "Sleep Adherence", "Total Score"]
    data = [
        [str(r.date), float(r.wake_consistency_score), float(r.challenge_success_score),
         float(r.snooze_reduction_score), float(r.sleep_adherence_score), float(r.total_score)]
        for r in rows
    ]
    return headers, data


def _gather_wakeup(user_id, db: Session, since):
    rows = (
        db.query(AlarmTrigger)
        .filter(AlarmTrigger.user_id == user_id, AlarmTrigger.triggered_at >= since)
        .order_by(AlarmTrigger.triggered_at.asc())
        .all()
    )
    headers = ["Triggered At", "Scheduled For", "Dismissed At", "Snooze Count", "Status"]
    data = [
        [
            r.triggered_at.strftime("%Y-%m-%d %H:%M") if r.triggered_at else "—",
            r.scheduled_for.strftime("%Y-%m-%d %H:%M") if r.scheduled_for else "—",
            r.dismissed_at.strftime("%Y-%m-%d %H:%M") if r.dismissed_at else "—",
            r.snooze_count or 0,
            r.verification_status.value,
        ]
        for r in rows
    ]
    return headers, data


def _gather_challenge(user_id, db: Session, since):
    rows = (
        db.query(ChallengeAttempt, Challenge)
        .join(Challenge, ChallengeAttempt.challenge_id == Challenge.id)
        .join(AlarmTrigger, ChallengeAttempt.alarm_trigger_id == AlarmTrigger.id)
        .filter(AlarmTrigger.user_id == user_id, ChallengeAttempt.answered_at >= since)
        .order_by(ChallengeAttempt.answered_at.asc())
        .all()
    )
    headers = ["Answered At", "Type", "Difficulty", "Correct", "Time Taken (s)"]
    data = [
        [
            attempt.answered_at.strftime("%Y-%m-%d %H:%M") if attempt.answered_at else "—",
            challenge.type.value,
            challenge.difficulty.value,
            "Yes" if attempt.is_correct else "No",
            attempt.time_taken_seconds if attempt.time_taken_seconds is not None else "—",
        ]
        for attempt, challenge in rows
    ]
    return headers, data


def _gather_productivity(user_id, db: Session, since):
    rows = (
        db.query(GoalMetric)
        .filter(GoalMetric.user_id == user_id, GoalMetric.date >= since.date())
        .order_by(GoalMetric.date.asc())
        .all()
    )
    headers = ["Date", "Goal Type", "Metric", "Value"]
    data = [[str(r.date), r.goal_type.value, r.metric_label, float(r.metric_value)] for r in rows]
    return headers, data


def _gather_sleep(user_id, db: Session, since):
    rows = (
        db.query(SleepLog)
        .filter(SleepLog.user_id == user_id, SleepLog.date >= since.date())
        .order_by(SleepLog.date.asc())
        .all()
    )
    headers = ["Date", "Sleep Start", "Sleep End", "Duration (mins)", "Source"]
    data = [
        [
            str(r.date),
            r.sleep_start.strftime("%Y-%m-%d %H:%M") if r.sleep_start else "—",
            r.sleep_end.strftime("%Y-%m-%d %H:%M") if r.sleep_end else "—",
            r.duration_mins if r.duration_mins is not None else "—",
            r.source.value,
        ]
        for r in rows
    ]
    return headers, data


_GATHERERS = {
    ReportType.habit: _gather_habit,
    ReportType.wakeup: _gather_wakeup,
    ReportType.challenge: _gather_challenge,
    ReportType.productivity: _gather_productivity,
    ReportType.sleep: _gather_sleep,
}


# ---------- File writers ----------

def _write_pdf(path: str, title: str, headers: list, data: list):
    doc = SimpleDocTemplate(path, pagesize=A4)
    styles = getSampleStyleSheet()
    elements = [Paragraph(title, styles["Title"]), Spacer(1, 12)]

    if not data:
        elements.append(Paragraph("No data available for this period.", styles["Normal"]))
    else:
        table_data = [headers] + [[str(cell) for cell in row] for row in data]
        table = Table(table_data, repeatRows=1)
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2c3e50")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f2f2f2")]),
        ]))
        elements.append(table)

    doc.build(elements)


def _write_excel(path: str, title: str, headers: list, data: list):
    wb = Workbook()
    ws = wb.active
    ws.title = title[:31] if title else "Report"
    ws.append(headers)
    for row in data:
        ws.append(row)
    for col_cells in ws.columns:
        length = max(len(str(c.value)) if c.value is not None else 0 for c in col_cells)
        ws.column_dimensions[col_cells[0].column_letter].width = min(max(length + 2, 10), 40)
    wb.save(path)


# ---------- Public entry point ----------

def generate_report(user_id, db: Session, report_type: str, fmt: str, days: int = DEFAULT_WINDOW_DAYS) -> Report:
    r_type = ReportType(report_type)
    r_format = ReportFormat(fmt)

    since = datetime.now(timezone.utc) - timedelta(days=days)
    headers, data = _GATHERERS[r_type](user_id, db, since)

    title = f"{r_type.value.capitalize()} Report — last {days} days"
    filename = f"{r_type.value}_{r_format.value}_{uuid.uuid4().hex}.{'pdf' if r_format == ReportFormat.pdf else 'xlsx'}"
    path = os.path.join(REPORTS_DIR, filename)

    if r_format == ReportFormat.pdf:
        _write_pdf(path, title, headers, data)
    else:
        _write_excel(path, title, headers, data)

    report = Report(
        user_id=user_id,
        report_type=r_type,
        format=r_format,
        file_url=filename,  # resolved to a full path by the download endpoint
    )
    db.add(report)
    db.commit()
    db.refresh(report)
    return report