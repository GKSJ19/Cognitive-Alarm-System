from datetime import datetime, timezone as dt_timezone
from zoneinfo import ZoneInfo
from sqlalchemy.exc import IntegrityError

from app.core.database import SessionLocal
from app.models.alarm import Alarm, AlarmType
from app.models.alarm_trigger import AlarmTrigger, VerificationStatus
from app.models.user import User
from app.services.verification_service import start_verification
from app.services.notification_service import notify_wake_up_reminder

FIRE_WINDOW_SECONDS = 90


def _alarm_applies_today(alarm: Alarm, local_now: datetime) -> bool:
    weekday = local_now.weekday()

    if alarm.alarm_type == AlarmType.one_time:
        return alarm.specific_date == local_now.date()
    if alarm.alarm_type in (AlarmType.daily, AlarmType.smart_adaptive):
        return True
    if alarm.alarm_type == AlarmType.weekday:
        allowed = set(alarm.days_of_week) if alarm.days_of_week else {0, 1, 2, 3, 4}
        return weekday in allowed
    if alarm.alarm_type == AlarmType.weekend:
        allowed = set(alarm.days_of_week) if alarm.days_of_week else {5, 6}
        return weekday in allowed
    return False


def check_and_fire_alarms():
    db = SessionLocal()
    fired = []
    try:
        alarms = db.query(Alarm).filter(Alarm.is_active == True).all()
        for alarm in alarms:
            user = db.query(User).filter(User.id == alarm.user_id).first()
            if not user:
                continue

            tz_name = alarm.timezone_override or user.timezone or "UTC"
            tz = ZoneInfo(tz_name)
            local_now = datetime.now(tz)

            if not _alarm_applies_today(alarm, local_now):
                continue

            scheduled_for = datetime.combine(local_now.date(), alarm.time, tzinfo=tz)
            elapsed = (local_now - scheduled_for).total_seconds()
            if elapsed < 0 or elapsed > FIRE_WINDOW_SECONDS:
                continue

            scheduled_for_utc = scheduled_for.astimezone(dt_timezone.utc)

            already_fired = db.query(AlarmTrigger).filter(
                AlarmTrigger.alarm_id == alarm.id,
                AlarmTrigger.scheduled_for == scheduled_for_utc,
            ).first()
            if already_fired:
                continue

            trigger = AlarmTrigger(
                alarm_id=alarm.id,
                user_id=alarm.user_id,
                verification_status=VerificationStatus.pending,
                scheduled_for=scheduled_for_utc,
            )
            db.add(trigger)
            try:
                db.commit()
            except IntegrityError:
                db.rollback()
                continue
            db.refresh(trigger)

            challenge = start_verification(db, user, alarm, trigger)
            notify_wake_up_reminder(db, user, alarm)

            if alarm.alarm_type == AlarmType.one_time:
                alarm.is_active = False
                db.commit()

            fired.append({
                "trigger_id": str(trigger.id),
                "challenge_id": str(challenge.id),
                "question": challenge.question,
            })
    finally:
        db.close()
    return fired