from datetime import datetime, timedelta, timezone
from app.models.alarm_trigger import VerificationStatus
from app.models.challenge import Challenge, ChallengeType, Difficulty
from app.services.challenge_service.engine import generate_challenge
from app.services.difficulty_service import calculate_difficulty


def _new_challenge(db, user, exclude_categories=None):
    difficulty_str, _, _ = calculate_difficulty(str(user.id), db)
    category, question, answer = generate_challenge(
        goal_type=user.goal_type, difficulty=difficulty_str, exclude_categories=exclude_categories
    )
    challenge = Challenge(
        type=ChallengeType(category), difficulty=Difficulty(difficulty_str),
        question=question, correct_answer=answer, source="question_bank",
    )
    db.add(challenge)
    db.commit()
    db.refresh(challenge)
    return challenge


def start_verification(db, user, alarm, trigger):
    """Called on /trigger — sets up the first challenge according to the alarm's method."""
    exclude = None
    if alarm.verification_method.value == "multi_step":
        trigger.chain_categories = []
    challenge = _new_challenge(db, user, exclude_categories=exclude)

    trigger.current_challenge_id = challenge.id
    trigger.current_step = 0
    trigger.correct_count = 0
    if alarm.verification_method.value == "time_bounded" and alarm.challenge_time_limit_secs:
        trigger.current_deadline = datetime.now(timezone.utc) + timedelta(seconds=alarm.challenge_time_limit_secs)
    else:
        trigger.current_deadline = None

    db.commit()
    db.refresh(trigger)
    return challenge


def process_attempt(db, user, alarm, trigger, challenge, is_correct: bool):
    """
    Applies the alarm's verification method to one answered attempt.
    Returns (final_is_correct, status, next_challenge_or_None, extra_info_dict).
    """
    method = alarm.verification_method.value
    target = alarm.verification_target or 1
    extra = {}

    # Time-bounded: a lapsed deadline always counts as wrong, regardless of the answer.
    if method == "time_bounded" and trigger.current_deadline:
        if datetime.now(timezone.utc) > trigger.current_deadline:
            is_correct = False
            extra["expired"] = True

    trigger.total_attempts = (trigger.total_attempts or 0) + 1
    if is_correct:
        trigger.correct_count = (trigger.correct_count or 0) + 1

    next_challenge = None

    if method == "puzzle":
        # Solve N correct answers total. Wrong answers cost time (another attempt), never progress.
        if is_correct:
            trigger.current_step += 1
        if trigger.current_step >= target:
            trigger.verification_status = VerificationStatus.passed
        else:
            trigger.verification_status = VerificationStatus.in_progress
            next_challenge = _new_challenge(db, user)
            trigger.current_challenge_id = next_challenge.id

    elif method == "multi_step":
        # Chain of N across different challenge types. One mistake restarts the whole chain.
        if is_correct:
            used = list(trigger.chain_categories or [])
            used.append(challenge.type.value)
            trigger.chain_categories = used
            trigger.current_step += 1
            if trigger.current_step >= target:
                trigger.verification_status = VerificationStatus.passed
            else:
                trigger.verification_status = VerificationStatus.in_progress
                next_challenge = _new_challenge(db, user, exclude_categories=used)
                trigger.current_challenge_id = next_challenge.id
        else:
            trigger.current_step = 0
            trigger.chain_categories = []
            trigger.verification_status = VerificationStatus.in_progress
            next_challenge = _new_challenge(db, user)
            trigger.current_challenge_id = next_challenge.id
            extra["chain_restarted"] = True

    elif method == "consecutive":
        # N correct in a row. A single wrong answer resets the streak to zero.
        if is_correct:
            trigger.current_step += 1
        else:
            trigger.current_step = 0
            extra["streak_reset"] = True

        if trigger.current_step >= target:
            trigger.verification_status = VerificationStatus.passed
        else:
            trigger.verification_status = VerificationStatus.in_progress
            next_challenge = _new_challenge(db, user)
            trigger.current_challenge_id = next_challenge.id

    elif method == "time_bounded":
        # Single challenge, hard deadline. Correct + on time = passed; otherwise failed outright.
        trigger.verification_status = VerificationStatus.passed if is_correct else VerificationStatus.failed

    elif method == "accuracy":
        # Needs N correct AND overall accuracy >= 70% — guessing repeatedly can't satisfy both.
        accuracy = trigger.correct_count / trigger.total_attempts if trigger.total_attempts else 0.0
        extra["accuracy_percent"] = round(accuracy * 100, 1)
        if trigger.correct_count >= target and accuracy >= 0.70:
            trigger.verification_status = VerificationStatus.passed
        else:
            trigger.verification_status = VerificationStatus.in_progress
            next_challenge = _new_challenge(db, user)
            trigger.current_challenge_id = next_challenge.id

    else:
        trigger.verification_status = VerificationStatus.passed if is_correct else VerificationStatus.failed

    db.commit()
    db.refresh(trigger)
    return is_correct, trigger.verification_status.value, next_challenge, extra