from sqlalchemy.orm import Session
from app.models.challenge_attempt import ChallengeAttempt
from app.models.alarm_trigger import AlarmTrigger
from app.models.challenge import Challenge
from app.ml.predict_difficulty import predict_direction

DIFFICULTY_LEVELS = ["beginner", "easy", "medium", "hard", "expert"]
# Below this confidence, we don't trust the model's direction enough to override
# the rule-based result — the rules stay in charge instead of a coin-flip-confidence guess.
MODEL_CONFIDENCE_THRESHOLD = 0.5


def _step_difficulty(difficulty: str, direction: str) -> str:
    """Moves difficulty one level up or down from wherever the rules landed. Never jumps
    more than one level at a time, so the model can only nudge, not override wildly."""
    idx = DIFFICULTY_LEVELS.index(difficulty)
    if direction == "increase":
        idx = min(idx + 1, len(DIFFICULTY_LEVELS) - 1)
    elif direction == "decrease":
        idx = max(idx - 1, 0)
    return DIFFICULTY_LEVELS[idx]


def calculate_difficulty(user_id: str, db: Session) -> tuple[str, float, int]:
    recent_attempts = (
        db.query(ChallengeAttempt, Challenge)
        .join(Challenge, ChallengeAttempt.challenge_id == Challenge.id)
        .join(AlarmTrigger, ChallengeAttempt.alarm_trigger_id == AlarmTrigger.id)
        .filter(AlarmTrigger.user_id == user_id)
        .order_by(ChallengeAttempt.answered_at.desc())
        .limit(10)
        .all()
    )

    if not recent_attempts:
        return "medium", 0.0, 0

    attempts = [a for a, c in recent_attempts]
    total = len(attempts)
    correct = sum(1 for a in attempts if a.is_correct)
    accuracy = round((correct / total) * 100, 1)

    # --- Original rule-based baseline, unchanged ---
    if accuracy >= 95:
        rule_difficulty = "expert"
    elif accuracy >= 80:
        rule_difficulty = "hard"
    elif accuracy >= 60:
        rule_difficulty = "medium"
    elif accuracy >= 40:
        rule_difficulty = "easy"
    else:
        rule_difficulty = "beginner"

    # --- Ask the trained model whether to nudge that baseline up or down ---
    latest_attempt, latest_challenge = recent_attempts[0]

    streak = 0
    for a in attempts:
        if a.is_correct:
            streak += 1
        else:
            break

    times = [a.time_taken_seconds for a in attempts if a.time_taken_seconds is not None]
    rolling_avg_time = sum(times) / len(times) if times else -1

    current_difficulty_value = (
        latest_challenge.difficulty.value if hasattr(latest_challenge.difficulty, "value")
        else latest_challenge.difficulty
    )
    challenge_type_value = (
        latest_challenge.type.value if hasattr(latest_challenge.type, "value")
        else latest_challenge.type
    )
    difficulty_index = {"beginner": 0, "easy": 1, "medium": 2, "hard": 3, "expert": 4}

    model_result = predict_direction({
        "rolling_accuracy": accuracy,
        "rolling_avg_time": rolling_avg_time,
        "current_difficulty": difficulty_index.get(current_difficulty_value, 2),
        "streak": streak,
        "challenge_type": challenge_type_value,
    })

    if model_result is not None and model_result["confidence"] >= MODEL_CONFIDENCE_THRESHOLD:
        difficulty = _step_difficulty(rule_difficulty, model_result["direction"])
    else:
        difficulty = rule_difficulty

    return difficulty, accuracy, total