from datetime import datetime, timedelta
from collections import defaultdict
from sqlalchemy.orm import Session

from app.models.alarm_trigger import AlarmTrigger, VerificationStatus
from app.models.challenge_attempt import ChallengeAttempt
from app.models.sleep_log import SleepLog
from app.ml.predict_behavior_anomaly import check_anomaly

WINDOW_DAYS = 30

def snooze_trend(user_id: str, db: Session, since: datetime):
    triggers = (
        db.query(AlarmTrigger)
        .filter(AlarmTrigger.user_id == user_id, AlarmTrigger.triggered_at >= since)
        .order_by(AlarmTrigger.triggered_at.asc())
        .all()
    )
    by_week = defaultdict(list)
    for t in triggers:
        week_key = t.triggered_at.date().isocalendar()[1]
        by_week[week_key].append(t.snooze_count)

    weekly_avg = {
        f"week_{w}": round(sum(v) / len(v), 2) for w, v in by_week.items()
    }
    overall_avg = round(sum(t.snooze_count for t in triggers) / len(triggers), 2) if triggers else 0.0
    return {"weekly_average_snoozes": weekly_avg, "overall_average_snoozes": overall_avg}

def wake_time_consistency(user_id: str, db: Session, since: datetime):
    triggers = (
        db.query(AlarmTrigger)
        .filter(
            AlarmTrigger.user_id == user_id,
            AlarmTrigger.triggered_at >= since,
            AlarmTrigger.verification_status == VerificationStatus.passed,
            AlarmTrigger.dismissed_at.isnot(None),
        )
        .all()
    )
    if not triggers:
        return {"average_wake_minute_of_day": None, "std_dev_minutes": None, "sample_size": 0}

    minutes = [t.dismissed_at.hour * 60 + t.dismissed_at.minute for t in triggers]
    avg = sum(minutes) / len(minutes)
    variance = sum((m - avg) ** 2 for m in minutes) / len(minutes)
    std_dev = round(variance ** 0.5, 1)

    return {
        "average_wake_minute_of_day": round(avg, 1),
        "std_dev_minutes": std_dev,
        "sample_size": len(triggers),
    }

def sleep_vs_accuracy_correlation(user_id: str, db: Session, since: datetime):
    logs = db.query(SleepLog).filter(
        SleepLog.user_id == user_id, SleepLog.date >= since.date()
    ).all()
    date_to_duration = {log.date: log.duration_mins for log in logs if log.duration_mins}

    attempts = (
        db.query(ChallengeAttempt)
        .join(AlarmTrigger, ChallengeAttempt.alarm_trigger_id == AlarmTrigger.id)
        .filter(AlarmTrigger.user_id == user_id, ChallengeAttempt.answered_at >= since)
        .all()
    )
    by_date = defaultdict(list)
    for a in attempts:
        by_date[a.answered_at.date()].append(a.is_correct)

    paired = []
    for d, results in by_date.items():
        if d in date_to_duration:
            accuracy = sum(results) / len(results) * 100
            paired.append((date_to_duration[d], accuracy))

    if len(paired) < 2:
        return {"correlation": None, "sample_size": len(paired), "note": "Not enough overlapping days yet"}

    durations = [p[0] for p in paired]
    accuracies = [p[1] for p in paired]
    mean_d = sum(durations) / len(durations)
    mean_a = sum(accuracies) / len(accuracies)
    cov = sum((d - mean_d) * (a - mean_a) for d, a in zip(durations, accuracies))
    std_d = sum((d - mean_d) ** 2 for d in durations) ** 0.5
    std_a = sum((a - mean_a) ** 2 for a in accuracies) ** 0.5

    if std_d == 0 or std_a == 0:
        correlation = 0.0
    else:
        correlation = round(cov / (std_d * std_a), 2)

    return {"correlation": correlation, "sample_size": len(paired)}


def _most_recent_day_anomaly(user_id: str, db: Session, since: datetime, baseline_wake_minute):
    """Builds the 5 features check_anomaly() expects from the single most recent
    day this user had an alarm trigger, and scores it. Returns None if there's
    no model trained yet, or not enough data on that specific day to build the
    features -- callers should treat None as 'no anomaly signal available',
    not as 'this day was normal'."""
    latest_trigger = (
        db.query(AlarmTrigger)
        .filter(AlarmTrigger.user_id == user_id, AlarmTrigger.triggered_at >= since)
        .order_by(AlarmTrigger.triggered_at.desc())
        .first()
    )
    if latest_trigger is None:
        return None

    day = latest_trigger.triggered_at.date()

    day_triggers = (
        db.query(AlarmTrigger)
        .filter(
            AlarmTrigger.user_id == user_id,
            AlarmTrigger.triggered_at >= datetime.combine(day, datetime.min.time()),
            AlarmTrigger.triggered_at < datetime.combine(day, datetime.min.time()) + timedelta(days=1),
        )
        .all()
    )
    if not day_triggers:
        return None

    snooze_count = sum(t.snooze_count or 0 for t in day_triggers)

    latencies = [
        (t.dismissed_at - t.triggered_at).total_seconds()
        for t in day_triggers
        if t.dismissed_at and t.verification_status == VerificationStatus.passed
    ]
    dismiss_latency_seconds = sum(latencies) / len(latencies) if latencies else 0

    first_trigger = min(day_triggers, key=lambda t: t.triggered_at)
    wake_minute = first_trigger.triggered_at.hour * 60 + first_trigger.triggered_at.minute
    baseline = baseline_wake_minute if baseline_wake_minute is not None else wake_minute
    wake_time_deviation_minutes = abs(wake_minute - baseline)

    day_attempts = (
        db.query(ChallengeAttempt)
        .join(AlarmTrigger, ChallengeAttempt.alarm_trigger_id == AlarmTrigger.id)
        .filter(
            AlarmTrigger.user_id == user_id,
            ChallengeAttempt.answered_at >= datetime.combine(day, datetime.min.time()),
            ChallengeAttempt.answered_at < datetime.combine(day, datetime.min.time()) + timedelta(days=1),
        )
        .all()
    )
    challenge_accuracy_percent = (
        sum(a.is_correct for a in day_attempts) / len(day_attempts) * 100 if day_attempts else 50.0
    )

    sleep_log = db.query(SleepLog).filter(SleepLog.user_id == user_id, SleepLog.date == day).first()
    sleep_duration_mins = sleep_log.duration_mins if sleep_log and sleep_log.duration_mins else 420

    result = check_anomaly({
        "snooze_count": snooze_count,
        "dismiss_latency_seconds": dismiss_latency_seconds,
        "wake_time_deviation_minutes": wake_time_deviation_minutes,
        "challenge_accuracy_percent": challenge_accuracy_percent,
        "sleep_duration_mins": sleep_duration_mins,
    })
    if result is not None:
        result["date"] = str(day)
    return result


def get_behavior_patterns(user_id: str, db: Session) -> dict:
    since = datetime.utcnow() - timedelta(days=WINDOW_DAYS)
    wake_consistency = wake_time_consistency(user_id, db, since)

    return {
        "window_days": WINDOW_DAYS,
        "snooze_trend": snooze_trend(user_id, db, since),
        "wake_time_consistency": wake_consistency,
        "sleep_duration_vs_accuracy": sleep_vs_accuracy_correlation(user_id, db, since),
        "recent_day_anomaly": _most_recent_day_anomaly(
            user_id, db, since, wake_consistency.get("average_wake_minute_of_day")
        ),
    }