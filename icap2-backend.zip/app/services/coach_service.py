from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.models.user import User
from app.models.coach_assignment import CoachAssignment
from app.models.sleep_log import SleepLog
from app.models.alarm import Alarm
from app.models.alarm_trigger import AlarmTrigger

from app.services.habit_score_service import calculate_habit_score
from app.services.behavior_service import get_behavior_patterns

RECENT_LIMIT = 14


def get_assigned_users(coach_id, db: Session):
    rows = (
        db.query(User)
        .join(CoachAssignment, CoachAssignment.user_id == User.id)
        .filter(CoachAssignment.coach_id == coach_id)
        .all()
    )
    return rows


def ensure_assigned(coach_id, user_id, db: Session) -> User:
    """Raises 403/404 unless the given user is actually assigned to this coach."""
    assignment = db.query(CoachAssignment).filter(
        CoachAssignment.coach_id == coach_id, CoachAssignment.user_id == user_id
    ).first()
    if not assignment:
        raise HTTPException(status_code=403, detail="This user is not assigned to you")

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


def _recent_sleep_logs(user_id, db: Session, limit=RECENT_LIMIT):
    rows = (
        db.query(SleepLog)
        .filter(SleepLog.user_id == user_id)
        .order_by(SleepLog.date.desc())
        .limit(limit)
        .all()
    )
    return [
        {
            "date": r.date,
            "sleep_start": r.sleep_start,
            "sleep_end": r.sleep_end,
            "duration_mins": r.duration_mins,
            "source": r.source.value,
        }
        for r in rows
    ]


def _recent_alarm_history(user_id, db: Session, limit=RECENT_LIMIT):
    rows = (
        db.query(AlarmTrigger, Alarm)
        .join(Alarm, AlarmTrigger.alarm_id == Alarm.id)
        .filter(AlarmTrigger.user_id == user_id)
        .order_by(AlarmTrigger.triggered_at.desc())
        .limit(limit)
        .all()
    )
    return [
        {
            "alarm_label": alarm.label,
            "triggered_at": trigger.triggered_at,
            "dismissed_at": trigger.dismissed_at,
            "snooze_count": trigger.snooze_count,
            "status": trigger.verification_status.value,
        }
        for trigger, alarm in rows
    ]


def get_user_detail(coach_id, user_id, db: Session) -> dict:
    user = ensure_assigned(coach_id, user_id, db)
    return {
        "user": {"id": str(user.id), "name": user.name, "email": user.email},
        "habit_score": calculate_habit_score(user_id, db),
        "behavior_patterns": get_behavior_patterns(user_id, db),
        "recent_sleep_logs": _recent_sleep_logs(user_id, db),
        "recent_alarm_history": _recent_alarm_history(user_id, db),
    }