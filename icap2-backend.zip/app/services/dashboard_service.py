from datetime import datetime, timedelta
from collections import defaultdict
from sqlalchemy.orm import Session

from app.models.user import User
from app.models.alarm import Alarm
from app.models.alarm_trigger import AlarmTrigger
from app.models.challenge import Challenge
from app.models.challenge_attempt import ChallengeAttempt
from app.models.habit_score import HabitScore
from app.models.sleep_log import SleepLog
from app.models.goal_metric import GoalMetric
from app.models.coach_assignment import CoachAssignment
from app.models.recommendation import Recommendation
from app.models.report import Report

from app.services.habit_score_service import calculate_habit_score
from app.services.behavior_service import get_behavior_patterns

RECENT_LIMIT = 10


# ---------- User dashboard ----------

def _alarm_history(user_id, db: Session, limit=RECENT_LIMIT):
    rows = (
        db.query(AlarmTrigger, Alarm)
        .join(Alarm, AlarmTrigger.alarm_id == Alarm.id)
        .filter(AlarmTrigger.user_id == user_id)
        .order_by(AlarmTrigger.triggered_at.desc())
        .limit(limit)
        .all()
    )
    return [
        {
            "alarm_label": alarm.label,
            "triggered_at": trigger.triggered_at,
            "dismissed_at": trigger.dismissed_at,
            "snooze_count": trigger.snooze_count,
            "status": trigger.verification_status.value,
        }
        for trigger, alarm in rows
    ]


def _challenge_performance(user_id, db: Session):
    attempts = (
        db.query(ChallengeAttempt)
        .join(AlarmTrigger, ChallengeAttempt.alarm_trigger_id == AlarmTrigger.id)
        .filter(AlarmTrigger.user_id == user_id)
        .all()
    )
    total = len(attempts)
    correct = sum(1 for a in attempts if a.is_correct)
    accuracy = round((correct / total) * 100, 1) if total else 0.0
    return {"total_attempts": total, "correct_attempts": correct, "accuracy_percent": accuracy}


def _productivity_insights(user_id, db: Session, limit=RECENT_LIMIT):
    rows = (
        db.query(GoalMetric)
        .filter(GoalMetric.user_id == user_id)
        .order_by(GoalMetric.date.desc())
        .limit(limit)
        .all()
    )
    return [
        {"date": r.date, "goal_type": r.goal_type.value, "metric_label": r.metric_label, "value": float(r.metric_value)}
        for r in rows
    ]


def get_user_dashboard(user_id, db: Session) -> dict:
    return {
        "habit_score": calculate_habit_score(user_id, db),
        "alarm_history": _alarm_history(user_id, db),
        "wake_up_stats": get_behavior_patterns(user_id, db),
        "challenge_performance": _challenge_performance(user_id, db),
        "productivity_insights": _productivity_insights(user_id, db),
    }


# ---------- Wellness coach dashboard ----------

def _sleep_trend(user_id, db: Session, days=30):
    since = (datetime.utcnow() - timedelta(days=days)).date()
    logs = db.query(SleepLog).filter(SleepLog.user_id == user_id, SleepLog.date >= since).all()
    durations = [l.duration_mins for l in logs if l.duration_mins is not None]
    if not durations:
        return {"average_duration_mins": None, "sample_size": 0}
    return {"average_duration_mins": round(sum(durations) / len(durations), 1), "sample_size": len(durations)}


def _score_trend(user_id, db: Session):
    """Latest total_score vs the score from ~7 days ago, to show direction of progress."""
    rows = (
        db.query(HabitScore)
        .filter(HabitScore.user_id == user_id)
        .order_by(HabitScore.date.desc())
        .limit(8)
        .all()
    )
    if not rows:
        return {"latest_score": None, "trend": "no_data"}
    latest = float(rows[0].total_score)
    if len(rows) < 2:
        return {"latest_score": latest, "trend": "insufficient_history"}
    earliest = float(rows[-1].total_score)
    if latest > earliest:
        trend = "improving"
    elif latest < earliest:
        trend = "declining"
    else:
        trend = "stable"
    return {"latest_score": latest, "trend": trend}


def get_coach_dashboard(coach_id, db: Session) -> dict:
    assignments = db.query(CoachAssignment).filter(CoachAssignment.coach_id == coach_id).all()
    user_ids = [a.user_id for a in assignments]
    users = db.query(User).filter(User.id.in_(user_ids)).all() if user_ids else []

    user_summaries = []
    for user in users:
        behavior = get_behavior_patterns(user.id, db)
        user_summaries.append({
            "user_id": str(user.id),
            "name": user.name,
            "habit_adherence": _score_trend(user.id, db),
            "sleep_trend": _sleep_trend(user.id, db),
            "snooze_trend": behavior["snooze_trend"],
            "wake_time_consistency": behavior["wake_time_consistency"],
        })

    return {
        "assigned_user_count": len(user_summaries),
        "users": user_summaries,
    }


# ---------- Admin dashboard ----------

def _user_management_summary(db: Session):
    total = db.query(User).count()
    active = db.query(User).filter(User.is_active == True).count()
    by_role = defaultdict(int)
    for (role,) in db.query(User.role).all():
        by_role[role] += 1
    return {"total_users": total, "active_users": active, "by_role": dict(by_role)}


def _platform_analytics_summary(db: Session):
    total_alarms = db.query(Alarm).count()
    active_alarms = db.query(Alarm).filter(Alarm.is_active == True).count()
    total_triggers = db.query(AlarmTrigger).count()
    total_challenge_attempts = db.query(ChallengeAttempt).count()

    latest_scores = (
        db.query(HabitScore.total_score)
        .distinct(HabitScore.user_id)
        .order_by(HabitScore.user_id, HabitScore.date.desc())
        .all()
    )
    scores = [float(s[0]) for s in latest_scores if s[0] is not None]
    avg_habit_score = round(sum(scores) / len(scores), 1) if scores else None

    return {
        "total_alarms": total_alarms,
        "active_alarms": active_alarms,
        "total_alarm_triggers": total_triggers,
        "total_challenge_attempts": total_challenge_attempts,
        "average_habit_score_platform_wide": avg_habit_score,
    }


def _recommendation_monitoring_summary(db: Session):
    total = db.query(Recommendation).count()
    unread = db.query(Recommendation).filter(Recommendation.is_read == False).count()
    by_category = defaultdict(int)
    for (category,) in db.query(Recommendation.category).all():
        by_category[category or "uncategorized"] += 1
    return {"total_recommendations": total, "unread": unread, "by_category": dict(by_category)}


def _system_reports_summary(db: Session):
    total = db.query(Report).count()
    by_type = defaultdict(int)
    for (report_type,) in db.query(Report.report_type).all():
        by_type[report_type.value] += 1
    return {"total_reports_generated": total, "by_type": dict(by_type)}


def get_admin_dashboard(db: Session) -> dict:
    return {
        "user_management": _user_management_summary(db),
        "platform_analytics": _platform_analytics_summary(db),
        "recommendation_monitoring": _recommendation_monitoring_summary(db),
        "system_reports": _system_reports_summary(db),
    }