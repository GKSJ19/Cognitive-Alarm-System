import os
import sys
from logging.config import fileConfig

from sqlalchemy import engine_from_config, pool
from alembic import context

# Make "app" importable when running alembic from the project root.
sys.path.insert(0, os.getcwd())

from dotenv import load_dotenv
load_dotenv()

from app.core.database import Base

# Import every model module so Base.metadata actually knows about all
# tables — this is required for autogenerate to see them.
from app.models import (
    user, alarm, alarm_trigger, audit_log, challenge, challenge_attempt,
    coach_assignment, goal_metric, habit_score, notification,
    password_reset_token, platform_setting, recommendation, refresh_token,
    report, sleep_log,
)

config = context.config

# Use the same DATABASE_URL your app already uses, from .env — never hardcode it here.
config.set_main_option("sqlalchemy.url", os.getenv("DATABASE_URL"))

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()