/**
 * @format
 */
import { AppRegistry } from 'react-native';
import App from './App';
import { name as appName } from './app.json';
import { registerBackgroundAlarmEvents } from './src/alarm/events';

// Must run at module scope, before AppRegistry.registerComponent — Android
// can invoke this handler while the JS app is not otherwise running (e.g.
// the alarm fires while the app was killed).
registerBackgroundAlarmEvents();

AppRegistry.registerComponent(appName, () => App);
