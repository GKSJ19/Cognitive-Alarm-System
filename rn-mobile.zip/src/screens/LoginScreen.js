import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { colors } from '../theme';

export default function LoginScreen({ navigation }) {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function handleSubmit() {
    setError('');
    setBusy(true);
    try {
      await login({ email, password });
    } catch (err) {
      setError(err.response?.data?.detail || "That email and password don't match.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={styles.logo} />
      <Text style={styles.title}>Cognitive Alarm</Text>
      <Text style={styles.subtitle}>Sign in to manage your alarms</Text>

      {error ? <Text style={styles.error}>{error}</Text> : null}

      <Text style={styles.label}>Email</Text>
      <TextInput
        style={styles.input}
        autoCapitalize="none"
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
        placeholderTextColor={colors.mistDim}
      />
      <Text style={styles.label}>Password</Text>
      <TextInput style={styles.input} secureTextEntry value={password} onChangeText={setPassword} placeholderTextColor={colors.mistDim} />

      <TouchableOpacity style={styles.button} onPress={handleSubmit} disabled={busy}>
        <Text style={styles.buttonText}>{busy ? 'Signing in…' : 'Sign in'}</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('Register')}>
        <Text style={styles.link}>New here? Create an account</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate('ServerSettings')}>
        <Text style={styles.linkDim}>Server settings</Text>
      </TouchableOpacity>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink, justifyContent: 'center', padding: 24 },
  logo: { width: 56, height: 56, borderRadius: 28, backgroundColor: colors.violet, alignSelf: 'center', marginBottom: 16 },
  title: { color: colors.paper, fontSize: 24, fontWeight: '700', textAlign: 'center' },
  subtitle: { color: colors.mist, fontSize: 13, textAlign: 'center', marginTop: 4, marginBottom: 24 },
  label: { color: colors.mistDim, fontSize: 11, textTransform: 'uppercase', marginBottom: 4, marginTop: 12 },
  input: { backgroundColor: colors.surface2, borderColor: colors.border, borderWidth: 1, borderRadius: 10, padding: 12, color: colors.paper },
  button: { backgroundColor: colors.amber, borderRadius: 10, padding: 14, alignItems: 'center', marginTop: 24 },
  buttonText: { color: colors.ink, fontWeight: '700' },
  link: { color: colors.amber, textAlign: 'center', marginTop: 20 },
  linkDim: { color: colors.mistDim, textAlign: 'center', marginTop: 14, fontSize: 12 },
  error: { color: colors.rose, backgroundColor: 'rgba(224,96,126,0.1)', borderRadius: 8, padding: 10, marginBottom: 8 },
});
