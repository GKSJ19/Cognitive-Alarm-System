import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { createAlarm, updateAlarm } from '../api/alarms';
import { syncDeviceAlarm } from '../alarm/rescheduling';
import { requestNotificationPermission, hasExactAlarmPermission, openExactAlarmSettings } from '../alarm/scheduler';
import { colors } from '../theme';

const TYPES = ['daily', 'weekday', 'weekend', 'one_time', 'smart_adaptive'];
// Backend uses Python's date.weekday(): Monday=0 ... Sunday=6.
const WEEKDAYS = [
  { value: 0, label: 'Mon' }, { value: 1, label: 'Tue' }, { value: 2, label: 'Wed' },
  { value: 3, label: 'Thu' }, { value: 4, label: 'Fri' }, { value: 5, label: 'Sat' }, { value: 6, label: 'Sun' },
];

function toFormTime(backendTime) {
  // Backend AlarmResponse.time is "HH:MM:SS" — the <input> only wants HH:MM.
  return (backendTime || '07:00:00').slice(0, 5);
}

const DEFAULT_FORM = { alarm_type: 'daily', time: '07:00', label: '', days_of_week: [], max_snoozes: 3, snooze_duration_mins: 5, is_active: true };

export default function AlarmEditorScreen({ route, navigation }) {
  // No GET /alarms/{id} exists on the backend — the full alarm object is
  // passed in via navigation params from AlarmsScreen instead of re-fetched.
  const existing = route.params?.alarm;
  const isEdit = !!existing;
  const [form, setForm] = useState(
    existing ? { ...DEFAULT_FORM, ...existing, time: toFormTime(existing.time), days_of_week: existing.days_of_week || [] } : DEFAULT_FORM,
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [permissionWarning, setPermissionWarning] = useState('');

  useEffect(() => {
    (async () => {
      await requestNotificationPermission();
      const granted = await hasExactAlarmPermission();
      if (!granted) setPermissionWarning('Exact-alarm permission is off — this alarm may fire late. Tap to fix.');
    })();
  }, []);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  function toggleWeekday(day) {
    setForm((f) => ({
      ...f,
      days_of_week: f.days_of_week.includes(day) ? f.days_of_week.filter((d) => d !== day) : [...f.days_of_week, day].sort(),
    }));
  }

  async function handleSubmit() {
    setSaving(true);
    setError('');
    try {
      const payload = {
        time: form.time.length === 5 ? `${form.time}:00` : form.time,
        alarm_type: form.alarm_type,
        label: form.label || null,
        max_snoozes: form.max_snoozes,
        snooze_duration_mins: form.snooze_duration_mins,
        days_of_week: form.alarm_type === 'weekday' || form.alarm_type === 'weekend' ? form.days_of_week : null,
      };
      const saved = isEdit ? await updateAlarm(existing.id, payload) : await createAlarm(payload);
      await syncDeviceAlarm(saved).catch(() => {});
      navigation.goBack();
    } catch (err) {
      setError(err.response?.data?.detail || "Couldn't save that alarm.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <ScrollView style={styles.screen} contentContainerStyle={{ padding: 20 }}>
      <Text style={styles.title}>{isEdit ? 'Edit alarm' : 'New alarm'}</Text>

      {permissionWarning ? (
        <TouchableOpacity style={styles.warning} onPress={openExactAlarmSettings}>
          <Text style={styles.warningText}>{permissionWarning}</Text>
        </TouchableOpacity>
      ) : null}
      {error ? <Text style={styles.error}>{error}</Text> : null}

      <Text style={styles.label}>Time (HH:MM)</Text>
      <TextInput style={styles.input} value={form.time} onChangeText={(v) => update('time', v)} placeholder="07:00" placeholderTextColor={colors.mistDim} />

      <Text style={styles.label}>Type</Text>
      <View style={styles.chipRow}>
        {TYPES.map((t) => (
          <TouchableOpacity key={t} onPress={() => update('alarm_type', t)} style={[styles.chip, form.alarm_type === t && styles.chipActive]}>
            <Text style={[styles.chipText, form.alarm_type === t && styles.chipTextActive]}>{t.replace('_', ' ')}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {(form.alarm_type === 'weekday' || form.alarm_type === 'weekend') && (
        <>
          <Text style={styles.label}>Days (defaults to Mon–Fri / Sat–Sun if none picked)</Text>
          <View style={styles.chipRow}>
            {WEEKDAYS.map((d) => (
              <TouchableOpacity key={d.value} onPress={() => toggleWeekday(d.value)} style={[styles.chip, form.days_of_week.includes(d.value) && styles.chipActiveViolet]}>
                <Text style={[styles.chipText, form.days_of_week.includes(d.value) && styles.chipTextActive]}>{d.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </>
      )}

      <Text style={styles.label}>Label</Text>
      <TextInput style={styles.input} value={form.label} onChangeText={(v) => update('label', v)} placeholder="e.g. Gym mornings" placeholderTextColor={colors.mistDim} />

      <Text style={styles.note}>
        Challenge type and verification method aren't configurable per alarm right now —
        the backend picks these server-side (see mobile README for why).
      </Text>

      <View style={styles.row2}>
        <View style={{ flex: 1 }}>
          <Text style={styles.label}>Max snoozes</Text>
          <TextInput style={styles.input} keyboardType="numeric" value={String(form.max_snoozes)} onChangeText={(v) => update('max_snoozes', Number(v) || 0)} />
        </View>
        <View style={{ flex: 1, marginLeft: 12 }}>
          <Text style={styles.label}>Snooze length (min)</Text>
          <TextInput style={styles.input} keyboardType="numeric" value={String(form.snooze_duration_mins)} onChangeText={(v) => update('snooze_duration_mins', Number(v) || 0)} />
        </View>
      </View>

      <TouchableOpacity style={styles.button} onPress={handleSubmit} disabled={saving}>
        <Text style={styles.buttonText}>{saving ? 'Saving…' : isEdit ? 'Save changes' : 'Create alarm'}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink },
  title: { color: colors.paper, fontSize: 22, fontWeight: '700', marginBottom: 16 },
  label: { color: colors.mistDim, fontSize: 11, textTransform: 'uppercase', marginBottom: 6, marginTop: 16 },
  note: { color: colors.mistDim, fontSize: 11, marginTop: 14, lineHeight: 16 },
  input: { backgroundColor: colors.surface2, borderColor: colors.border, borderWidth: 1, borderRadius: 10, padding: 12, color: colors.paper },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { backgroundColor: colors.surface2, borderRadius: 10, paddingVertical: 8, paddingHorizontal: 12 },
  chipActive: { backgroundColor: colors.amber },
  chipActiveViolet: { backgroundColor: colors.violet },
  chipText: { color: colors.mist, fontSize: 12, textTransform: 'capitalize' },
  chipTextActive: { color: colors.ink, fontWeight: '700' },
  row2: { flexDirection: 'row', marginTop: 4 },
  button: { backgroundColor: colors.amber, borderRadius: 10, padding: 14, alignItems: 'center', marginTop: 28 },
  buttonText: { color: colors.ink, fontWeight: '700' },
  error: { color: colors.rose, backgroundColor: 'rgba(224,96,126,0.1)', borderRadius: 8, padding: 10, marginBottom: 12 },
  warning: { backgroundColor: 'rgba(242,166,90,0.12)', borderColor: colors.amber, borderWidth: 1, borderRadius: 10, padding: 10, marginBottom: 12 },
  warningText: { color: colors.amber, fontSize: 12 },
});
