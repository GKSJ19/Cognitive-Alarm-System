import React, { useCallback, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, RefreshControl } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { listAlarms, getNextTrigger } from '../api/alarms';
import { getHabitScore } from '../api/habits';
import { listRecommendationHistory } from '../api/recommendations';
import Spinner from '../components/Spinner';
import { colors } from '../theme';

function formatCountdown(nextTriggerUtc) {
  if (!nextTriggerUtc) return 'No alarm scheduled';
  const diffMs = new Date(nextTriggerUtc).getTime() - Date.now();
  if (diffMs <= 0) return 'Ringing now';
  const hrs = Math.floor(diffMs / 3600000);
  const mins = Math.floor((diffMs % 3600000) / 60000);
  return `${hrs}h ${mins}m`;
}

export default function HomeScreen() {
  const [state, setState] = useState({ loading: true, nextTrigger: null, habit: null, recs: [] });
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    const alarms = await listAlarms().catch(() => []);
    const active = alarms.filter((a) => a.is_active);

    // The backend only computes next-trigger per alarm on request — there's
    // no field on the alarm list itself. Fetch each active alarm's, then
    // take the earliest. Fine at this scale (a handful of alarms); would
    // want a batched endpoint if that ever changes.
    const triggers = await Promise.all(
      active.map((a) => getNextTrigger(a.id).catch(() => null)),
    );
    const soonest = triggers
      .filter(Boolean)
      .sort((a, b) => new Date(a.next_trigger_utc) - new Date(b.next_trigger_utc))[0];

    const [habit, recs] = await Promise.all([
      getHabitScore().catch(() => null),
      listRecommendationHistory().catch(() => []),
    ]);

    setState({ loading: false, nextTrigger: soonest, habit, recs, alarmCount: active.length });
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load]),
  );

  async function onRefresh() {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  }

  if (state.loading) {
    return (
      <View style={styles.center}>
        <Spinner />
      </View>
    );
  }

  const unread = state.recs.filter((r) => !r.is_read);

  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={{ padding: 20 }}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.amber} />}
    >
      <Text style={styles.title}>Good to see you up</Text>

      <View style={styles.card}>
        <Text style={styles.cardLabel}>Next alarm</Text>
        <Text style={styles.countdown}>{formatCountdown(state.nextTrigger?.next_trigger_utc)}</Text>
        {!state.nextTrigger ? (
          <Text style={styles.cardSub}>Nothing scheduled — set one up on the Alarms tab.</Text>
        ) : null}
      </View>

      {state.habit && !state.habit.insufficient_data ? (
        <View style={styles.card}>
          <Text style={styles.cardLabel}>Habit score</Text>
          <Text style={styles.score}>{Math.round(state.habit.total_score)}</Text>
          <Text style={styles.cardSub}>out of 100</Text>
        </View>
      ) : (
        <View style={styles.card}>
          <Text style={styles.cardLabel}>Habit score</Text>
          <Text style={styles.cardSub}>Not enough data yet — dismiss a few alarms first.</Text>
        </View>
      )}

      <View style={styles.card}>
        <Text style={styles.cardLabel}>Recommendations</Text>
        {unread.length === 0 ? (
          <Text style={styles.cardSub}>Nothing new to flag right now.</Text>
        ) : (
          unread.slice(0, 3).map((r) => (
            <Text key={r.id} style={styles.recItem}>• {r.message}</Text>
          ))
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink },
  center: { flex: 1, backgroundColor: colors.ink, justifyContent: 'center', alignItems: 'center' },
  title: { color: colors.paper, fontSize: 22, fontWeight: '700', marginBottom: 16 },
  card: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 16, padding: 16, marginBottom: 14 },
  cardLabel: { color: colors.mistDim, fontSize: 11, textTransform: 'uppercase', marginBottom: 8 },
  countdown: { color: colors.amber, fontSize: 28, fontWeight: '700' },
  score: { color: colors.amber, fontSize: 28, fontWeight: '700' },
  cardSub: { color: colors.mist, fontSize: 12, marginTop: 4 },
  recItem: { color: colors.paper, fontSize: 13, marginTop: 6 },
});
