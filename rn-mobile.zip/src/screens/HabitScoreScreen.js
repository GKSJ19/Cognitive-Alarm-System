import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { getHabitScore } from '../api/habits';
import { getCurrentDifficulty } from '../api/adaptive';
import WakeRing from '../components/WakeRing';
import EmptyState from '../components/EmptyState';
import Spinner from '../components/Spinner';
import { colors } from '../theme';

// CORRECTED: no "components" array from the backend — four named *_score
// fields plus total_score. No per-challenge-type difficulty — one current
// value for the whole user.
const COMPONENT_LABELS = {
  wake_consistency_score: 'Wake-up consistency',
  challenge_success_score: 'Challenge completion',
  snooze_reduction_score: 'Snooze reduction',
  sleep_adherence_score: 'Sleep schedule adherence',
};
const WEIGHTS = {
  wake_consistency_score: 35,
  challenge_success_score: 25,
  snooze_reduction_score: 20,
  sleep_adherence_score: 20,
};

export default function HabitScoreScreen() {
  const [habit, setHabit] = useState(undefined);
  const [difficulty, setDifficulty] = useState(null);

  useEffect(() => {
    getHabitScore().then(setHabit).catch(() => setHabit(null));
    getCurrentDifficulty().then(setDifficulty).catch(() => setDifficulty(null));
  }, []);

  if (habit === undefined) return <View style={styles.center}><Spinner /></View>;
  if (!habit || habit.insufficient_data) {
    return <View style={styles.screen}><EmptyState title="No habit score yet" body="Builds from about a week of alarm history." /></View>;
  }

  return (
    <ScrollView style={styles.screen} contentContainerStyle={{ padding: 20 }}>
      <Text style={styles.title}>Habit score</Text>
      <View style={[styles.card, { alignItems: 'center' }]}>
        <WakeRing value={habit.total_score} max={100} size={160} label="current score" />
      </View>

      <View style={styles.card}>
        <Text style={styles.cardLabel}>What it's made of</Text>
        {Object.keys(COMPONENT_LABELS).map((key) => {
          const value = habit[key];
          if (value === null || value === undefined) return null;
          return (
            <View key={key} style={{ marginTop: 10 }}>
              <View style={styles.rowBetween}>
                <Text style={styles.componentLabel}>{COMPONENT_LABELS[key]} · {WEIGHTS[key]}%</Text>
                <Text style={styles.componentValue}>{Math.round(value)}</Text>
              </View>
              <View style={styles.track}>
                <View style={[styles.fill, { width: `${Math.min(100, value)}%` }]} />
              </View>
            </View>
          );
        })}
      </View>

      {difficulty && (
        <View style={styles.card}>
          <Text style={styles.cardLabel}>Current difficulty</Text>
          <Text style={styles.difficultyValue}>{difficulty.difficulty}</Text>
          <Text style={styles.cardSub}>
            {difficulty.recent_accuracy_percent}% accuracy over the last {difficulty.recent_attempts_considered} attempts
          </Text>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink, padding: 20 },
  center: { flex: 1, backgroundColor: colors.ink, justifyContent: 'center', alignItems: 'center' },
  title: { color: colors.paper, fontSize: 22, fontWeight: '700', marginBottom: 16 },
  card: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 16, padding: 16, marginBottom: 14 },
  cardLabel: { color: colors.mistDim, fontSize: 11, textTransform: 'uppercase' },
  cardSub: { color: colors.mist, fontSize: 12, marginTop: 4 },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between' },
  componentLabel: { color: colors.mist, fontSize: 12, textTransform: 'capitalize' },
  componentValue: { color: colors.paper, fontSize: 12, fontWeight: '600' },
  track: { height: 6, backgroundColor: colors.surface2, borderRadius: 4, marginTop: 4, overflow: 'hidden' },
  fill: { height: 6, backgroundColor: colors.amber },
  difficultyValue: { color: colors.violet, fontSize: 22, fontWeight: '700', marginTop: 4, textTransform: 'capitalize' },
});
