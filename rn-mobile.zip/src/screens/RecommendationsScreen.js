import React, { useCallback, useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { listRecommendationHistory, markRecommendationRead } from '../api/recommendations';
import EmptyState from '../components/EmptyState';
import Spinner from '../components/Spinner';
import { colors } from '../theme';

// CORRECTED: only a "mark read" action exists — there's no acknowledge/reject
// distinction on the backend.
export default function RecommendationsScreen() {
  const [recs, setRecs] = useState(null);
  const load = useCallback(() => listRecommendationHistory().then(setRecs).catch(() => setRecs([])), []);
  useFocusEffect(load);

  async function handleRead(id) {
    setRecs((prev) => prev.map((r) => (r.id === id ? { ...r, is_read: true } : r)));
    markRecommendationRead(id).catch(load);
  }

  if (recs === null) return <View style={styles.center}><Spinner /></View>;

  return (
    <View style={styles.screen}>
      <Text style={styles.title}>Recommendations</Text>
      {recs.length === 0 ? (
        <EmptyState title="Nothing yet" body="Recommendations build up as you use the app." />
      ) : (
        <FlatList
          data={recs}
          keyExtractor={(r) => String(r.id)}
          renderItem={({ item }) => (
            <View style={[styles.card, item.is_read && { opacity: 0.5 }]}>
              <Text style={styles.category}>{item.category || 'General'}</Text>
              <Text style={styles.message}>{item.message}</Text>
              {!item.is_read && (
                <TouchableOpacity onPress={() => handleRead(item.id)} style={styles.ackButton}>
                  <Text style={styles.ackText}>Mark read</Text>
                </TouchableOpacity>
              )}
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink, padding: 20 },
  center: { flex: 1, backgroundColor: colors.ink, justifyContent: 'center', alignItems: 'center' },
  title: { color: colors.paper, fontSize: 22, fontWeight: '700', marginBottom: 16 },
  card: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 14, padding: 14, marginBottom: 10 },
  category: { color: colors.violet, fontSize: 10, textTransform: 'uppercase' },
  message: { color: colors.paper, fontSize: 14, marginTop: 6 },
  ackButton: { backgroundColor: colors.amber, borderRadius: 8, paddingVertical: 6, paddingHorizontal: 12, alignSelf: 'flex-start', marginTop: 10 },
  ackText: { color: colors.ink, fontSize: 12, fontWeight: '700' },
});
