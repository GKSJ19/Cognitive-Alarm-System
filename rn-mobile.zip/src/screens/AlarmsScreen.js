import React, { useCallback, useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Switch } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { listAlarms, deleteAlarm, updateAlarm } from '../api/alarms';
import { syncDeviceAlarm } from '../alarm/rescheduling';
import { cancelAlarm } from '../alarm/scheduler';
import EmptyState from '../components/EmptyState';
import Spinner from '../components/Spinner';
import { colors } from '../theme';

const TYPE_LABEL = {
  daily: 'Daily', weekday: 'Weekday', weekend: 'Weekend', one_time: 'One-time', smart_adaptive: 'Smart adaptive',
};

export default function AlarmsScreen({ navigation }) {
  const [alarms, setAlarms] = useState(null);

  const load = useCallback(() => {
    listAlarms().then(setAlarms).catch(() => setAlarms([]));
  }, []);

  useFocusEffect(load);

  async function handleToggle(alarm) {
    const nextActive = !alarm.is_active;
    setAlarms((prev) => prev.map((a) => (a.id === alarm.id ? { ...a, is_active: nextActive } : a)));
    const updated = await updateAlarm(alarm.id, { is_active: nextActive });
    // Device AlarmManager schedule must mirror server state, or the phone
    // will ring for an alarm the user just turned off (or stay silent for
    // one they just turned on).
    await syncDeviceAlarm(updated).catch(() => {});
  }

  async function handleDelete(alarm) {
    await deleteAlarm(alarm.id);
    await cancelAlarm(alarm.id);
    load();
  }

  if (alarms === null) {
    return <View style={styles.center}><Spinner /></View>;
  }

  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <Text style={styles.title}>Alarms</Text>
        <TouchableOpacity style={styles.newButton} onPress={() => navigation.navigate('AlarmEditor', {})}>
          <Text style={styles.newButtonText}>New</Text>
        </TouchableOpacity>
      </View>

      {alarms.length === 0 ? (
        <EmptyState title="No alarms yet" body="Create your first one — it dismisses with a challenge, not a swipe." />
      ) : (
        <FlatList
          data={alarms}
          keyExtractor={(a) => String(a.id)}
          contentContainerStyle={{ paddingBottom: 24 }}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.row}
              onPress={() => navigation.navigate('AlarmEditor', { alarm: item })}
              onLongPress={() => handleDelete(item)}
            >
              <View>
                <Text style={styles.time}>{item.time?.slice(0, 5)}</Text>
                <Text style={styles.meta}>{TYPE_LABEL[item.alarm_type] || item.alarm_type}{item.label ? ` · ${item.label}` : ''}</Text>
                <Text style={styles.hint}>Long-press to delete</Text>
              </View>
              <Switch value={item.is_active} onValueChange={() => handleToggle(item)} trackColor={{ true: colors.amber, false: colors.surface3 }} />
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink, padding: 20 },
  center: { flex: 1, backgroundColor: colors.ink, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  title: { color: colors.paper, fontSize: 22, fontWeight: '700' },
  newButton: { backgroundColor: colors.amber, borderRadius: 10, paddingVertical: 8, paddingHorizontal: 14 },
  newButtonText: { color: colors.ink, fontWeight: '700', fontSize: 13 },
  row: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 14, padding: 16, marginBottom: 10,
  },
  time: { color: colors.paper, fontSize: 20, fontWeight: '700' },
  meta: { color: colors.mist, fontSize: 12, marginTop: 2 },
  hint: { color: colors.mistDim, fontSize: 10, marginTop: 4 },
});
