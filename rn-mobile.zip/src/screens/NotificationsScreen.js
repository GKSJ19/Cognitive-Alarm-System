import React, { useCallback, useState } from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { listNotifications, markNotificationRead } from '../api/notifications';
import EmptyState from '../components/EmptyState';
import Spinner from '../components/Spinner';
import { colors } from '../theme';

// CORRECTED: the list response is an envelope { total, unread_count,
// notifications: [...] }, not a bare array.
export default function NotificationsScreen() {
  const [items, setItems] = useState(null);
  const load = useCallback(() => {
    listNotifications().then((res) => setItems(res.notifications)).catch(() => setItems([]));
  }, []);
  useFocusEffect(load);

  if (items === null) return <View style={styles.center}><Spinner /></View>;

  return (
    <View style={styles.screen}>
      <Text style={styles.title}>Notifications</Text>
      {items.length === 0 ? (
        <EmptyState title="You're all caught up" />
      ) : (
        <FlatList
          data={items}
          keyExtractor={(n) => String(n.id)}
          renderItem={({ item }) => (
            <View style={[styles.row, !item.read_at && styles.rowUnread]} onTouchEnd={() => markNotificationRead(item.id)}>
              <Text style={styles.message}>{item.message}</Text>
              <Text style={styles.time}>{item.sent_at ? new Date(item.sent_at).toLocaleString() : ''}</Text>
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink, padding: 20 },
  center: { flex: 1, backgroundColor: colors.ink, justifyContent: 'center', alignItems: 'center' },
  title: { color: colors.paper, fontSize: 22, fontWeight: '700', marginBottom: 16 },
  row: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 12, padding: 14, marginBottom: 8 },
  rowUnread: { borderColor: colors.amber },
  message: { color: colors.paper, fontSize: 13 },
  time: { color: colors.mistDim, fontSize: 10, marginTop: 4 },
});
