import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { colors } from '../theme';

export default function RegisterScreen({ navigation }) {
  const { register } = useAuth();
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit() {
    setError('');
    setBusy(true);
    try {
      await register(form);
      navigation.navigate('Login');
    } catch (err) {
      setError(err.response?.data?.detail || "Couldn't create that account.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <ScrollView style={styles.screen} contentContainerStyle={{ padding: 24 }}>
      <Text style={styles.title}>Create your account</Text>

      {error ? <Text style={styles.error}>{error}</Text> : null}

      <Text style={styles.label}>Name</Text>
      <TextInput style={styles.input} value={form.name} onChangeText={(v) => update('name', v)} placeholderTextColor={colors.mistDim} />
      <Text style={styles.label}>Email</Text>
      <TextInput style={styles.input} autoCapitalize="none" keyboardType="email-address" value={form.email} onChangeText={(v) => update('email', v)} placeholderTextColor={colors.mistDim} />
      <Text style={styles.label}>Password</Text>
      <TextInput style={styles.input} secureTextEntry value={form.password} onChangeText={(v) => update('password', v)} placeholderTextColor={colors.mistDim} />

      <TouchableOpacity style={styles.button} onPress={handleSubmit} disabled={busy}>
        <Text style={styles.buttonText}>{busy ? 'Creating…' : 'Create account'}</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('Login')}>
        <Text style={styles.link}>Already have an account? Sign in</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink },
  title: { color: colors.paper, fontSize: 22, fontWeight: '700', marginBottom: 16 },
  label: { color: colors.mistDim, fontSize: 11, textTransform: 'uppercase', marginBottom: 4, marginTop: 12 },
  input: { backgroundColor: colors.surface2, borderColor: colors.border, borderWidth: 1, borderRadius: 10, padding: 12, color: colors.paper },
  button: { backgroundColor: colors.amber, borderRadius: 10, padding: 14, alignItems: 'center', marginTop: 24 },
  buttonText: { color: colors.ink, fontWeight: '700' },
  link: { color: colors.amber, textAlign: 'center', marginTop: 20 },
  error: { color: colors.rose, backgroundColor: 'rgba(224,96,126,0.1)', borderRadius: 8, padding: 10, marginBottom: 8 },
});
