import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import notifee from '@notifee/react-native';
import { triggerAlarm, submitAttempt, snoozeTrigger } from '../api/verification';
import Spinner from '../components/Spinner';
import { colors } from '../theme';

// REWRITTEN for the real backend flow (app/routers/verification.py). There
// is no pre-existing "alarm event" to fetch a challenge from — arriving here
// means the on-device alarm just fired, and this screen's job is to open a
// *trigger* itself, which returns the first challenge inline. Each answer
// attempt returns the next challenge inline too (or verification_status
// "passed"/"failed"), so there's no separate "get current challenge" call
// at any point in the loop.
export default function AlarmRingScreen({ route, navigation }) {
  const { alarmId } = route.params;

  const [trigger, setTrigger] = useState(null); // { trigger_id, max attempts context }
  const [challenge, setChallenge] = useState(null); // { challenge_id, category, question }
  const [answer, setAnswer] = useState('');
  const [feedback, setFeedback] = useState(null);
  const [attempts, setAttempts] = useState(0);
  const [busy, setBusy] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const [loadError, setLoadError] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const result = await triggerAlarm(alarmId);
        setTrigger({ trigger_id: result.trigger_id, verification_target: result.verification_target });
        setChallenge({ challenge_id: result.challenge_id, category: result.category, question: result.question });
      } catch (err) {
        setLoadError(err.response?.data?.detail || "Couldn't start verification for this alarm.");
      }
    })();
  }, [alarmId]);

  async function stopRinging() {
    await notifee.cancelNotification(`alarm-${alarmId}`);
  }

  async function handleSubmit() {
    setBusy(true);
    try {
      const result = await submitAttempt({
        trigger_id: trigger.trigger_id,
        challenge_id: challenge.challenge_id,
        submitted_answer: answer,
      });
      setAttempts(result.total_attempts);

      if (result.verification_status === 'passed') {
        await stopRinging();
        setDismissed(true);
        return;
      }

      if (result.next_challenge_id) {
        setChallenge({ challenge_id: result.next_challenge_id, category: challenge.category, question: result.next_question });
        setAnswer('');
        setFeedback(
          result.is_correct
            ? { correct: true, message: 'Correct — one more step.' }
            : { correct: false, message: 'Not quite. Next one.' },
        );
      } else {
        // Same challenge again (e.g. "consecutive" method resets the streak
        // on a wrong answer but keeps the same target) — result.extra may
        // carry method-specific detail worth surfacing later.
        setAnswer('');
        setFeedback({ correct: result.is_correct, message: result.is_correct ? 'Correct.' : 'Not quite. Try again.' });
      }
    } catch (err) {
      setFeedback({ correct: false, message: err.response?.data?.detail || "Couldn't check that answer." });
    } finally {
      setBusy(false);
    }
  }

  async function handleSnooze() {
    setBusy(true);
    try {
      await snoozeTrigger(trigger.trigger_id);
      await stopRinging();
      navigation.navigate('Home');
    } catch (err) {
      setFeedback({ correct: false, message: err.response?.data?.detail || "Couldn't snooze — you may be out of snoozes." });
    } finally {
      setBusy(false);
    }
  }

  if (loadError) {
    return (
      <View style={styles.center}>
        <Text style={styles.title}>Couldn't start this alarm</Text>
        <Text style={styles.sub}>{loadError}</Text>
        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Home')}>
          <Text style={styles.buttonText}>Go to dashboard</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (dismissed) {
    return (
      <View style={styles.center}>
        <Text style={styles.title}>Dismissed</Text>
        <Text style={styles.sub}>Attempts: {attempts}</Text>
        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Home')}>
          <Text style={styles.buttonText}>Go to dashboard</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (!challenge) {
    return <View style={styles.center}><Spinner size="large" /></View>;
  }

  return (
    <View style={styles.screen}>
      <View style={{ flex: 1, justifyContent: 'center' }}>
        <Text style={styles.type}>{challenge.category?.replace('_', ' ')}</Text>
        <Text style={styles.streak}>attempts {attempts}</Text>

        <View style={styles.card}>
          <Text style={styles.prompt}>{challenge.question}</Text>
          {feedback ? (
            <Text style={[styles.feedback, { color: feedback.correct ? colors.success : colors.rose }]}>{feedback.message}</Text>
          ) : null}
          <TextInput
            style={styles.input}
            autoFocus
            value={answer}
            onChangeText={setAnswer}
            placeholder="Your answer"
            placeholderTextColor={colors.mistDim}
          />
          <TouchableOpacity style={styles.button} onPress={handleSubmit} disabled={busy || !answer}>
            <Text style={styles.buttonText}>Submit</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity onPress={handleSnooze} disabled={busy}>
          <Text style={styles.snooze}>Snooze instead</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink, padding: 24 },
  center: { flex: 1, backgroundColor: colors.ink, justifyContent: 'center', alignItems: 'center', padding: 24 },
  type: { color: colors.mist, fontSize: 12, textTransform: 'uppercase', textAlign: 'center' },
  streak: { color: colors.mistDim, fontSize: 11, textAlign: 'center', marginTop: 4, marginBottom: 20 },
  card: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 16, padding: 20 },
  prompt: { color: colors.paper, fontSize: 18, lineHeight: 26 },
  feedback: { fontSize: 13, marginTop: 12 },
  input: { backgroundColor: colors.surface2, borderColor: colors.border, borderWidth: 1, borderRadius: 10, padding: 14, color: colors.paper, fontSize: 16, marginTop: 16 },
  button: { backgroundColor: colors.amber, borderRadius: 10, padding: 14, alignItems: 'center', marginTop: 14 },
  buttonText: { color: colors.ink, fontWeight: '700' },
  snooze: { color: colors.mist, textAlign: 'center', marginTop: 20 },
  title: { color: colors.paper, fontSize: 24, fontWeight: '700' },
  sub: { color: colors.mist, marginTop: 8 },
});
