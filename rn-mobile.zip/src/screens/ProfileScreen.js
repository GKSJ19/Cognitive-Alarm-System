import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { getProfile, updateProfile } from '../api/profile';
import { useAuth } from '../context/AuthContext';
import Spinner from '../components/Spinner';
import { colors } from '../theme';

// CORRECTED field names to match app/schema/user.py exactly: `name` (not
// full_name — but that only matters at registration; here it's just the
// display name), `preferred_bedtime` (not `bedtime`).
export default function ProfileScreen({ navigation }) {
  const { logout } = useAuth();
  const [form, setForm] = useState(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    getProfile().then(setForm);
  }, []);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
    setSaved(false);
  }

  async function handleSave() {
    setSaving(true);
    try {
      const { name, preferred_wake_time, preferred_bedtime, sleep_duration_mins, timezone, goal_type, difficulty_pref, bio } = form;
      await updateProfile({ name, preferred_wake_time, preferred_bedtime, sleep_duration_mins, timezone, goal_type, difficulty_pref, bio });
      setSaved(true);
    } finally {
      setSaving(false);
    }
  }

  if (!form) return <View style={styles.center}><Spinner /></View>;

  return (
    <ScrollView style={styles.screen} contentContainerStyle={{ padding: 20 }}>
      <Text style={styles.title}>Profile</Text>

      <Text style={styles.label}>Name</Text>
      <TextInput style={styles.input} value={form.name || ''} onChangeText={(v) => update('name', v)} placeholderTextColor={colors.mistDim} />

      <Text style={styles.label}>Preferred wake-up time</Text>
      <TextInput style={styles.input} value={form.preferred_wake_time || ''} onChangeText={(v) => update('preferred_wake_time', v)} placeholder="07:00" placeholderTextColor={colors.mistDim} />

      <Text style={styles.label}>Timezone</Text>
      <TextInput style={styles.input} value={form.timezone || ''} onChangeText={(v) => update('timezone', v)} placeholderTextColor={colors.mistDim} />

      <TouchableOpacity style={styles.button} onPress={handleSave} disabled={saving}>
        <Text style={styles.buttonText}>{saving ? 'Saving…' : saved ? 'Saved' : 'Save changes'}</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('ServerSettings')} style={{ marginTop: 24 }}>
        <Text style={styles.link}>Server settings</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={logout} style={{ marginTop: 16 }}>
        <Text style={styles.linkDanger}>Sign out</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink },
  center: { flex: 1, backgroundColor: colors.ink, justifyContent: 'center', alignItems: 'center' },
  title: { color: colors.paper, fontSize: 22, fontWeight: '700', marginBottom: 16 },
  label: { color: colors.mistDim, fontSize: 11, textTransform: 'uppercase', marginBottom: 6, marginTop: 16 },
  input: { backgroundColor: colors.surface2, borderColor: colors.border, borderWidth: 1, borderRadius: 10, padding: 12, color: colors.paper },
  button: { backgroundColor: colors.amber, borderRadius: 10, padding: 14, alignItems: 'center', marginTop: 24 },
  buttonText: { color: colors.ink, fontWeight: '700' },
  link: { color: colors.amber, textAlign: 'center' },
  linkDanger: { color: colors.rose, textAlign: 'center' },
});
