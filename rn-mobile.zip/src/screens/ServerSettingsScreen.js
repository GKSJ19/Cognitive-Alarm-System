import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { getServerBaseUrl, setServerBaseUrl } from '../api/client';
import { hasExactAlarmPermission, openExactAlarmSettings, requestNotificationPermission } from '../alarm/scheduler';
import { colors } from '../theme';

// Matches project-overview.md: "AsyncStorage — tokens and the configurable
// server address." No backend URL is ever hardcoded into the build.
export default function ServerSettingsScreen() {
  const [url, setUrl] = useState('');
  const [saved, setSaved] = useState(false);
  const [alarmPermission, setAlarmPermission] = useState(null);

  useEffect(() => {
    getServerBaseUrl().then(setUrl);
    hasExactAlarmPermission().then(setAlarmPermission);
  }, []);

  async function handleSave() {
    await setServerBaseUrl(url.trim());
    setSaved(true);
  }

  async function handleRequestNotifications() {
    await requestNotificationPermission();
  }

  return (
    <View style={styles.screen}>
      <Text style={styles.title}>Server settings</Text>

      <Text style={styles.label}>API base URL</Text>
      <TextInput
        style={styles.input}
        value={url}
        onChangeText={(v) => { setUrl(v); setSaved(false); }}
        autoCapitalize="none"
        placeholder="http://10.0.2.2:8000"
        placeholderTextColor={colors.mistDim}
      />
      <Text style={styles.hint}>
        Use http://10.0.2.2:8000 for a backend running on your machine while testing in the Android
        emulator, or your server's real address/domain in production.
      </Text>

      <TouchableOpacity style={styles.button} onPress={handleSave}>
        <Text style={styles.buttonText}>{saved ? 'Saved' : 'Save'}</Text>
      </TouchableOpacity>

      <View style={styles.divider} />

      <Text style={styles.label}>Notification permission</Text>
      <TouchableOpacity style={styles.secondaryButton} onPress={handleRequestNotifications}>
        <Text style={styles.secondaryButtonText}>Request permission</Text>
      </TouchableOpacity>

      <Text style={styles.label}>Exact-alarm permission</Text>
      <Text style={styles.hint}>
        {alarmPermission ? 'Granted — alarms will fire on time.' : 'Not granted — Android 12+ requires this separately, or alarms may fire late.'}
      </Text>
      <TouchableOpacity style={styles.secondaryButton} onPress={openExactAlarmSettings}>
        <Text style={styles.secondaryButtonText}>Open system settings</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink, padding: 20 },
  title: { color: colors.paper, fontSize: 22, fontWeight: '700', marginBottom: 16 },
  label: { color: colors.mistDim, fontSize: 11, textTransform: 'uppercase', marginBottom: 6, marginTop: 16 },
  input: { backgroundColor: colors.surface2, borderColor: colors.border, borderWidth: 1, borderRadius: 10, padding: 12, color: colors.paper },
  hint: { color: colors.mist, fontSize: 11, marginTop: 6, lineHeight: 16 },
  button: { backgroundColor: colors.amber, borderRadius: 10, padding: 14, alignItems: 'center', marginTop: 20 },
  buttonText: { color: colors.ink, fontWeight: '700' },
  secondaryButton: { backgroundColor: colors.surface2, borderRadius: 10, padding: 12, alignItems: 'center', marginTop: 8 },
  secondaryButtonText: { color: colors.paper, fontSize: 13 },
  divider: { height: 1, backgroundColor: colors.border, marginTop: 24 },
});
