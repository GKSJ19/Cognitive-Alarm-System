import notifee, { AndroidImportance } from '@notifee/react-native';

export const ALARM_CHANNEL_ID = 'alarm-ring';

// One high-importance, high-priority channel so alarms bypass Do Not
// Disturb-style suppression the way a real alarm clock does. Users can still
// mute it in system settings, but nothing in-app suppresses it.
export async function ensureAlarmChannel() {
  await notifee.createChannel({
    id: ALARM_CHANNEL_ID,
    name: 'Alarm',
    importance: AndroidImportance.HIGH,
    sound: 'default',
    vibration: true,
    bypassDnd: true,
  });
}
