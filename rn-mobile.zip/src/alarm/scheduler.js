import notifee, { AndroidCategory, AndroidVisibility, TriggerType, AlarmType } from '@notifee/react-native';
import { ALARM_CHANNEL_ID, ensureAlarmChannel } from './channels';

// Android-specific by design (per project-overview.md: "mobile/src/alarm/scheduler.js
// and the manifest are Android-specific, so a port to iOS would need its own
// scheduling layer using UNNotificationRequest / EventKit instead of AlarmManager").
//
// Each alarm is scheduled as a Notifee "trigger notification" backed by
// AlarmManager.setAlarmClock — the same API Android's own clock app uses, so
// it fires even in Doze and even if the app was killed. Tapping/opening it
// launches a full-screen intent straight into AlarmRingScreen.
export async function scheduleAlarm(alarm) {
  await ensureAlarmChannel();

  const trigger = {
    type: TriggerType.TIMESTAMP,
    timestamp: alarm.nextTriggerAtMs,
    alarmManager: {
      type: AlarmType.SET_ALARM_CLOCK, // exact, Doze-proof, shows in the system alarm icon
    },
  };

  await notifee.createTriggerNotification(
    {
      id: `alarm-${alarm.id}`,
      title: alarm.label || 'Alarm',
      body: 'Solve the challenge to dismiss.',
      data: { alarmId: String(alarm.id) },
      android: {
        channelId: ALARM_CHANNEL_ID,
        category: AndroidCategory.ALARM,
        visibility: AndroidVisibility.PUBLIC,
        loopSound: true,
        autoCancel: false,
        ongoing: true,
        fullScreenAction: {
          id: 'default', // launches MainActivity full-screen over the lock screen
        },
        pressAction: { id: 'default' },
        actions: [{ title: 'Open', pressAction: { id: 'default' } }],
      },
    },
    trigger,
  );
}

export async function cancelAlarm(alarmId) {
  await notifee.cancelTriggerNotification(`alarm-${alarmId}`);
}

export async function cancelAllAlarms() {
  const ids = await notifee.getTriggerNotificationIds();
  await Promise.all(ids.map((id) => notifee.cancelTriggerNotification(id)));
}

export async function getScheduledAlarmIds() {
  return notifee.getTriggerNotificationIds();
}

// Android 13+ needs POST_NOTIFICATIONS granted, and Android 12+ needs exact-
// alarm permission granted separately in system settings — Notifee can only
// request the former; the latter is a manual settings deep link (see
// ServerSettingsScreen, "Alarm permission").
export async function requestNotificationPermission() {
  const settings = await notifee.requestPermission();
  return settings;
}

export async function hasExactAlarmPermission() {
  const settings = await notifee.getNotificationSettings();
  return settings.android?.alarm === 1; // AndroidNotificationSetting.ENABLED
}

export function openExactAlarmSettings() {
  return notifee.openAlarmPermissionSettings();
}
