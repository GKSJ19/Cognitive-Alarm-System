import notifee, { EventType } from '@notifee/react-native';

// Registered once, in index.js, before the app component mounts — this is
// what lets a tap on the alarm notification navigate straight to the ringing
// screen even from a cold start (app was fully killed).
let pendingNavigationTarget = null;

export function consumePendingAlarmEvent() {
  const target = pendingNavigationTarget;
  pendingNavigationTarget = null;
  return target;
}

function extractTarget(detail) {
  const alarmId = detail?.notification?.data?.alarmId;
  return alarmId ? { alarmId } : null;
}

export function registerForegroundAlarmEvents(navigationRef) {
  return notifee.onForegroundEvent(({ type, detail }) => {
    if (type === EventType.PRESS || type === EventType.DELIVERED) {
      const target = extractTarget(detail);
      if (target && navigationRef.isReady()) {
        navigationRef.navigate('AlarmRing', target);
      }
    }
  });
}

// Background handler must be registered at the top level of index.js, not
// inside a component — Android can invoke this with the JS app not otherwise
// running.
export function registerBackgroundAlarmEvents() {
  notifee.onBackgroundEvent(async ({ type, detail }) => {
    if (type === EventType.PRESS || type === EventType.DELIVERED) {
      const target = extractTarget(detail);
      if (target) pendingNavigationTarget = target;
    }
  });
}
