import { getNextTrigger } from '../api/alarms';
import { scheduleAlarm as scheduleNotifeeAlarm, cancelAlarm } from './scheduler';

// Bridges the server (which only knows a recurrence rule) to Notifee (which
// needs one concrete future timestamp per AlarmManager trigger). Called
// after create/update/toggle-on. One-time and smart_adaptive alarms need
// re-arming after each fire — that isn't implemented yet (see mobile
// README) and is a known gap, not an oversight to silently paper over.
export async function syncDeviceAlarm(alarm) {
  if (!alarm.is_active) {
    await cancelAlarm(alarm.id);
    return;
  }
  const { next_trigger_utc } = await getNextTrigger(alarm.id);
  await scheduleNotifeeAlarm({
    id: alarm.id,
    label: alarm.label,
    nextTriggerAtMs: new Date(next_trigger_utc).getTime(),
  });
}
