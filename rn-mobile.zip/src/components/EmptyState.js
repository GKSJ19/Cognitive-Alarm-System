import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors } from '../theme';

export default function EmptyState({ title, body }) {
  return (
    <View style={styles.box}>
      <Text style={styles.title}>{title}</Text>
      {body ? <Text style={styles.body}>{body}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  box: { borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, borderRadius: 16, padding: 24, alignItems: 'center' },
  title: { color: colors.paper, fontSize: 16, fontWeight: '600', textAlign: 'center' },
  body: { color: colors.mist, fontSize: 13, marginTop: 8, textAlign: 'center' },
});
