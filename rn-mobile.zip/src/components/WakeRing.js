import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Svg, { Path, Defs, LinearGradient, Stop } from 'react-native-svg';
import { colors } from '../theme';

// Same signature gauge as the web app's WakeRing — kept as one shared visual
// identity across both clients.
export default function WakeRing({ value = 0, max = 100, size = 140, label }) {
  const pct = Math.max(0, Math.min(1, value / max));
  const stroke = 10;
  const r = (size - stroke) / 2;
  const cx = size / 2;
  const cy = size / 2;
  const sweep = 270;
  const startAngle = 135;
  const circumference = (sweep / 360) * 2 * Math.PI * r;
  const dash = circumference * pct;

  const polarToCartesian = (angleDeg) => {
    const a = ((angleDeg - 90) * Math.PI) / 180;
    return { x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) };
  };
  const start = polarToCartesian(startAngle);
  const end = polarToCartesian(startAngle + sweep);
  const largeArc = sweep > 180 ? 1 : 0;
  const trackPath = `M ${start.x} ${start.y} A ${r} ${r} 0 ${largeArc} 1 ${end.x} ${end.y}`;

  return (
    <View style={{ width: size, alignItems: 'center' }}>
      <Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <Defs>
          <LinearGradient id="wakeGradient" x1="0%" y1="100%" x2="100%" y2="0%">
            <Stop offset="0%" stopColor={colors.violet} />
            <Stop offset="55%" stopColor={colors.rose} />
            <Stop offset="100%" stopColor={colors.amber} />
          </LinearGradient>
        </Defs>
        <Path d={trackPath} fill="none" stroke={colors.surface2} strokeWidth={stroke} strokeLinecap="round" />
        <Path
          d={trackPath}
          fill="none"
          stroke="url(#wakeGradient)"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={`${dash}, ${circumference}`}
        />
      </Svg>
      <Text style={[styles.value, { marginTop: -size * 0.6 }]}>{Math.round(value)}</Text>
      {label ? <Text style={styles.label}>{label}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  value: { color: colors.paper, fontSize: 28, fontWeight: '700' },
  label: { color: colors.mist, fontSize: 12, marginTop: 4 },
});
