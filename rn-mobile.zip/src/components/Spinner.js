import React from 'react';
import { ActivityIndicator } from 'react-native';
import { colors } from '../theme';

export default function Spinner({ size = 'large' }) {
  return <ActivityIndicator size={size} color={colors.amber} />;
}
