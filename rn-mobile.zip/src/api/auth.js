import client, { setTokens, clearTokens } from './client';

// CORRECTED to match app/routers/users.py exactly: prefix is /users, not
// /auth. Register takes `name`, not `full_name`, and has no `timezone`
// field — timezone is set separately via PUT /users/me after registration.
export async function register({ name, email, password }) {
  const { data } = await client.post('/users/register', { name, email, password });
  return data;
}

export async function login({ email, password }) {
  const { data } = await client.post('/users/login', { email, password });
  await setTokens(data);
  return data;
}

export async function logout() {
  try {
    const AsyncStorage = require('@react-native-async-storage/async-storage').default;
    const refresh_token = await AsyncStorage.getItem('icap_refresh_token');
    if (refresh_token) await client.post('/users/logout', { refresh_token });
  } finally {
    await clearTokens();
  }
}

export async function fetchMe() {
  const { data } = await client.get('/users/me');
  return data;
}

export async function changePassword({ current_password, new_password }) {
  const { data } = await client.post('/users/change-password', { current_password, new_password });
  return data;
}
