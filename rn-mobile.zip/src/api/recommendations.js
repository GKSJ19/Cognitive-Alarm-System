import client from './client';

// CORRECTED: prefix is /recommend (no "s"). There is no "acknowledge" or
// "reject" action — only mark-as-read. GET /recommend generates fresh
// recommendations *and persists them as a side effect*; GET /recommend/history
// is the actual list with ids/is_read for a UI to render and toggle.
export async function listRecommendationHistory() {
  const { data } = await client.get('/recommend/history');
  return data; // [{ id, category, message, is_read, created_at }]
}

export async function markRecommendationRead(id) {
  const { data } = await client.patch(`/recommend/${id}/read`);
  return data;
}
