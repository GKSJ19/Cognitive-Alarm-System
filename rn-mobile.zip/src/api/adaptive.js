import client from './client';

// CORRECTED: app/routers/difficulty.py exposes ONE current difficulty for
// the user (not a rating per challenge type) at GET /difficulty/current.
export async function getCurrentDifficulty() {
  const { data } = await client.get('/difficulty/current');
  return data; // { difficulty, recent_accuracy_percent, recent_attempts_considered }
}
