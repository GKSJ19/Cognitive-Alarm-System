import client from './client';

// CORRECTED to match app/routers/alarms.py + app/schema/alarm.py exactly.
// Field is `alarm_type`, not `type`. `days_of_week` is an array of ints
// (0=Mon..6=Sun to match Python's isoweekday-style convention used by the
// scheduler — confirm against alarm_schedule_service.py before shipping),
// not weekday name strings. There is NO single-alarm GET endpoint — only
// list, so "edit" has to come from the already-fetched list.
//
// NOTE ON A REAL BACKEND BUG: app/schema/alarm.py has verification_method /
// verification_target / challenge_time_limit_secs typed as *module-level*
// annotations sitting after the AlarmResponse class, not inside
// AlarmCreateRequest/AlarmUpdateRequest. They are never actually part of
// the request schema, so sending them does nothing — every alarm is always
// created with the model's default (verification_method="puzzle",
// verification_target=1). This is not fixed on the frontend; it needs a
// one-line backend fix (move those three lines inside AlarmCreateRequest
// and AlarmUpdateRequest). Until then, don't build UI that implies these
// are configurable per alarm.
export async function listAlarms() {
  const { data } = await client.get('/alarms/');
  return data;
}

export async function createAlarm(payload) {
  const { data } = await client.post('/alarms/', payload);
  return data;
}

export async function updateAlarm(id, payload) {
  const { data } = await client.put(`/alarms/${id}`, payload);
  return data;
}

export async function deleteAlarm(id) {
  await client.delete(`/alarms/${id}`);
}

export async function getNextTrigger(id) {
  const { data } = await client.get(`/alarms/${id}/next-trigger`);
  return data; // { alarm_id, timezone, next_trigger_local, next_trigger_utc }
}
