import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const TOKEN_KEY = 'icap_access_token';
const REFRESH_KEY = 'icap_refresh_token';
const SERVER_KEY = 'icap_server_base_url';

// CORRECTED: the real backend (app/main.py) mounts routers with NO /api
// prefix at all — routes are directly at /users, /alarms, /verify, etc.
// Previously this defaulted to ".../api", which 404'd on every single call.
const DEFAULT_BASE_URL = 'http://10.0.2.2:8000';

let cachedBaseUrl = null;

export async function getServerBaseUrl() {
  if (cachedBaseUrl) return cachedBaseUrl;
  const stored = await AsyncStorage.getItem(SERVER_KEY);
  cachedBaseUrl = stored || DEFAULT_BASE_URL;
  return cachedBaseUrl;
}

export async function setServerBaseUrl(url) {
  // Strip a trailing slash so callers can freely do `${base}/users/login`
  // without ever producing a double slash.
  cachedBaseUrl = url.replace(/\/+$/, '');
  await AsyncStorage.setItem(SERVER_KEY, cachedBaseUrl);
}

export async function setTokens({ access_token, refresh_token }) {
  if (access_token) await AsyncStorage.setItem(TOKEN_KEY, access_token);
  if (refresh_token) await AsyncStorage.setItem(REFRESH_KEY, refresh_token);
}

export async function clearTokens() {
  await AsyncStorage.multiRemove([TOKEN_KEY, REFRESH_KEY]);
}

const client = axios.create({ timeout: 15000 });

client.interceptors.request.use(async (config) => {
  config.baseURL = await getServerBaseUrl();
  const token = await AsyncStorage.getItem(TOKEN_KEY);
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

let refreshPromise = null;

client.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config;
    const status = error.response?.status;

    // CORRECTED: refresh lives at /users/refresh, not /auth/refresh.
    if (status !== 401 || original._retried || original.url?.includes('/users/refresh')) {
      return Promise.reject(error);
    }
    const refreshToken = await AsyncStorage.getItem(REFRESH_KEY);
    if (!refreshToken) {
      await clearTokens();
      return Promise.reject(error);
    }
    original._retried = true;

    try {
      if (!refreshPromise) {
        const baseURL = await getServerBaseUrl();
        refreshPromise = axios
          .post(`${baseURL}/users/refresh`, { refresh_token: refreshToken })
          .then(async (res) => {
            await setTokens(res.data);
            return res.data;
          })
          .finally(() => {
            refreshPromise = null;
          });
      }
      const data = await refreshPromise;
      original.headers.Authorization = `Bearer ${data.access_token}`;
      return client(original);
    } catch (refreshError) {
      await clearTokens();
      return Promise.reject(refreshError);
    }
  },
);

export default client;
