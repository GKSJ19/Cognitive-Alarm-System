import client from './client';

// CORRECTED: prefix is /habit (singular), path is /score. Response has no
// "components" array — it's four named *_score fields plus total_score and
// insufficient_data, matching app/services/habit_score_service.py exactly.
export async function getHabitScore() {
  const { data } = await client.get('/habit/score');
  return data;
  // { date, wake_consistency_score, challenge_success_score,
  //   snooze_reduction_score, sleep_adherence_score, total_score,
  //   insufficient_data, components_used }
}
