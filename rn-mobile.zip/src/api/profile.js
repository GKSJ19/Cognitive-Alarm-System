import client from './client';

// CORRECTED: profile lives at /users/me (GET + PUT), not /profile. Field
// names match app/schema/user.py exactly: `name` (not full_name),
// `preferred_bedtime` (not `bedtime`), `sleep_duration_mins` (not a
// separate target field), `goal_type` (not `productivity_goals`),
// `difficulty_pref` (not `difficulty_preference`).
export async function getProfile() {
  const { data } = await client.get('/users/me');
  return data;
}

export async function updateProfile(payload) {
  const { data } = await client.put('/users/me', payload);
  return data;
}
