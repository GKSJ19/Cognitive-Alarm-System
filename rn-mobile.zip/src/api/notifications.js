import client from './client';

// CORRECTED: prefix is /notify. List response is an envelope
// { total, unread_count, notifications: [...] }, not a bare array. Marking
// read is PATCH, not POST.
export async function listNotifications({ unreadOnly = false } = {}) {
  const { data } = await client.get('/notify', { params: { unread_only: unreadOnly } });
  return data;
}

export async function markNotificationRead(id) {
  const { data } = await client.patch(`/notify/${id}/read`);
  return data;
}

export async function markAllNotificationsRead() {
  const { data } = await client.patch('/notify/read-all');
  return data;
}
