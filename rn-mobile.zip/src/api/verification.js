import client from './client';

// This replaces the old challenges.js. CORRECTED to match the real flow in
// app/routers/verification.py (prefix /verify) — there is no "alarm event"
// resource to fetch a challenge from. Instead: you create a *trigger* (which
// returns the first challenge inline), then each answer attempt returns the
// next challenge inline too, until verification_status is "passed".
export async function triggerAlarm(alarmId) {
  const { data } = await client.post('/verify/trigger', { alarm_id: alarmId });
  return data; // { trigger_id, challenge_id, category, question, verification_method, verification_target, debug_answer }
}

export async function submitAttempt({ trigger_id, challenge_id, submitted_answer }) {
  const { data } = await client.post('/verify/attempt', { trigger_id, challenge_id, submitted_answer });
  return data; // { is_correct, verification_status, total_attempts, current_step, next_challenge_id, next_question, extra }
}

export async function snoozeTrigger(triggerId) {
  const { data } = await client.post('/verify/snooze', { trigger_id: triggerId });
  return data; // { snooze_count, max_snoozes, snoozes_remaining, can_still_snooze }
}
