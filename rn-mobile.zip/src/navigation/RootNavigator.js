import React from 'react';
import { ActivityIndicator, View } from 'react-native';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useAuth } from '../context/AuthContext';
import { colors } from '../theme';

import LoginScreen from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import ServerSettingsScreen from '../screens/ServerSettingsScreen';
import HomeScreen from '../screens/HomeScreen';
import AlarmsScreen from '../screens/AlarmsScreen';
import AlarmEditorScreen from '../screens/AlarmEditorScreen';
import AlarmRingScreen from '../screens/AlarmRingScreen';
import HabitScoreScreen from '../screens/HabitScoreScreen';
import RecommendationsScreen from '../screens/RecommendationsScreen';
import NotificationsScreen from '../screens/NotificationsScreen';
import ProfileScreen from '../screens/ProfileScreen';

const AuthStack = createNativeStackNavigator();
const MainStack = createNativeStackNavigator();
const Tabs = createBottomTabNavigator();

const navTheme = {
  ...DarkTheme,
  colors: { ...DarkTheme.colors, background: colors.ink, card: colors.surface, border: colors.border, primary: colors.amber, text: colors.paper },
};

function MainTabs() {
  return (
    <Tabs.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.border },
        tabBarActiveTintColor: colors.amber,
        tabBarInactiveTintColor: colors.mist,
      }}
    >
      <Tabs.Screen name="Home" component={HomeScreen} />
      <Tabs.Screen name="Alarms" component={AlarmsScreen} />
      <Tabs.Screen name="HabitScore" component={HabitScoreScreen} options={{ title: 'Habit' }} />
      <Tabs.Screen name="Recommendations" component={RecommendationsScreen} options={{ title: 'Tips' }} />
      <Tabs.Screen name="Notifications" component={NotificationsScreen} options={{ title: 'Alerts' }} />
      <Tabs.Screen name="Profile" component={ProfileScreen} />
    </Tabs.Navigator>
  );
}

function AuthFlow() {
  return (
    <AuthStack.Navigator screenOptions={{ headerShown: false }}>
      <AuthStack.Screen name="Login" component={LoginScreen} />
      <AuthStack.Screen name="Register" component={RegisterScreen} />
      <AuthStack.Screen name="ServerSettings" component={ServerSettingsScreen} options={{ headerShown: true, title: 'Server settings' }} />
    </AuthStack.Navigator>
  );
}

function MainFlow() {
  return (
    <MainStack.Navigator screenOptions={{ headerShown: false }}>
      <MainStack.Screen name="Tabs" component={MainTabs} />
      <MainStack.Screen name="AlarmEditor" component={AlarmEditorScreen} options={{ headerShown: true, title: 'Alarm' }} />
      <MainStack.Screen name="AlarmRing" component={AlarmRingScreen} options={{ gestureEnabled: false }} />
      <MainStack.Screen name="ServerSettings" component={ServerSettingsScreen} options={{ headerShown: true, title: 'Server settings' }} />
    </MainStack.Navigator>
  );
}

export default function RootNavigator({ navigationRef }) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.ink, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color={colors.amber} />
      </View>
    );
  }

  return (
    <NavigationContainer ref={navigationRef} theme={navTheme}>
      {user ? <MainFlow /> : <AuthFlow />}
    </NavigationContainer>
  );
}
