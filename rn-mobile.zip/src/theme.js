// Same dawn palette and roles as the web app (icap-web/src/index.css) so the
// two clients read as one product.
export const colors = {
  ink: '#12111c',
  surface: '#1c1a2b',
  surface2: '#262340',
  surface3: '#302c4d',
  paper: '#f5f3f0',
  mist: '#a8a4bf',
  mistDim: '#6d6a8a',
  amber: '#f2a65a',
  rose: '#e0607e',
  violet: '#7c6fd6',
  success: '#6fcf97',
  danger: '#e5657a',
  border: '#33304d',
};
