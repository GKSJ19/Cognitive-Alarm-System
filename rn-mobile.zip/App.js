import React, { useEffect, useRef } from 'react';
import { StatusBar } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider } from './src/context/AuthContext';
import RootNavigator from './src/navigation/RootNavigator';
import { registerForegroundAlarmEvents, consumePendingAlarmEvent } from './src/alarm/events';
import { colors } from './src/theme';

export default function App() {
  const navigationRef = useRef();

  useEffect(() => {
    const unsubscribe = registerForegroundAlarmEvents(navigationRef);
    return unsubscribe;
  }, []);

  useEffect(() => {
    // Cold start via a tapped/full-screen alarm notification: the background
    // handler (registered in index.js) stashed the target before the JS
    // engine was even up. Consume it once the navigator is mounted.
    const target = consumePendingAlarmEvent();
    if (target && navigationRef.current?.isReady()) {
      navigationRef.current.navigate('AlarmRing', target);
    }
  }, []);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <StatusBar barStyle="light-content" backgroundColor={colors.ink} />
        <AuthProvider>
          <RootNavigator navigationRef={navigationRef} />
        </AuthProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
