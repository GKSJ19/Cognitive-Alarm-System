# Cognitive Alarm — Android app

Bare React Native (no Expo), matching project-overview.md's mobile stack:
React Native 0.76.5, Notifee for alarm scheduling, AsyncStorage for tokens
and the server address, axios sharing the web client's API contract.

## Status: reconciled against the real backend (icap2)
This was originally built guessing at API shapes from the project brief, then
fully reconciled line-by-line against the actual FastAPI backend
(`app/main.py`, every router in `app/routers/`, every schema in `app/schema/`,
and the service functions that build response bodies). Every `src/api/*.js`
file has a comment explaining what was wrong before and what's correct now.
See `icap-web/README.md` for the full list of corrections — they apply
identically here, plus:

- **`client.js`'s default base URL had a stray `/api` suffix** — removed. It
  now points at `http://10.0.2.2:8000` (emulator loopback), no prefix.
- **The old `challenges.js` (fetch-a-challenge-for-an-alarm-event) never
  matched anything real.** Replaced with `verification.js`, matching the
  actual trigger/attempt/snooze flow in `app/routers/verification.py`.
  `AlarmRingScreen.js` was rewritten around it: arriving here means the
  on-device alarm just fired, and the screen's own job is to open the
  trigger (`POST /verify/trigger {alarm_id}`), not fetch a pre-existing
  challenge.
- **There's no batched "next trigger time" for all alarms.** `src/alarm/
  rescheduling.js` is new — it calls `GET /alarms/{id}/next-trigger` per
  active alarm and converts the result into the one concrete timestamp
  Notifee's `AlarmManager` trigger needs. This runs after create/update/
  toggle-on.
- **Known gap, not fixed here:** every alarm re-arm scenario is unimplemented.
  Notifee's `AlarmManager.setAlarmClock` trigger fires once at one concrete
  timestamp — it isn't a recurring alarm. That means:
  - After a **daily/weekday/weekend/smart_adaptive** alarm fires and is
    dismissed, the device needs a fresh call to `syncDeviceAlarm` for the
    *next* occurrence. `AlarmRingScreen.js` currently just stops the ringing
    notification; it doesn't re-arm anything.
  - After a **snooze**, `POST /verify/snooze` doesn't return a next-fire
    time — the alarm model's `snooze_duration_mins` has to be used to
    compute `now + snooze_duration_mins` and schedule that locally, which
    means the ring screen needs that field (currently only `alarmId` is
    passed through the notification payload).
  Both are real work, not a one-line fix — flagging clearly rather than
  leaving a half-working implementation in place.

## Why bare RN instead of Expo
No Expo SDK version lock-step, no `expo install`, no Expo Go — just RN CLI +
Gradle, the same as any native Android project. One version-drift bug already
got caught and fixed during the original build: `react-native-screens`
resolved to `4.27.0` under a caret range and broke Metro's codegen against RN
0.76.5. Every native-module dependency is pinned to an exact version for
that reason.

## What's verified vs. not
No Android SDK / Google Maven access in the environment this was built in,
so no actual `./gradlew assembleDebug` was run. What was verified after the
API rewrite: `npm install` resolves cleanly, all 32 source files pass a full
Babel transform, and a complete production Metro bundle
(`react-native bundle --platform android`) builds end-to-end — walking every
import in the app, including the new `verification.js` and
`rescheduling.js`. `./gradlew assembleDebug` on your machine is still the
real pass/fail gate.

## Screens (11)
Login, Register, Server settings, Home, Alarms, Alarm editor, Alarm ring
(the challenge-to-dismiss screen), Habit score, Recommendations,
Notifications, Profile.

## Permissions
Two Android permissions matter for the alarm to actually fire on time:
1. **Notifications** (Android 13+) — requested in-app
2. **Exact alarms** (Android 12+) — deep link to system settings, not a
   runtime dialog; both `ServerSettingsScreen` and `AlarmEditorScreen`
   surface a warning banner if it isn't granted

## Local dev
```bash
npm install
npx react-native start          # Metro
npx react-native run-android    # separate terminal, needs Android SDK + a device/emulator
```
Set the server address once in-app on **Server settings** — no backend host
is hardcoded anywhere.

## Building a release APK
```bash
cd android
./gradlew assembleRelease
# APK at android/app/build/outputs/apk/release/
```
Needs a real signing config for release (template ships debug-signed only).
